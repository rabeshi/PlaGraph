package com.example.animationgame;

public class Ball {
double x;
double y;
double xspeed;
double yspeed;
double max_x;
int max_y;

public Ball(double x, double y, double xspeed, double yspeed, double max_x,
		int max_y) {
	super();
	this.x = x;
	this.y = y;
	this.xspeed = xspeed;
	this.yspeed = yspeed;
	this.max_x = max_x;
	this.max_y = max_y;
}
public void update(double a)
{
	int b = 1;
	yspeed += a;
	y+=yspeed;
	x+=xspeed;
	
	if(y>max_y-5 || y< 0){
		yspeed *= -0.8;
		y=max_y-5;
	}
	if(x>max_x || x< 0)
		xspeed *= -1;
	
}

}
