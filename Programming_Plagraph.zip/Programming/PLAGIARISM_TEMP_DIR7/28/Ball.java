package com.example.animationgame;

public class Ball {
	
	double x; //to indicate the horizontal position of the ball
	double y; //to indicate the vertical position of the ball
	double xspeed; //to indicate the current horizontal velocity of the ball
	double yspeed; //to indicate the current vertical velocity of the ball
	double max_x; //indicates the highest x value the ball can take before it bounces. this would normally be set to the width of the screen
	double max_y;//indicates the highest y value the ball can take before it bounces. this would normally be set to the heght of the screen
	
	public Ball(double px, double py, double pxspeed, double pyspeed, double pmax_x, double pmax_y)
	{
		x=px;
		y=py;
		xspeed = pxspeed;
		yspeed = pyspeed;
		max_x = pmax_x;
		max_y = pmax_y;
	}
	
	public void update(double yacc)
	{
		yspeed += yacc;
		y+= yspeed;
		x+= xspeed;
		
		if(y>max_y || y<0)
		{
			yspeed = yspeed*(-0.8);
		}
		
		//x+= xspeed;
		
		if(x>max_x || x<0)
		{
			xspeed = xspeed*(-1);
		}
		
		if(y+yspeed> max_y)
		{
			y = max_y;
		}
		
		
	}
	
	

}
