package com.example.animationgame;

public class Ball extends MainActivity
{
	public double x;
	public double y;
	public double xspeed;
	public double yspeed;
	public double max_x;
	public double max_y;
    public double y_acceleration_value;
    
	public Ball(double ballX, double ballY, double ballXspeed, double ballYspeed, double ballMax_x, double ballMax_y)
	{
		this.x = ballX;
		this.y = ballY;
		this.xspeed = ballXspeed;
		this.yspeed = ballYspeed;
		this.max_x = ballMax_x;
		this.max_y = ballMax_y;	
	}
	
	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}
	
	public void setY(double y) {
		this.y = y;
	}
	public double getXspeed() {
		return xspeed;
	}

	public void setXspeed(double xspeed) {
		this.xspeed = xspeed;
	}

	public double getYspeed() {
		return yspeed;
	}

	public void setYspeed(double yspeed) {
		this.yspeed = yspeed;
	}

	public double getMax_x() {
		return max_x;
	}

	public void setMax_x(double max_x) {
		this.max_x = max_x;
	}

	public double getMax_y() {
		return max_y;
	}

	public void setMax_y(double max_y) {
		this.max_y = max_y;
	}

	
	public void update (double yAccelerationValue)
	{
		yspeed = yspeed + yAccelerationValue;
		y = y + yspeed;
		x = x + xspeed;
		
		if(y>max_y)
		{
			y = max_y;
			yspeed = -0.8 *yspeed;	
		}   
		
		 if (y<0)
		 {
			 yspeed = -0.8 *yspeed;	
		 }
		 
		 
	
		if(x>max_x)
		{
			x = max_x;
		    xspeed = -0.8 *xspeed;	
		} 
	
		if (x<0)
		{
			xspeed = -0.8 *xspeed;
		}
	}
}
