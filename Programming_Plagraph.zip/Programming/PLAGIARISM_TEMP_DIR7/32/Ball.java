package com.example.animationgame;

public class Ball {
	double x, y, xspeed, yspeed, max_x, max_y;
	public Ball(double x1, double y1, double xs, double ys, double mx, double my){
		x = x1;
		y = y1;
		xspeed = xs;
		yspeed = ys;
		max_x = mx;
		max_y = my;
	}
	
	public void update(double yacc, double xacc){
		yspeed += yacc;
		xspeed += xacc;
		y += yspeed;
		x += xspeed;
		if(y > max_y || y < 0){
			yspeed = yspeed*-0.8;
		}
		if(x > max_x || x<0){
			xspeed = xspeed*-0.8;
		}
		if (y>max_y + yspeed ) {
			y = max_y;
		}
		if(x>max_x +xspeed){
			x = max_x;
		}
		if(x + xspeed <0){
			x = 0;
		}

	}
}
