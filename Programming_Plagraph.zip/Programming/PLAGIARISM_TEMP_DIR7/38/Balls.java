package com.example.bounceballs;

public class Balls {
	double x,y,xspeed,yspeed,maxX,maxY;	
	
	public Balls(double xIns,double yIns,double xspeedIns, double yspeedIns, double maxXIns, double maxYIns){
		x = xIns;
		y = yIns;
		xspeed = xspeedIns;
		yspeed = yspeedIns;
		maxX = maxXIns;
		maxY = maxYIns;
	}
	
	public void update(double yAcc){
		//Y-direction
		yspeed += yAcc;
		
		
		if(y+yspeed < maxY ){
			y += yspeed;
		}
		
		if (y+yspeed >= maxY || y+yspeed <= 0){
			yspeed = -0.8*yspeed;						
		}
		
		if(x + xspeed >= maxX || x+ xspeed <= 0){
			xspeed = -0.8*xspeed;
		}	
		x += xspeed;
			
	}	
	
	public void changeXY(double xtouch){
		if(xtouch > (maxX*0.5)){
			y = 50;	
			xspeed = -1*xspeed;			
		}	
		
	}

}
