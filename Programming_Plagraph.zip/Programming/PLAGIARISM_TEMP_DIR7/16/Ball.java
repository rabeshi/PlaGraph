package merand.tau.animationgame;

/**
 * Created by david on 2015/04/21.
 */
public class Ball{
    public double x,y,xspeed,yspeed,max_x,max_y;

    public Ball(double x, double y, double xspeed, double yspeed, double max_x, double max_y) {
        this.x = x;
        this.y = y;
        this.xspeed = xspeed;
        this.yspeed = yspeed;
        this.max_x = max_x;
        this.max_y = max_y;
    }

    public void update(double yacc){
        yspeed+=yacc;

        y+=yspeed;
        x+=xspeed;
        if (y>max_y || y<0){
            y=max_y;
            yspeed*=-0.8;
        }

        if (x>max_x||x<0){
            x=max_x;
            xspeed*=-0.8;
        }
    }
}
