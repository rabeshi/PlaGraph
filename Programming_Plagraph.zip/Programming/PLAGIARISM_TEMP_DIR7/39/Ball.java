package com.example.hloni;

public class Ball {
	
	double x, y,x_speed,y_speed,max_x,max_y,height;
	
	public Ball(double x,double y,double x_speed,double y_speed,double max_x,double max_y,double height){
		this.x = x;
		this.y = y;
		this.max_x = max_x;
		this.max_y = max_y;
		this.x_speed = x_speed;
		this.y_speed = y_speed;
		this.height = height;
	}
	
	public void	Update(double acceleration){
		y_speed+=acceleration;
		y=y+y_speed;
		x=x+x_speed;
		
		if(y>max_y-height || y<0){
			y_speed = (-0.8)*y_speed;
			y = max_y-height;
		}
		
		if(x>max_x-height || x<0){
			x_speed = (-1)*x_speed;
			//x=max_x-height;
		}
	}
	
}
