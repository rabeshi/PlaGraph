package com.example.animationgame;


public class Ball {
	double x,y,xspeed,yspeed;
	int max_x,max_y;
	
	Ball(double x1, double y1, double xspeed1, double yspeed1, int max_x1, int max_y1){
		x = x1;
		y = y1;
		xspeed = xspeed1;
		yspeed = yspeed1;
		max_x = max_x1;
		max_y = max_y1;
	}
	public void update(double yAcc){
		yspeed = yspeed + yAcc;

		
		if (y >= max_y && yspeed>0){
			yspeed = -0.8 * yspeed;
		}
		else if (y<=2.5 && yspeed<0){
			yspeed = -yspeed;
		}
		y = y + yspeed;
		
		
		if (x >= max_x && xspeed>0){
			xspeed = -0.8 * xspeed;
		}
		else if (x<=2.5 && xspeed<0){
			xspeed = -xspeed;
		}
		x = x + xspeed;
	}
}
