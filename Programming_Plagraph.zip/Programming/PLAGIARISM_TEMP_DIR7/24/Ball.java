package com.example.lab6;

public class Ball {
	double x,y;
	double xspeed,yspeed;
	double x_max,y_max;
	
	public Ball(double xVal,double yVal,double xSVal,double ySVal,double xMaxVal,double yMaxVal){
		x = xVal;
		y = yVal;
		xspeed = xSVal;
		yspeed = ySVal;
		x_max = xMaxVal;
		y_max = yMaxVal;
	}
	
	public void update(double yAcc){
		yspeed += yAcc;
		y += yspeed;
		x += xspeed;
		
		if(y>y_max || y<0){
			y = y_max;
			yspeed = yspeed * (-0.8);
		}
		
		if(x>x_max){
			x= x_max;
			xspeed = xspeed * (-0.8);
		}
		else if (x<0){
			x= 0;
			xspeed = xspeed * (-0.8);
		}
		
		
	}
}
