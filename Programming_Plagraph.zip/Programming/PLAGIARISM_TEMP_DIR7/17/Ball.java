package com.example.animationgame;

public class Ball {
	double x, y;
	double xspeed, yspeed;
	double max_x, max_y;
	double yacceleration, xacceleration;
	boolean ystationary, xstationary;
	
	public void update(){
		yspeed = yspeed + yacceleration;
		
		if ( (Math.round(yspeed) == 0) && ((Math.round(max_y-y) == 0) || (Math.round(y) == 0)) )
			{yspeed = 0;}
		
		if ( (Math.round(xspeed) == 0) && ((Math.round(max_x-x) == 0) || (Math.round(x) == 0)) )
			{xspeed = 0;}
		
		//Y bounds (top and bottom)
		if (y+yspeed >= max_y){
				y = max_y + (-0.8)*((y+yspeed)%max_y);
				yspeed = (-0.8)*yspeed;
		}
		else{
				if (y+yspeed <= 0){
					y = (-0.8)*(yspeed + y);
					yspeed = (-0.8)*yspeed;
				}
				else
					{y = y + yspeed;}
			}
		
		//Right bound (left and right)
		if (x+xspeed >= max_x){
			x = max_x + (- 0.8)*((x+xspeed)%max_x);
			xspeed = (-0.8)*xspeed;
		}
		else{
			if (x+xspeed <= 0){
				x = (-0.8)*(xspeed + x);
				xspeed = (-0.8)*xspeed;
			}
			else
				{x = x + xspeed;}
		}

	}
	
	public Ball(double xIn, double yIn, double xspeedIn, double xaccelerationIn, double yspeedIn, double yaccelerationIn, double max_xIn, double max_yIn){
		x = xIn;
		y = yIn;
		xspeed = xspeedIn;
		yspeed = yspeedIn;
		max_x = max_xIn;
		max_y = max_yIn;
		yacceleration = yaccelerationIn;
	}
}
