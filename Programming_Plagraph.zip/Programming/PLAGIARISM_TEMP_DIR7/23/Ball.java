package com.example.animationgame;

public class Ball {
	double y;
	double x;
	double xspeed;
	double yspeed;
	double max_x = 0;
	double max_y = 0;

	public Ball(double x, double y, double xspeed, double yspeed, double max_x,
			double max_y) {
		this.max_x = max_x;
		this.max_y = max_y;
		this.x = x;
		this.y = y;
		this.xspeed = xspeed;
		this.yspeed = yspeed;
	}

	public void update(double acceleration) {
		x += xspeed;
		if (y > max_y) {
			y = max_y;
			yspeed = -0.8 * yspeed;
		}
		if (y < 0) {
			y = 0;
			yspeed = -0.8 * yspeed;
		}
		yspeed += acceleration;
		y += yspeed;
		if (x > max_x || x < 0) {
			xspeed = -xspeed;

		}

		// if(x<max_x){
		// xspeed=-xspeed;
		//
		// }
		// if(xspeed<=0){
		// x=0.8*x;
		// }
	}
	// public static void x_update(double xacceleration){
	//
	// }
}
