package com.example.animationgame;

public class Ball {
	double x;
	double y;
	double xspeed;
	double yspeed;
	double max_x;//width
	double max_y;//height
	
	public Ball(double p,double q,double pspeed,double qspeed,double max_p,double max_q){
		x=p;
		y=q;
		xspeed=pspeed;
		yspeed=qspeed;
		max_x=max_p;
		max_y=max_q;
	}
	
	public void update(double y_acc){
		yspeed += y_acc;
		y += yspeed;
		x += xspeed;
		
		if(y>=max_y || y<=0){
			if(y>max_y){
				y=max_y;
			}
			if(y<0){
				y=0;
			}
			yspeed = yspeed * -0.8;
		}
		
		if(x>=max_x || x<=0){
			if(x>max_x){
				x=max_x;
			}
			if(x<0){
				x=0;
			}
			xspeed = xspeed * -0.8;
		}
		
	}

}
