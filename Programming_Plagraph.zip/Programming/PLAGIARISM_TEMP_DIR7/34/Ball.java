package com.example.balls;

public class Ball {
double x,y;
double xSpeed, ySpeed;
double max_x,max_y;


public Ball(double x, double y, double xSpeed, double ySpeed, double max_x,
		double max_y) {
	super();
	this.x = x;
	this.y = y;
	this.xSpeed = xSpeed;
	this.ySpeed = ySpeed;
	this.max_x = max_x;
	this.max_y = max_y;
}


public double getX() {
	return x;
}


public void setX(double x) {
	this.x = x;
}


public double getY() {
	return y;
}


public void setY(double y) {
	this.y = y;
}


public double getxSpeed() {
	return xSpeed;
}


public void setxSpeed(double xSpeed) {
	this.xSpeed = xSpeed;
}


public double getySpeed() {
	return ySpeed;
}


public void setySpeed(double ySpeed) {
	this.ySpeed = ySpeed;
}


public double getmax_x() {
	return max_x;
}


public void setmax_x(double max_x) {
	this.max_x = max_x;
}


public double getmax_y() {
	return max_y;
}


public void setmax_y(double max_y) {
	this.max_y = max_y;
}


public void update(double yAcc){
	ySpeed+=yAcc;
	y+=ySpeed;
	x+=xSpeed;
	if (y > max_y) {
		y=max_y-1;
		ySpeed = ySpeed*-0.8;
	}
	if (y < 0) {
		y+=1;
		ySpeed = ySpeed*-0.8;
	}
	
	if (x >max_x) {
		x=max_x-1;

		xSpeed = xSpeed*-0.8;
	}
	if (x < 0) {
		x=1;
		xSpeed = xSpeed*-0.8;
	}
}
}


