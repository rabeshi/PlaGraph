package com.example.pangs;

public class Ball
{
//  int c;
  double max_x;
  double max_y;
  double x;
  double xspeed;
  double y;
  double yspeed;
  
  public Ball(double x, double y, double xs, double ys, int xm, int ym)
  {
    this.x = x;
    this.y = y;
    this.xspeed = xs;
    this.yspeed = ys;
    this.max_x = xm;
    this.max_y = ym;
  }
  
  public void update(double acc)
  {
    this.yspeed = (acc + this.yspeed);
    this.y += this.yspeed;
    this.x += this.xspeed;
    if (this.y > this.max_y)
    {
      this.y = this.max_y;
      this.yspeed = (-0.8 * this.yspeed);
    }
    if (this.x < 0.0)
    {
      this.x = 0.0;
      this.xspeed = (-this.xspeed);
    }
    if (this.x > this.max_x)
    {
      this.x = this.max_x;
      this.xspeed = (-0.8 * this.xspeed);
    }
  }
}
