package com.example.animationgame;

public class Ball {
	public double x,y,xspeed,yspeed,max_y,max_x;
	public Ball(double x, double y, double yspeed, double xspeed, double max_x,double max_y) {
		this.x = x;
		this.y = y;
		this.xspeed = xspeed;
		this.yspeed = yspeed;
		this.max_y = max_y;
		this.max_x = max_x;
	}
	public void update(double y1)
	{
		if(y<=0)
		{
			yspeed=yspeed*-0.8;
			y=max_y;
		}
		else if(y>max_y)
		{
	    	 
		     yspeed=yspeed*-0.8;
		     y=max_y;
		}
		yspeed=yspeed+y1;
		y=y+yspeed;
		if(x<=0)
		{
			xspeed=xspeed*-0.8;
			x=0;
		}
		else if(x>max_x)
		{
		     xspeed=xspeed*-0.8;
		     x=max_x;
		}
	    x=x+xspeed;	
	}
}
