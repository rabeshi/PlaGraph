package com.example.animationgame;

public class Ball {
	static int radius = 5;
	//down is positive
	double x,y,xspeed,yspeed,max_x,max_y;

	public void update(double y_accel) {
		yspeed += y_accel;
		y += yspeed;
		if(y > max_y-radius) y = max_y-radius;
		x += xspeed;
		if(x > max_x-radius) x = max_x-radius;
		else if(x < radius) x = radius;
		
		if(y>=max_y-radius || y<=radius) yspeed*=-0.8;
		if(x>=max_x-radius || x<=radius) xspeed*=-0.8;
	}
	
	public void flipX() {
		xspeed *= -1;
	}
	
	//AUTO-GENERATED
	public Ball(double x, double y, double xspeed, double yspeed, double max_x,
			double max_y) {
		this.x = x;
		this.y = y;
		this.xspeed = xspeed;
		this.yspeed = yspeed;
		this.max_x = max_x;
		this.max_y = max_y;
	}
	
	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public double getXspeed() {
		return xspeed;
	}

	public void setXspeed(double xspeed) {
		this.xspeed = xspeed;
	}

	public double getYspeed() {
		return yspeed;
	}

	public void setYspeed(double yspeed) {
		this.yspeed = yspeed;
	}

	public double getMax_x() {
		return max_x;
	}

	public void setMax_x(double max_x) {
		this.max_x = max_x;
	}

	public double getMax_y() {
		return max_y;
	}

	public void setMax_y(double max_y) {
		this.max_y = max_y;
	}
}

