package com.example.animationgame;

import android.util.DisplayMetrics;

public class Ball {
	


	
	
double x, y, xspeed, yspeed, height; 
double max_x;
double max_y;


public Ball(int x, int y, int xspeed, int yspeed, int max_x, int max_y,int height) {
	super();
	this.x = x;
	this.y = y;
	this.xspeed = xspeed;
	this.yspeed = yspeed;
	this.max_x=max_x;
	this.max_y=max_y;
	this.height=height;
}

public void update(double a){
	yspeed= yspeed +a;
	y=y+yspeed;
	x=x+xspeed;

	if(y>max_y-height || y<0){
		yspeed=yspeed*(-0.8);
		y=max_y-height;
	}
	
	
	if(x>max_x || x<0){
		xspeed=xspeed*(-1);
	
}
}
}
