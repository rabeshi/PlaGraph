package com.example.animationgame;

public class Ball {
	double x,y,xSpeed,ySpeed,max_x,max_y;
	
	
	public Ball (double xIn, double yIn, double xSpeedIn, double ySpeedIn, double max_xIn, double max_yIn){
		x = xIn;
		y = yIn;
		xSpeed = xSpeedIn;
		ySpeed = ySpeedIn;
		max_x = max_xIn;
		max_y = max_yIn;
	}
	
	public void update (double yAcc){
		ySpeed += yAcc;
		y += ySpeed;
		x += xSpeed;
		if (y > max_y || y < 0){
			ySpeed *= -0.8;
		}
		if (x > max_x || x < 0){
			xSpeed *= -1;
		}
		if (y > max_y + ySpeed){
			y = max_y;
		}
		if (x > max_x + xSpeed){
			x = max_x;
		}
		if (x < 0 - xSpeed){
			x = 0;
		}
	}
}
