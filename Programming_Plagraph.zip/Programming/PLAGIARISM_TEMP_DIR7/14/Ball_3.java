package com.example.pangs;

public class Ball {
	double x,y,x_speed,y_speed,max_x,max_y;
	public Ball(double x,double y,double x_speed,double y_speed,double max_x,double max_y){
		this.x = x;
		this.y = y;
		this.max_x =max_x;
		this.max_y = max_y;
		this.x_speed = x_speed;
		this.y_speed = y_speed;
	}
	public void Update(double y_acc,double finale,boolean checked){
		if(checked&&x>=finale){
			this.y_speed+=y_acc;
			this.y+=this.y_speed;
			this.x=finale;	
		}else{
			this.y_speed+=y_acc;
			this.y+=this.y_speed;
			this.x+=this.x_speed;
		}
		if(y>=max_y || y<=0){
			y_speed*=-1;
		}
		if(x>=finale || x<=0){
			x_speed*=-1 ;
		}
	}
	public void UpdateLine(double y_acc){
		this.x-=y_acc;

	}

}
