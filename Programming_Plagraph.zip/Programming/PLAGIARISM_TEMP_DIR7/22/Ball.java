package com.example.animationgame;

public class Ball 
{
	double x,y,xSpeed,ySpeed,maxX,maxY;
	
	public Ball(double x1,double y1, double xspeed,double yspeed,double maxx,double maxy)
	{
		x=x1;
		y=y1;
		xSpeed=xspeed;
		ySpeed=yspeed;
		maxX=maxx;
		maxY=maxy;
	}
	
	public void update(double acc)
	{
		ySpeed+=acc;
		x+=xSpeed;
		y+=ySpeed;
		
		if(x>maxX)
		{
			x=maxX;
			xSpeed*=-1;
		}
		else if(x<0)
		{
			x=0;
			xSpeed*=-1;
		}
		if(y>maxY)
		{
			y=maxY;
			ySpeed*=-0.8;
		}
	}
}
