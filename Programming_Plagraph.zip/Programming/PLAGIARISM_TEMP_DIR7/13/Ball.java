package com.example.animationgame;

public class Ball {
	double x, y, xspeed, yspeed, max_x, max_y;
	
	public Ball(double xvalue, double yvalue, double speedx, double speedy, double x_max, double y_max){
		setX(xvalue); setY(yvalue);
		setXspeed(speedx); setYspeed(speedy);
		setXmax(x_max); setYmax(y_max);
	}
	
	public void setX(double xvalue){
		this.x = xvalue;
	}
	
	public double getX(){
		return x;
	}
	
	public void setY(double yvalue){
		this.y = yvalue;
	}
	
	public double getY(){
		return y;
	}
	
	public void setXspeed(double speedx){
		this.xspeed = speedx;
	}
	
	public double getXspeed(){
		return xspeed;
	}
	
	public void setYspeed(double speedy){
		this.yspeed = speedy;
	}
	
	public double getYspeed(){
		return yspeed;
	}
	
	public void setXmax(double x_max){
		this.max_x = x_max;
	}
	
	public double getXmax(){
		return max_x;
	}
	
	public void setYmax(double y_max){
		this.max_y = y_max;
	}
	
	public double getYmax(){
		return max_y;
	}
	
	public void update(double speedy){
		double i = -0.8;
		yspeed = yspeed+speedy;
		
		
		
		if(y > max_y || y < 0){
			yspeed = yspeed*i;
		}
		y = y + yspeed;
		
		if(x > max_x || x < 0){
			xspeed = xspeed*i;
		}
		x = x + xspeed;
	}
}
