package com.example.animationgamev2;

import java.util.Random;

public class Ball {
	double x;
	double y;
	double xspeed;
	double yspeed;
	double max_x;
	double max_y;
	int radius;
	Random rdm=new Random();
	
	public Ball(Integer x, Integer y, Integer xspeed, Integer yspeed, Integer max_x,
			Integer max_y,int radius) {
		this.x = x.doubleValue();
		this.y = y.doubleValue();
		this.xspeed = xspeed.doubleValue();
		this.yspeed = yspeed.doubleValue();
		this.max_x = max_x-radius;
		this.max_y = max_y-radius;
		this.radius=radius;
	}
	
	public void update(double accel){
		if(y>=max_y){
			if((int)yspeed!=0){
				yspeed*=-0.8;
				y=max_y;
			}
		}
		
		if(y<=radius){
			yspeed*=-0.8;
			y=radius;
		}
		
		if(y<=max_y && y>=radius){
			yspeed+=accel;
			y+=yspeed;
		}
		
		//X values
		
		if(x>=max_x){
			if(xspeed>=0){
				xspeed*=-0.8;
				x=max_x;
			}
		}
		
		if(x<=radius){
			xspeed*=-0.8;
			x=radius;
		}
		
		if(x<=max_x && x>=radius){
				x+=xspeed;
		}
		
	}
	
	public void goCrazy(int accelXm,int accelYm){
		if((int)yspeed==0){
			yspeed=rdm.nextInt(100);
			xspeed=rdm.nextInt(100);
		}
		this.xspeed*=accelXm;
		this.yspeed*=accelYm;
	}
	
	
}
