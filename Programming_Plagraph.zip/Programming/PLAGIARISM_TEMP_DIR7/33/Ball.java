package com.example.lab6;

public class Ball {
	double x,y,x_speed,y_speed,x_max,y_max;
	
	
	public Ball(double xIn,double yIn, double xSpeed, double ySpeed, double xMax, double yMax )
	{
		x =xIn;
		y = yIn;
		x_speed = xSpeed;
		y_speed = ySpeed;
		x_max = xMax;
		y_max = yMax;
	}
	
	public void update(double yAcc)
	{
		if ( y >= y_max || y <= 0)
		{
			y_speed = y_speed*(-0.8);
			x_speed = x_speed*(0.8);
			y = y_max;
		}
		if (x >= x_max)
		{
			x_speed = x_speed*(-0.8);
			x = x_max;
		}
		if (x <= 0)
		{
			x_speed = x_speed*(-0.8);
			x = 0;
		}
		y_speed += yAcc;
		y += y_speed;
		x += x_speed;
	
	}
}
