package com.example.animationgame;

public class Ball {

	double x, y;
	double xspeed, yspeed;
	double max_x, max_y;
	
	public Ball(int x, int y, int xspeed, int yspeed, int max_x, int max_y) {
		super();
		this.x = x;
		this.y = y;
		this.xspeed = xspeed;
		this.yspeed = yspeed;
		this.max_x = max_x;
		this.max_y = max_y;
	}
	
	public void update(double increase)
	{
		
		yspeed+=increase;
		
		x += xspeed;
		y += yspeed;
		
		if (x >= max_x || x <= 0) {
			xspeed*=-0.8;
			x = (x <= 0) ? 0 : max_x; // edge hit ! set x-value to appropriate edge to get around the jiggly-ball problem
		}
		if (y >= max_y || y <= 0) {
			yspeed*=-0.8;
			y = (y <= 0) ? 0 : max_y; // edge hit ! set y-value to appropriate edge to get around the jiggly-ball problem
		}

	}
	
}
