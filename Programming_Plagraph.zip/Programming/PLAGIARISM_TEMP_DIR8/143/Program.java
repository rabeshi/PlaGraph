import java.util.ArrayList;
import java.util.Scanner;


public class Program {
	public static void main(String args[]){
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		Scanner in = new Scanner(System.in);
		String Laura;
		String [] h;
		Laura = in.nextLine();
		while(!Laura.equals("-1"))
		{
			h = Laura.split(";");
			allRatings.add(new Rating(h[0],Integer.parseInt(h[1])));
			Laura = in.nextLine();
			
		}
		System.out.println(getAverage(allRatings));
	}
	public static double getAverage(ArrayList<Rating> allRatings){
		double sum=0;
		double average;
		//ArrayList<Rating>allRatingsL = new ArrayList<Rating>();
		for(int i=0;i<allRatings.size();i++)
		{
			Rating s = allRatings.get(i);
			sum = sum + s.getScore();
		}
		average = sum/allRatings.size();

		return average;
	}
}

