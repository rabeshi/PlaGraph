import java.util.ArrayList;
import java.util.Scanner;


public class Program {
	public double getAverage(ArrayList<Rating> v){
		int size = v.size();
		double sum =0;
		
		for (int i =0;i<size;i++){
			sum += v.get(i).getScore();
		}
		
		return(sum/size);
	}
	public static void main(String args[]){
		ArrayList<Rating> arrRate = new ArrayList<Rating>(); 
		
		Scanner in = new Scanner(System.in);
		
		String next = in.nextLine();
		String str[];
		int iScore =0;
		Rating r;
		
		Program p = new Program();
		
		while(next.equals("-1") != true){
			str = next.split(";");
			iScore = Integer.parseInt(str[1]);
			r = new Rating(str[0],iScore);
			arrRate.add(r);
			next = in.nextLine();
		}
		
		double ave = p.getAverage(arrRate);
		System.out.println(ave);
		
	}
}
