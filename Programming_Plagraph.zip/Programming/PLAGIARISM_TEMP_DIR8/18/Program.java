import java.util.*;
import java.util.Scanner;
public class Program{

	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		ArrayList<Rating> allratings = new ArrayList<Rating>();

		String input = in.nextLine();
		while (!input.equals("-1")){
		String str = input;
		String[] vals = str.split(";");
		allratings.add(new Rating(vals[0],Integer.parseInt(vals[1])));
input = in.nextLine();
				}
System.out.println(getAverage(allratings));
		}
	public static double getAverage(ArrayList<Rating> v){
		double average =0, total=0;
		for(int i = 0;i<v.size();i++){
			total = total +v.get(i).getScore();
		}
		average = total/v.size();
		return average;
	}
}

 
