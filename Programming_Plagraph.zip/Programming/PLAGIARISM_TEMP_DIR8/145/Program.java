import java.util.ArrayList;
import java.util.Scanner;


public class Program {
	public double getAverage(ArrayList<Rating> v) {
		
		double sum = 0;
		for (int s = 0; s < v.size(); s++) {
			
			Rating movie = v.get(s);
			double rate = movie.getScore();
			sum = sum + rate;
			
		}			
		double average = sum / v.size();
		return average;
	}

public static void main(String[] args) {
	ArrayList<Rating> allRatings = new ArrayList<Rating>();
	Scanner in = new Scanner(System.in);
	String list = in.nextLine();
	
	while(list != "-1"){
		String[] vals = list.split(";");
		int x = Integer.parseInt(vals[1]);
		Rating show = new Rating(vals[0],x);
		allRatings.add(show);
		list = in.nextLine();
		if(list.equals("-1")){
			break;
		}
	}
	
	Program d =new Program();
	System.out.println(d.getAverage(allRatings));
	}
}
