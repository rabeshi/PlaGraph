import java.util.ArrayList;
import java.util.Scanner;


public class Program {
    ArrayList<Rating> allRatings = new ArrayList<Rating>();
	
	public double getAverage(ArrayList<Rating> v) {
		double sum = 0;
		for(Rating r: allRatings) sum+=r.getScore();
		return(sum/allRatings.size());
	}

	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String s = in.nextLine();
		String[] a;
		Program p = new Program();
		while(!s.equals("-1")) {
			a = s.trim().split(";");
			p.allRatings.add(new Rating(a[0],Integer.parseInt(a[1])));
			s = in.nextLine();
		}
		System.out.println(p.getAverage(p.allRatings));
		in.close();
	}
}
