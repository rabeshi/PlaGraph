import java.util.ArrayList;
import java.util.Scanner;

public class Program {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String text = in.nextLine();
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		//Gets Index of ";" from getIndexes and stores in index1/2.
		int index1 = 0;
		int index2 = 0;
		while (!text.equals("-1")) {
			index1 = getIndexes(text)[0];
			index2 = getIndexes(text)[1];
			allRatings.add(new Rating(text.substring(0, index1), Double
					.parseDouble(text.substring(index2))));
			text = in.nextLine();
		}
		System.out.println(getAverage(allRatings));
		in.close();
	}

	public static double getAverage(ArrayList<Rating> v) {
		double sum = 0;
		for (int i = 0; i < v.size(); i++) {
			sum += v.get(i).getScore();
		}
		return sum / v.size();
	}

	public static int[] getIndexes(String numbers) {
		int index1 = -1;
		int index2 = -1;
		for (int i = numbers.length() - 1; i > 0; i--) {
			if (index1 < 0) {
				if (numbers.charAt(i) >= '0' && numbers.charAt(i) <= '9') {
					index1 = i + 1;
				}
			}
			if (index2 < 0) {
				if (numbers.charAt(i) == ';') {
					index2 = i + 1;
				}
			}
		}
		int[] indexes = { index2 - 1, index2 };
		return indexes;
	}
}
