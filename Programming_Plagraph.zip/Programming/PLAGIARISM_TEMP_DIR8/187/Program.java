import java.util.*;


class Rating{
	private String userName;
	private int score;
	
	Rating(String userName,int score){
		this.userName=userName;
		this.score=score;
	}
	
	void setUsername(String userName){
		this.userName=userName;
	}

	String getUsername(){
		return userName;
		
	}

	void setScore(int score){
		this.score=score;
	}
	int getScore(){
		return score;
	}
}
	
public class Program{
	
	static ArrayList<Rating> allRatings=new ArrayList<Rating>();
	
	static public double getAverage(ArrayList<Rating> v){
		double avg=0;
		for(int i=0;i<v.size();i++){
			avg+=v.get(i).getScore()/((double) v.size());
		}
		return avg;
	}
	
	static public void main(String[] args){
		Scanner in=new Scanner(System.in);
		String input;
		String[] inArray=new String[2];
		input=in.nextLine();
		
		while(input.equals("-1")==false){
			
			inArray=input.split(";");
			allRatings.add(new Rating(inArray[0],Integer.parseInt(inArray[1])));
			input=in.nextLine();
			
		}
		System.out.println(getAverage(allRatings));
		
		
	}
}








