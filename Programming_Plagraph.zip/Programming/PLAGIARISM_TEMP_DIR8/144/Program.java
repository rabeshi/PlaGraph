import java.util.*;

public class Program {

	public static void main(String[] args) {
		
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		Program prog = new Program();
		Rating temp = new Rating(null, 0);
		int i=0;
		Scanner in = new Scanner(System.in);
		String input = in.nextLine();
		while(!input.equals("-1")){
			String[] vals = input.split(";");
			temp.setUserName(vals[0]);
			int score = Integer.parseInt(vals[1]);
			temp.setScore(score);
			allRatings.add(temp);
			input = in.nextLine();
			i++;
		}
		System.out.println(prog.getAverage(allRatings));
		
		
	}
	public double getAverage(ArrayList<Rating> v){
		
		double total=0;
		double n =0;
		double average;
		
		for(int i=0; i<v.size(); i++){
			total += v.get(i).getScore();
			n += 1;
		}
		
		average = total/n;
		return average;
	}

}
