import java.util.ArrayList;
import java.util.Scanner;

public class Program{
	



	public static double getAverage(ArrayList<Rating> v){
		double sum = 0;
		double average = 0;
		int counter = 0;
		
		for(int i = 0;i<v.size();i++){
		sum+=v.get(i).rating;
		counter++;
		}
		average = sum/counter;
		//System.out.println(counter);
		//System.out.println(sum);
		//System.out.println(average);
		return average;
		
	}



public static void main(String args[]){

	ArrayList<Rating> allratings = new ArrayList<Rating>();
	String s;
	String[] arr;
	Scanner hloni = new Scanner(System.in);
	s = hloni.nextLine();
	
	while(!s.equals("-1")){
		
		arr = s.split(";");
		//rate.setUsername(arr[0]);
		//rate.setScore();
		Rating rate = new Rating(arr[0],Integer.parseInt(arr[1]));
		allratings.add(rate);
		s = hloni.nextLine();
		
	};

	 getAverage(allratings);
	 hloni.close();
}	
}