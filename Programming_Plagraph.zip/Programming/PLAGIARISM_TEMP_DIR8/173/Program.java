import java.util.ArrayList;
import java.util.Scanner;


public class Program {
	Rating temp;
	int count =0;
	double total =0;
	ArrayList<Rating> allRatings = new ArrayList<Rating>();
	public double getAverage(ArrayList<Rating> v){
		for (int i = 0; i< v.size(); i++) {
		total =	total + v.get(i).score;
		count = count +1;	
		}
		total = total/count;
		return (total);
	}
	public static void main(String arg[]){
		Scanner in = new Scanner(System.in);
		String temp1 ="";
		int tmp =0;
		Program p = new Program();
		
		temp1 =  in.nextLine();
		while (!temp1.equals("-1")){
			String str = temp1;
			String[] vals = str.split(";");
			tmp = Integer.parseInt(vals[1]);
			p.allRatings.add(new Rating(vals[0], tmp));
			temp1 = in.nextLine();
		}
		System.out.println(p.getAverage(p.allRatings)); 
	}
}
