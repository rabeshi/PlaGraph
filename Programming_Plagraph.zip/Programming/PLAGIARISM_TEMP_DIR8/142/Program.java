import java.util.ArrayList;
import java.util.Scanner;


public class Program {
public static double getAverage(ArrayList<Rating> v) {
		
		double sum = 0;
		for (int i = 0; i < v.size(); i++) {
			Rating sam = v.get(i);
			double score = sam.getScore();
			sum = sum + score;
		}
			
		double ave = sum / v.size();
		return ave;
	}
	
	public static void main(String[] args) {
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		Scanner in = new Scanner(System.in);
		String y = in.nextLine();
		
		while(!y.equals("-1")){
			String[] vals = y.split(";");
			int x = Integer.parseInt(vals[1]);
			Rating sm = new Rating(vals[0],x);
			allRatings.add(sm);
			y = in.nextLine();
		}
		
		Program d =new Program();
		System.out.println(d.getAverage(allRatings));
		
		
		
	}

}
