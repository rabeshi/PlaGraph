import java.util.ArrayList;
import java.util.Scanner;
public class Program {

	public static double getAverage(ArrayList<Rating> v){
	int sum=0;
		
	for(int i=0; i<v.size(); i++ ){
	sum =v.get(i).score + sum;
	
	}
	return(double) sum/v.size();	
	}
	public static void main(String args[]){
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		String s;
		Scanner in = new Scanner(System.in);
		s=in.nextLine();
		while(s.equals("-1") == false){
			String[] str= s.split(";");
			int scor =Integer.parseInt(str[1]);
			Rating r=new Rating(str[0] , scor);
			allRatings.add(r);  
			s=in.nextLine();
		}
		
	System.out.print(getAverage(allRatings));
	
	}
	
	
}
