import java.util.ArrayList;
import java.util.Scanner;

public class Program {
	
	public static void main (String [] args){
		Program p = new Program();
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		Scanner sc = new Scanner (System.in);
		
		String input = sc.next();
		int score;
		Rating x;
		while (!(input.equals("-1"))){
			String[] in = input.split(";");
			score = Integer.parseInt(in[1]);
			x = new Rating(in[0],score);
			allRatings.add(x);
			input = sc.next();
		}
		System.out.println(p.getAverage(allRatings));
		sc.close();
	}
	
	public double getAverage (ArrayList<Rating> v){
		double tempTotal = 0;
		for (int i = 0; i < v.size(); i++){
			tempTotal += v.get(i).getScore();
		}
		return tempTotal/v.size();
	}
}
