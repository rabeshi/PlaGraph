import java.util.ArrayList;
import java.util.Scanner;

public class Program {
	
	public static void main(String[] args)
	{
		String sScore = "";
		double score = 0;
		double average=0;
		String username = "";
		
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		
		Scanner in = new Scanner(System.in);
		String str = in.nextLine();

		String[] vals = new String[2];
		vals = str.split(";");
		username = vals[0];
		
		while(username.equals("-1")==false)
		{	
			
			sScore = vals[1];
			score = Double.parseDouble(sScore);
			Rating info = new Rating(username, score);
			allRatings.add(info);
			
			str = in.nextLine();
			vals = str.split(";");
			username = vals[0];
				
		}
		average = getAverage(allRatings);
		System.out.print(average);
	}
	
	public static double getAverage(ArrayList<Rating> v)
	{
		double sum=0;
		int x=0;
		int size = v.size();
		
		while(x<size)
		{
		
			sum = sum + v.get(x).getScore();
			++x;
		}
		
		double average = sum / x;
		
		return average;
		
	}

}
