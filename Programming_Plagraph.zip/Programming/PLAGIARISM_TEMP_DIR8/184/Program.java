import java.util.ArrayList;
import java.util.Scanner;

public class Program {
	//
	
	public static double getAverage(ArrayList<Rating> v){
		double sum=0;
				
		for(int i=0;i<v.size();i++){
			sum+=v.get(i).getScore();
			
		}
		sum=sum/v.size();
	return sum;	
	}
	public static void main(String []args){
		ArrayList<Rating> allRating=new ArrayList<Rating>();
		Scanner in=new Scanner(System.in);
		String temp1 = in.nextLine();
		
		
		while(!temp1.equals("-1")){
			
			String[] temp = temp1.split(";");
			int dum=Integer.parseInt(temp[1]);
			Rating obj=new Rating(temp[0],dum);
			allRating.add(obj);
			temp1=in.nextLine();
		}
		
		System.out.println(getAverage(allRating));
	}
}
