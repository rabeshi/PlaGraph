import java.util.ArrayList;
import java.util.Scanner;

public class Program
{
    ArrayList<Rating> allRatings = new ArrayList<Rating>();

    public double getAverage(ArrayList<Rating> v)
    {
        double total = 0.0;
        for (Rating i : v)
            total += i.getScore();

        return total / v.size();
    }

    public static void main(String args[])
    {
        Scanner in = new Scanner(System.in);

        Program myRating = new Program();

        while (true)
        {
            String line = in.nextLine();

            if (line.equalsIgnoreCase("-1"))
                break;

            myRating.allRatings.add(new Rating(line.split(";")[0], Integer.parseInt(line.split(";")[1])));
        }

        in.close();

        System.out.println(myRating.getAverage(myRating.allRatings));
    }
}
