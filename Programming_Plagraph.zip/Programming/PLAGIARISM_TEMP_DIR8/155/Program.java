import java.util.ArrayList;
import java.util.Scanner;

public class Program {
	ArrayList<Rating> allRating = new ArrayList<Rating>();
	public double getAverage(ArrayList<Rating> v) {
		double average = 0;
		for (int i = 0; i < v.size(); i++) {
			average=average + v.get(i).getScore();
		}
		average=average/(v.size());
		return (average);
	}
	public static void main(String args[])
	{
		Program p = new Program();
		p.Add();
		System.out.println(p.getAverage(p.allRating));
	}
	public void Add()
	{
		Scanner in =new Scanner(System.in);
		String i = in.next();
		while(!i.equals("-1"))
		{
        String[] vals = i.split(";");
        Rating m=new Rating(vals[0],Integer.parseInt(vals[1]));
        allRating.add(m);
	    i = in.next();
		}
	}
}
