import java.util.ArrayList;
import java.util.Scanner;


public class Program {
	ArrayList<Rating> allRatings;
	
	public static void main(String args[]){
		Program Pro = new Program();
		Pro.allRatings = new ArrayList<Rating>();
		int counter = 0;
		Scanner in = new Scanner(System.in);
		String a = in.nextLine();
		while (a.startsWith("-") == false){
			Rating rat = new Rating("",0);
			int n = a.indexOf(";");
			String b = a.substring(0, n-1);
			String c = a.substring(n+1);
			int d = Integer.parseInt(c);
			rat.setUsername(b);
			rat.setScore(d);
			Pro.allRatings.add(counter,rat);
			counter = counter + 1;
			a = in.nextLine();
		}
		double r = Pro.getAverage(Pro.allRatings);
		System.out.println(r);
		in.close();
	}
	
	public double getAverage(ArrayList<Rating> v){
		double sum = 0;
		int icount = 0;
		Rating[] arr = new Rating[v.size()];
		for (int i = 0; i < v.size(); i++){
			arr[i] = new Rating("",0);
			arr[i].score = v.get(i).score;
			arr[i].username = v.get(i).username;
			sum = sum + arr[i].score;
			icount = icount + 1;
		}
		double avgr = sum/icount;
		return avgr;
	}
}