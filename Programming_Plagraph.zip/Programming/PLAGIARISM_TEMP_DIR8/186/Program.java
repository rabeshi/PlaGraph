import java.util.*;

public class Program
{
	public static void main(String[] args)
	{
		ArrayList<Rating> allRatings = new ArrayList<Rating>();

		Scanner stdin = new Scanner(System.in);
		
		String input;
		
		input = stdin.nextLine();
		
		while(!input.equals("-1"))
		{
			String[] array = input.split(";");
			
			//System.out.println(array[0]);
			//System.out.println(array[1]);
			
			String username = array[0];
			int score = Integer.parseInt(array[1]);
			
			//Rating aRating = new Rating(username, score);
			allRatings.add(new Rating(username,score));
			
			input = stdin.nextLine();

		}
		
		Program a = new Program();
		System.out.println(a.getAverage(allRatings));
	}

	public double getAverage(ArrayList<Rating> v)
	{
		double total=0, average;
			//int count=0;
	
		for(Rating i: v)
		{
	    total = total + i.getScore();
		//count = count +1;
		}
	
		average = total / (double) v.size();
	
		return average;
	}
}
