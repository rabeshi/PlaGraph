import java.util.Scanner;
import java.util.ArrayList;
import java.util.*;
public class Program {
	ArrayList<Rating> allRatings = new ArrayList<Rating>();
	
	public double getAverage(ArrayList<Rating> v){
		double sum = 0;
		double avarege;
		for(int i = 0;i <v.size();i++){
			sum = sum + v.get(i).score;
		}
		avarege = sum/v.size();
		return avarege;
	}
	
public static void main(String [] args){
   Program newPro= new Program();
   Scanner in = new Scanner(System.in);
   String surname= in.nextLine();
   while(!surname.equals("-1")){
	 //surname = in.nextLine();
	String []  h = surname.split(";");
	int send = Integer.parseInt(h[1]);
	Rating newR = new Rating(h[0],send);
	newPro.allRatings.add(newR);
	surname=in.nextLine();
   }
   System.out.println(newPro.getAverage(newPro.allRatings));
  
	
}

}
