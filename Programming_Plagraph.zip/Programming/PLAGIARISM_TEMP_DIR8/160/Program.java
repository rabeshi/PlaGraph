import java.util.ArrayList;
import java.util.Scanner;


public class Program {
	public static double getAverage(ArrayList<Rating> v)
	{
		int sum= 0;
	for (int i=0; i< v.size(); i++)
	{
		sum+=v.get(i).score;
	}
	return (double)sum/v.size();
	}
	public static void main(String args[])
	{
		//@SuppressWarnings("resource")
		Scanner in = new Scanner(System.in);
		ArrayList<Rating> myRatings= new ArrayList<Rating>();
		String h= in.nextLine();
		while (h.equals("-1")==false)
		{
			String[] dummy= h.split(";");
			Rating newRating= new Rating(dummy[0],Integer.parseInt(dummy[1]));
			myRatings.add(newRating);
			h= in.nextLine();
		}
		System.out.println(getAverage(myRatings));
		
	}

}
