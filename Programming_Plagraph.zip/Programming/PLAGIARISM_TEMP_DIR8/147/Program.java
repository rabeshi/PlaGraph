import java.util.*;
import java.util.Scanner;
public class Program{

	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		ArrayList<Rating> allratings = new ArrayList<Rating>();

		String x = in.nextLine();
		while (!x.equals("-1")){
		String str = x;
		String[] y = str.split(";");
		allratings.add(new Rating(y[0],Integer.parseInt(y[1])));
                x = in.nextLine();
				}
             System.out.println(getAverage(allratings));
		}

	public static double getAverage(ArrayList<Rating> v){
		double average =0, sum=0;
		for(int i = 0;i<v.size();i++){
			sum = sum +v.get(i).getScore();
		}
		average = sum/v.size();
		return average;
	}
}

 
