import java.util.ArrayList;
import java.util.Scanner;


public class Program {

	public static void main(String args[])
	{
		
		Scanner in = new Scanner(System.in);
		String line;
		
		ArrayList<Rating> allRatings = new ArrayList();
		while (!(line = in.nextLine()).equals("-1"))
		{
			String username = line.split(";")[0];
			int userscore = Integer.parseInt(line.split(";")[1]);
			allRatings.add(new Rating(username,userscore));
		}

		System.out.println(new Program().getAverage(allRatings));
	}
	
	
	public double getAverage(ArrayList<Rating> v)
	{
		int count = 0;
		double score_total = 0.00;
		
		for (Rating each : v)
		{
			score_total += each.getScore();
			count++;
		}
		
		return score_total/count;
	}
	
}
