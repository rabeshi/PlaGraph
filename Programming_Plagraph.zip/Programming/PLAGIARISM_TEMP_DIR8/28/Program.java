import java.util.*;

public class Program {
	
   
 public static void main(String[]args){
	  
	  ArrayList<Rating> allRatings =new ArrayList<Rating>();
	   Scanner in= new Scanner(System.in);
	   
	   String str =in.nextLine();
	   
	   while(!str.equals("-1")){
		   
		   String [] entries =str.split(";");
		   String name = entries[0];
		   int age = Integer.parseInt(entries[1]);
		   
		   Rating myRating =new Rating(name,age);
		   allRatings.add(myRating);
		   
		   str =in.nextLine();
	   }
	   
	
	   
	   Program myProgram =new Program();
	   
	 System.out.println(myProgram.getAverage(allRatings));
	   
   }
  
  public  double getAverage(ArrayList<Rating> v){ 
	  double average;
	  double sum = 0;
	  
	  for(Rating i : v)
		  sum =sum + i.getScore();
	  
	  average = sum /v.size();
	
	  return average;
   }

}
