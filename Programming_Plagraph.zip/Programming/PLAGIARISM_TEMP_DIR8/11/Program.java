import java.util.ArrayList;
import java.util.Scanner;


public class Program {
	public static void main(String args[]){
		ArrayList<Rating> allRatings = new ArrayList<Rating>(10);
		Scanner in = new Scanner(System.in);
		String s;
		String[] spl;
		int score;
		s = in.next();
		while(!s.equals("-1")){
			spl = s.split(";");
			score = Integer.parseInt(spl[1]);
			allRatings.add(new Rating(spl[0],score));
			s = in.next();
			
		}
		
		System.out.println(getAverage(allRatings));
	}
	
	public static double getAverage(ArrayList<Rating> v){
		double ave = 0;
		int count = 0;
		for(int i = 0;i < v.size();i++){
			ave = ave + v.get(i).getScore();
			count ++;
		}
		ave = ave/count;
		return ave;
	}


}
