
import java.util.*;

public class Program {

	public double getAverage(ArrayList<Rating> v){
		double sum = 0, ave;
		for(int count = 0; count < v.size(); count++){
			sum += v.get(count).getScore();
		}
			ave = sum/v.size();
			return ave;
	}
	public static void main(String args [])
	{
ArrayList<Rating> allRatings = new ArrayList<Rating>();
		
		
		String input;
		
		Scanner in = new Scanner(System.in);
		
		input = in.nextLine();
		
		while( ! input.equals("-1"))
		{
			String[] vals = input.split(";");
			
			Rating r = new Rating (vals[0],Integer.parseInt(vals[1]));
			
			allRatings.add( r );

			input = in.nextLine();

		}
		
		Program Average = new Program();
		
		System.out.println( Average.getAverage(allRatings));
			
	}
	}
