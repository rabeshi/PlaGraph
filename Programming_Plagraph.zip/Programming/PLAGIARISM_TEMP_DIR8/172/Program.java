import java.util.Scanner;
import java.util.*;
import java.util.ArrayList;
public class Program {
	

	ArrayList<Rating> allRatings = new ArrayList<Rating>();
	
	public double getAverage(ArrayList<Rating> v){
		double sum = 0;
		double avarege;
		for(int i = 0;i <v.size();i++){
			sum = sum + v.get(i).score;
		}
		avarege = sum/v.size();
		return avarege;
	}
	
		public static void main(String [] args){
		 Program monde = new Program();
		   Scanner in = new Scanner(System.in);
		   String a= in.nextLine();
		   while(!a.equals("-1")){
			 //surname = in.nextLine();
			String []  h = a.split(";");
			int s = Integer.parseInt(h[1]);
			String p  = h[0];
			Rating hlela = new Rating(p,s);
			monde.allRatings.add(hlela);
			a=in.nextLine();
		   }
		   System.out.println(monde.getAverage(monde.allRatings));
		  
			
		}
	}

		
