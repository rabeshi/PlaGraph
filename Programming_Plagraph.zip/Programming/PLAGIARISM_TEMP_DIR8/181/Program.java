


import java.util.*;

public class Program {	
			
		
		public static void main(String args[]){
			
			
		
			Scanner in = new Scanner(System.in) ;
		
			String sinput = in.nextLine() ;
			int Count = 0;
		
			ArrayList<Rating> allRatings = new ArrayList<Rating>();
			while(!(sinput.equals("-1")))
			{
				
				String[] val  = sinput.split(";") ;
			   
			  
				allRatings.add(new Rating(val[0],Integer.parseInt(val[1]))) ;
				Count++ ;
				
				sinput = in.nextLine() ;
				
				
			}
	
			System.out.println(getAverage(allRatings)) ;
		
			
			}
		
		
		public static  double getAverage(ArrayList<Rating> v){
			double Rating = 0 ;
			
			for(int x=0 ; x<v.size() ; x++)
			{
				Rating = Rating + v.get(x).getScore() ;
			
				
				                    
			}
			double Avg = Rating/(v.size()); 
			return Avg ;
			
			
		}
		

}

