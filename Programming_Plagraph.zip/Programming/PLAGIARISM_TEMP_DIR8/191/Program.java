import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Scanner;

import android.media.Rating;

public class Program{
public static void main(String[] args) throws IOException {
		Program program = new Program(); //Calling a non static method in a static method need an object.
	
		int score = 0, totalScore = 0, count = 0;
		String userName = null;
		double avg = 0;
		Scanner in = new Scanner(System.in);
		String userNameScore = in.next();
		int p = -1;
		String c = ""+p;
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		while(!userNameScore.equalsIgnoreCase(c))
		{
			//check if input is valid
			if(userNameScore.contains(";"))
			{
				userName = userNameScore.substring(0, userNameScore.indexOf(";"));
				score = Integer.parseInt(userNameScore.substring(userNameScore.indexOf(";")+1, userNameScore.length()));
				
				Rating rating = new Rating();
				allRatings.add(rating);
			}
			userNameScore = in.next();
		}
		DecimalFormat df = new DecimalFormat("#.##");
		
	System.out.println(df.format(((Program) program).getAverage(allRatings)));
	}
}

