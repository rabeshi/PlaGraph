import java.util.ArrayList;
import java.util.Scanner;

public class Program{
	
	
	static ArrayList<Rating>allRatings = new ArrayList<Rating>();
	
	public static double getAverage(ArrayList<Rating> v){
		
		double sum = 0;
		int count = 0;
		
		for(int i = 0 ; i < v.size() ; i++){
			
			sum = sum + (v.get(i).getScore());
			count++;
			
		}
		
		double average = sum/count;
		
		return average;
		
	}
	
	public static void main(String args[]){
		
		Scanner input = new Scanner(System.in);
		String stuff = input.next();
		
		while(!stuff.equals("-1")){
			
			String[] vals = stuff.split(";");
			
			int score = Integer.parseInt(vals[1]);
			
			Rating person = new Rating(vals[0],score);
			
			allRatings.add(person);
			
			stuff = input.next();
		}
		
		
		//Rating person = new Rating("Megan", 50);
		//Rating person1 = new Rating("Luyanda", 0);
		
			
		//allRatings.add(person);
		
		System.out.println(getAverage(allRatings));
		
	}
	

}

