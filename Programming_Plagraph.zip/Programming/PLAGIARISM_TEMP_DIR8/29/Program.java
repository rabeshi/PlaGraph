import java.util.Scanner;
import java.util.*;


public class Program {
	
	public static double getAverage(ArrayList<Rating> v){
		double ave = 0;
		for (int i = 0 ; i < v.size() ; i++ ){
			ave = ave + v.get(i).score;
		}
		ave = ave/v.size();
		return ave;
	}
	
	public static void main(String[] args) {
	
		ArrayList<Rating> data = new ArrayList<Rating>();	
		Scanner in = new Scanner (System.in);
		int sum = 0;
		String dataSet = in.next();
		while (!dataSet.equals("-1")){
			
			String[] dataInd = dataSet.split(";");
			data.add(new Rating(dataInd[0] , Integer.parseInt(dataInd[1])));
			dataSet = in.next();
			
		}
		System.out.print(getAverage(data));
		
		
		
		
		//Rating []rateArray = new Rating[10];
		
//	Scanner in = new Scanner (System.in);
//	Dog []dogArray = new Dog[5];
//	for (int i = 0 ; i<5 ; i++){
//		String name = in.nextLine();
//		String ageSt = in.nextLine();
//		int age = Integer.parseInt(ageSt);
//		//dogArray[i] = new Dog (in.next(), in.nextInt());
//		dogArray[i] = new Dog(name,age);
//	}
//	for (int i = 0; i<5 ;i++){
//		dogArray[i].bark();
//	}
		//Rating myRating = new Rating("movieguy87", 7);
	
		
//		Scanner in = new Scanner (System.in);
//		//int arraySize = in.nextInt();
//		String []blabla = new String[10];
//		//int []numbers = new int[10];
//		for (int index = 0 ; index < 10 ; index++){
//			blabla[index] = in.nextLine(); 
//		}
//		for (int index = 9 ; index >= 0 ; index--){
//			System.out.println(blabla[index]);
//		}
	}

}
