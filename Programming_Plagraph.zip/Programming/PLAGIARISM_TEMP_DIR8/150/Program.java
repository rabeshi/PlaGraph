import java.util.ArrayList;
import java.util.Scanner;


public class Program {	
	public static double getAverage(ArrayList<Rating>v){
	double total=0;		
double count = 0;
		
	for(int i=0;i< v.size();i++){
		total = total + v.get(i).getScore();
			count++;	
		}		
double average = total/count;		
return average;
	}
	
	public static void main (String [] args){	
	ArrayList<Rating> allRating = new ArrayList<Rating>();		
  Scanner in = new Scanner(System.in);		
    String insert = in.nextLine();		
		
    while(!insert.equals("-1")){			
    	String[] vals = insert.split(";");			
    		int rate = Integer.parseInt(vals[1]);	
    		Rating myRating = new Rating(vals[0],rate);			
    			allRating.add(myRating);			
    				insert = in.nextLine();
		
	}
    	System.out.println(getAverage(allRating));	
	}
	
}
