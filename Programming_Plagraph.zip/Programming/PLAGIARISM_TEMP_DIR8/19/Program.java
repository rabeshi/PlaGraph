import java.util.*;

public class Program {
	
	public static double getAverage(ArrayList<Rating> v){
		double total =0;
		for(int i=0;i<v.size();i++){
			total+=v.get(i).getScore();
		}
		return total/v.size();
	}
	
	public static void main(String [] args){
		ArrayList<Rating> allRating = new ArrayList<Rating>();
		Scanner in = new Scanner(System.in);
		String [] p;
		String user;
		do{
			user = in.nextLine();
			p = user.split(";");
			if(!user.equals("-1"))
			allRating.add(new Rating(p[0],Integer.parseInt(p[1])));
			
		}while(!user.equals("-1"));
		in.close();
		System.out.print(getAverage(allRating));
	}
}
