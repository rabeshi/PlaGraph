import java.util.ArrayList;
import java.util.Scanner;


public class Program {
	public static double getAverage(ArrayList<Rating> v) {
		double s = 0;
		for (int i = 0; i < v.size(); i++) {
			s = s + v.get(i).score;
		}
		double k = s / v.size();
		return k;
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		String f = in.nextLine();
		String[] l;
		int r;
		while (!f.equals("-1")) {
			l = f.split(";");
			r = Integer.parseInt(l[1]);
			Rating ha = new Rating(l[0], r);
			allRatings.add(ha);
			f = in.nextLine();
		}
		in.close();
		System.out.print(getAverage(allRatings));
	}
}
