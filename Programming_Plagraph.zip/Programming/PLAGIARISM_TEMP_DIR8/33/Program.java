import java.io.IOException;
import java.io.ObjectInputStream.GetField;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Program

{
	private ArrayList<Rating> allRatings;
	/* arraylist is a data type */
	

	int score = 0, totalScore = 0;

	static int count = 0;
	static String userName = null;
	double avg = 0;
	public double getAverage(ArrayList<Rating> v) 
	{
		

		Iterator<Rating> it = v.iterator();
		while (it.hasNext()) {
			Rating rating = it.next();
			score = rating.getScore();
			userName = rating.getUsername();
			totalScore += score;
			count = count + 1;
			
		}

	avg = totalScore / count;
	return avg;

	}

	private String getUserName() {
	
		return null;
	}

	private int getScore() {
		
		return 0;
	}

	public static void main(String[] args) throws IOException
	

	{
		Rating rating = new Rating(userName, count); 
	
		int score = 0, totalScore = 0, count = 0;
		String userName = null;
		double avg = 0;
		Scanner in = new Scanner(System.in);
		String userNameScore = in.next();
		int p = -1;
		String c = ""+p;
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		while(!userNameScore.equalsIgnoreCase(c))
		{
			//check if input is valid
			if(userNameScore.contains(";"))
			{
				userName = userNameScore.substring(0, userNameScore.indexOf(";"));
				score = Integer.parseInt(userNameScore.substring(userNameScore.indexOf(";")+1, userNameScore.length()));
				
				Rating rating1 = new Rating(c, p);
				allRatings.add(rating1);
			}
			userNameScore = in.next();
		}
		DecimalFormat df = new DecimalFormat("#.##");
		
	System.out.println(df.format(rating.getAverage(allRatings)));
	}
}
