import java.util.*;
import java.util.Scanner;

public class Program {

	ArrayList<Rating> allRatings= new ArrayList<Rating>();
	
	public static double getAverage(ArrayList<Rating> v){
		double average;
		int size;
		double sum;
		sum=0;
		size=v.size();
		
		for(int i=0;i<size;i++){
			sum=sum + v.get(i).score;
		}
		average=sum/size;
		
		return average;
	}
	
	public static void main(String[] args) {
		Scanner in= new Scanner(System.in);
		Program g = new Program();
		String a = null;
		String x="-1";
		String b;
		int c;
		a=in.nextLine();
		while(!a.equals("-1")){


			
			String[] values= a.split(";");
			b=values[0];
			c = Integer.parseInt(values[1]);
			Rating o= new Rating(b,c);
			g.allRatings.add(o);
			a=in.nextLine();
		}
		
		System.out.println(g.getAverage(g.allRatings));

	}

}
