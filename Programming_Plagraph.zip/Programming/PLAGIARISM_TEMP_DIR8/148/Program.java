
import java.util.ArrayList;
import java.util.Scanner;


public class Program {
//tatic final String  QUIT = "-1";
	public static void main(String args[])
	{
		
		
		
		Scanner in = new Scanner(System.in);
		String nameEntered;
		int scoreEntered;
		
		ArrayList<Rating> allRating= new ArrayList<Rating>();
		 
		String theinput;
		theinput = in.nextLine();
		
		while (! theinput.equals("-1"))
		 {
		String[] values = theinput.split(";");
		//System.out.println(values[1]);
	    scoreEntered = Integer.parseInt(values[1]);
	    nameEntered = values[0];
	    Rating  myRating = new Rating(nameEntered, scoreEntered);
	    myRating.setUsername(nameEntered);
	    myRating.setScore(scoreEntered);
	     allRating.add(myRating);
	     theinput = in.nextLine();
		 } 
	  in.close();
	   Program inst = new Program();
	System.out.println(inst.getAverage(allRating));

		}
	
	
	
	public double getAverage(ArrayList<Rating> v )
	{
		double total=0.0;
		double average=0.0 ;
		 Rating  theRating = new Rating("woof", 1);
		for (int z = 0; z< v.size();z++)
		{
			theRating=v.get(z);
		    total =total + theRating.getScore();  
		}
	     
	      average = (double) average +(double)(total/v.size());
	      
	      return average;
	}
	      
	
}
