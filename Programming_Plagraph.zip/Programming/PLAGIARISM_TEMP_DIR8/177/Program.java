import java.util.ArrayList;
import java.util.Scanner;


public class Program {
	public static double getAverage(ArrayList<Rating> v){
		int sum = 0;
		int count = 0;
		for(Rating r: v){
			sum += r.getScore();
			count++;
		}
		return (double)sum/count;
	}
	public static void main(String args[]){
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		Scanner in = new Scanner(System.in);
		String line = in.nextLine();
		while (!line.equals("-1")){
			String[] vals = line.split(";");
			allRatings.add(new Rating(vals[0], Integer.parseInt(vals[1])));
			line = in.nextLine();
		}
		System.out.print(getAverage(allRatings));
	}

}
