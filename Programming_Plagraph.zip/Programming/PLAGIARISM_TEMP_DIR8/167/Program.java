import java.util.ArrayList;
import java.util.Scanner;


public class Program
{
	static ArrayList<Rating>allRatings = new ArrayList<Rating>();
	//static ArrayList<Rating>allRatings = new ArrayList<Rating>();
	
	public static double getAverage(ArrayList<Rating> v)
	{
		int size = v.size();
		int loop = 0;
		double sum = 0;
		double ave;
		while (loop < size)
		{
			sum = sum + (v.get(loop).getScore());	
			loop++;
		}
		ave = sum/size;
		return ave;
	}

	public static void main(String args[])
	{
		Scanner in = new Scanner(System.in);
		
		String user = in.next();
		int count = 0;
		int i = 0;
		String name;
		int score = 0;
		
		while (!user.equals("-1"))
		{
			
			String[] vals = user.split(";");
			name = vals[0];
			score = Integer.parseInt(vals[1]);
			allRatings.add(count, new Rating(name,score));
			
			user = in.next();
			count++;	
			
		}
		System.out.println(getAverage(allRatings));
	}

}