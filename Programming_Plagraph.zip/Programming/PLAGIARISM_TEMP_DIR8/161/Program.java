import java.io.ObjectInputStream.GetField;
import java.security.AllPermission;
import java.util.*;

public class Program {
	
	public static void main(String Args[]) {
		
		Scanner in = new Scanner(System.in);
		
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		
		String s;
		String sUserName;
		s = in.next();
		while (!s.equals("-1"))
		{
			
			String str = s;
			String[] vals = str.split(";");
			sUserName = vals[0];
			int iScore = Integer.parseInt(vals[1]);
			
			Rating r = new Rating(sUserName, iScore);
			allRatings.add(r);
			s = in.next();
		}
		
		System.out.println(getAverage(allRatings));
		
	}
	
	public static double getAverage(ArrayList<Rating> v){
		double total = 0;
		for (int i = 0; i < v.size(); i++) {
			Rating k = v.get(i);
			total = total + k.getScore();
		}
		double average = total/v.size();
		return average;
	}

}
