import java.util.ArrayList;
import java.util.Scanner;

public class Program { 
	public static void main(String[] args) {
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		Scanner in = new Scanner(System.in);
		String input = in.nextLine();
		while(!input.equals("-1")){
			String [] splitinput = input.split(";");
			allRatings.add(new Rating(splitinput[0],Integer.parseInt(splitinput[1])));
			input = in.nextLine();
		}
		System.out.println(getAverage(allRatings));
	}
	


	public static double getAverage(ArrayList<Rating> allRatings){
	double sum = 0;
	
	for(int i=0; i<allRatings.size(); i++){
		Rating temp = allRatings.get(i);
		sum = sum + temp.getScore();
	}
	double average = 0;
	average = sum/allRatings.size();
	
	return(average);
	}
}
