import java.util.ArrayList;
import java.util.Scanner;
//import


public class Program {
	
	public static void main(String arge[])
	{
		Program p = new Program();
		
		Scanner in = new Scanner(System.in);
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		
		String sLine;
		//String sUsername;
		//int iScore;
		int i ;
		
		//i = Integer.parseInt(in.nextLine());
		 sLine = in.nextLine();
		
		while (!(sLine.equals("-1")))
		{
			
			//sUsername = sLine.substring(0, sLine.indexOf(';')-1);
			//iScore = Integer.parseInt(sLine.substring(sLine.indexOf(';')+1, sLine.length()));
			String[] vals = sLine.split(";");
			allRatings.add(new Rating(vals[0], Integer.parseInt(vals[1])));
			sLine = in.nextLine();
		}
		
		double ave = p.getAverage(allRatings);
		System.out.println(ave);
		
	}
	
	public double getAverage(ArrayList<Rating> v)
	{
		double tot =0;
		
		for (int i=0; i< v.size(); i++)
		{
			tot += v.get(i).getScore();
		}
		
		return(tot/v.size());
	}

}
