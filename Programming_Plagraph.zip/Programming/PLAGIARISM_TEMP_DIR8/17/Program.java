/*import java.util.ArrayList;

import java.util.Scanner;

public class Program {
	
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		
		ArrayList<String> collection = new ArrayList<>();
		
		for (int i = 0; i >= 0; i++) {
			
			System.out.println(i);
			
			String line = in.nextLine();
			
			collection.add(line);
			
			if (line.equals("-1")) {
				
				break;
				
				}
			
			String lineSplit = line;
			
			String[] lineSplited = lineSplit.split(";");
						
			int rate = Integer.valueOf(lineSplited[1]);
			
			Rating myRating = new Rating(lineSplited[0], rate);
			
			
		
			
			System.out.println(line);
			
			
			
			}
		
		//char[] myRating = null;
		
		//System.out.println(myRating);
		
		in.close();
		
		}
	
	//public double getAverage(ArrayList<Rating> v) {
		
		//System.out.println(v);
		
		
		
		//return 0;
		
	//}
	
	}*/

import java.util.*;

public class Program {
	
	public static void main(String arg[]) {
		
		Scanner in = new Scanner(System.in);
		
		String line = "0";
		
		String user;
		
		int rating;
		
		int i = 0;
		
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		
		while (!(line.equals("-1"))) {
			
			line = in.nextLine();
			
			i = line.indexOf(';');
			
			if (!(line.equals("-1"))) {
				
				user = line.substring(0,i);
				
				rating = Integer.parseInt(line.substring(i + 1,line.length()));
				
				allRatings.add(new Rating(user,rating));
				
				}
			
			}
		
		System.out.println(getAverage(allRatings));
		
		in.close();
		
		}
	
	public static double getAverage(ArrayList<Rating> v) {
		
		int i;
		
		double sum = 0;
		
		int size = v.size();
		
		for (i = 0; i < size; i++) {
			
			sum = sum + v.get(i).getScore();
			
			}
		
		return sum/size;
		
		}
	
	}

