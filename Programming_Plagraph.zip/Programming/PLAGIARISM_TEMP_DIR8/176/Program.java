import java.util.ArrayList;
import java.util.Scanner;

public class Program {
	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
		String p=in.nextLine();
		ArrayList<Rating> allRatings=new ArrayList<Rating>();
		while(!p.equals("-1"))
		{
			String[] part=p.split(";");
			String part1=part[0];
			int part2=Integer.parseInt(part[1]);
			allRatings.add(new Rating(part1,part2));
			p=in.nextLine();
		}
		System.out.println(getAverage(allRatings));
		in.close();
	}
	public static double getAverage(ArrayList<Rating>v)
	{
		double sum=0;
		for(int i=0;i<v.size();i++)
		{
			sum=sum+v.get(i).getScore();
		}
		return (double)(sum/v.size());
	}
}

