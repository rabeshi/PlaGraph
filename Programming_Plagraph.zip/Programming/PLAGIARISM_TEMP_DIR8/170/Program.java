import java.util.*;


public class Program {

	public static double getAverage(ArrayList<Rating> v){
		
		double y=0;
		
		for(int i=0;i<v.size();i++)
		{
			y += v.get(i).Score;
		}
		
		
		
		return y/v.size();
	
	}
	
	public static void main(String[] args) {

		ArrayList<Rating> x = new ArrayList<Rating>();
		
		Scanner in = new Scanner(System.in);
		String str;
		String[] vals;
		
		
		str = in.next();
		
		
		
		while(!str.equals("-1"))
		{
			vals = str.split(";");
			x.add(new Rating(vals[0],Integer.parseInt(vals[1])));
			
			str = in.next();
			
		}
		
		
		double k = getAverage(x);
		
		System.out.println(k);
	}

}
