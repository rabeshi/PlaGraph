import java.util.ArrayList;
import java.util.Scanner;

public class Program {
	public static void main(String[] args) {
		ArrayList<Rating> data=new ArrayList<Rating>();
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		while(!s.equals("-1"))
		{
			String[]ag=s.split(";");
			data.add(new Rating(ag[0],Integer.parseInt(ag[1])));
			s=in.nextLine();
		}
		double ah=getAverage(data);
		System.out.println(ah);
		in.close();
	}
	public static double getAverage(ArrayList<Rating> v){
		double haha=0;
		for(int i=0;i<v.size();i++){
			Rating bla=v.get(i);
			haha+=bla.getScore();
		}
		return haha/(double)v.size();
	}
}
