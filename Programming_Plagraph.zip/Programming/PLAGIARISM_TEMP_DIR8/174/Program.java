import java.util.*;
public class Program {

	public Program() {
		// TODO Auto-generated constructor stub
	}
	 ArrayList <Rating> allRatings = new ArrayList<Rating>();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner (System.in);
		
		String in = sc.nextLine();
		int count =0;
		
		Program obj = new Program();
		
		while(!(in.equals("-1")))
		{
			String[] arr = in.split(";");
			
			obj.allRatings.add(new Rating( arr[0], Integer.parseInt(arr[1]) ) );
			
			count++;
			
			in=sc.nextLine();
		}
		
		System.out.println(obj.getAverage(obj.allRatings));

	}

	
	public double getAverage(ArrayList<Rating> v){
		double total=0;
		
		for(int i=0;i<v.size();i++)
		{
			total = total + v.get(i).getScore();
		}
		
		return (total/v.size());
	}
}
