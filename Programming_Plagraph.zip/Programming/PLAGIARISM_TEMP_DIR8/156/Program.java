import java.util.ArrayList;
import java.util.Scanner;

public class Program {
	public static void main (String args[]){
		Scanner in = new Scanner(System.in);
		ArrayList<Rating> allRatings  = new ArrayList<Rating>(); 
		Program program = new Program();
		String a = in.nextLine();

		while ( !a.equals("-1")){
			String vals[] =a.split(";");
			String b =vals[0];
			String c =vals[1];
			int d = Integer.parseInt(c);
			Rating myRating = new Rating(b,d);			
			allRatings.add(myRating);			
			
			a = in.nextLine();
		}
		System.out.println(program.getAverage(allRatings));
		
	}

	
	public double getAverage(ArrayList<Rating> v){
		
		int sum = 0;
		for (int i =0; i<v.size(); i++){
			 sum = sum + v.get(i).getScore();
					
		}
		double f = (double)sum;
		
		double average = f / v.size() ;
		return average;
	}
	
	
}

