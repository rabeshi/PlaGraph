
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author david
 */
public class Program {
    ArrayList<Rating> allRatings=new ArrayList<Rating>();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        BufferedReader BF=new BufferedReader(new InputStreamReader(System.in));
        Program p=new Program();
        for(String i=BF.readLine().trim();!i.equals("-1");i=BF.readLine()){
            String[] tempR=i.split(";");
            p.allRatings.add(new Rating(tempR[0],Integer.parseInt(tempR[1])));
        }
        System.out.println(p.getAverage(p.allRatings));
    }
    public double getAverage(ArrayList<Rating> v){
        double Average=0;
        for(Rating r:v){
            Average=r.getScore()+Average;
        }
        Average=Average/v.size();
        return Average;
    }

}
