import java.util.ArrayList;
import java.util.Scanner;


public class Program {
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		int i=0;
		String rates = in.nextLine();
		
		//allRatings.add(new Rating("Murendeni",1));
		//String rates;
		
		while(!"-1".equals(rates)){
			String[] vals = rates.split(";");
			int score = Integer.parseInt(vals[1]);
			allRatings.add(new Rating(vals[0], score));
			rates = in.nextLine();
		}
		
		//System.out.print(allRatings.get(2).getUsername());
		Program mure = new Program();
		double average = mure.getAverage(allRatings);
		System.out.print(average);
		//Rating myRating = new Rating("Mukwe", 7);	
	}
	
	public double getAverage(ArrayList<Rating> v){
		double av; double sum=0; int su;
		
		int vsize = v.size();
		
		for(int i=0; i<=vsize-1; i++){
			su = v.get(i).getScore();
			sum = sum + su;
		}
		
		av = sum/vsize;
		return av;
		
	}

}