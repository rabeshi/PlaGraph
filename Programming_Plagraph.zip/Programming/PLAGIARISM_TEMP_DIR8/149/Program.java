import java.util.ArrayList;
import java.util.Scanner;


public class Program {
	
	
	
	public double getAverage(ArrayList<Rating> v){
		double total=0;
		double arvg;
		for(int i=0; i< v.size(); i++){
			
			total +=  v.get(i).getScore();;
			
		}
		
		arvg = total / v.size();
		
		return arvg;
		
	}
	
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		
		String a = in.nextLine();
		
		while(!"-1".equals(a)){
			String[] vals = a.split(";");
			int score = Integer.parseInt(vals[1]);
			allRatings.add(new Rating(vals[0], score));
			a = in.nextLine();
		}
		
		Program avg = new Program();
		double average = avg.getAverage(allRatings);
		System.out.println("");
		System.out.print(average);
			
		}
		
	
	
}
