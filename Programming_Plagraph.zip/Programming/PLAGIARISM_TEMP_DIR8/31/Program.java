import java.util.*;

public class Program {

	public static void main(String [] args){
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		Program prog = new Program();
		Scanner in = new Scanner(System.in);
		String input = in.nextLine();

		while(!input.equals("-1")){
			StringTokenizer stk = new StringTokenizer(input, ";");
			String name = stk.nextToken();
			int age = Integer.parseInt(stk.nextToken());
			Rating item = new Rating(name, age);
			allRatings.add(item);
			input = in.nextLine();
		}
		double ave = 0.0;
		in.close();
		ave = prog.getAverage(allRatings);
		System.out.println(ave);
	}
	public double getAverage(ArrayList<Rating> v){
		double average = 0.0;
		double sum = 0;
		double count = 0.0;
		for(int i = 0; i < v.size(); i++){
			sum+= v.get(i).getScore();
			count++; 
		}
		average = sum/count;
		return average;
	}
}
