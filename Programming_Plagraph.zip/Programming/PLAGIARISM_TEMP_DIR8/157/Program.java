import java.util.ArrayList;
import java.util.Scanner;

public class Program {
	
	public static class callGetAverage{
	public double getAverage(ArrayList<Rating> v){
		int i=0;
		double sum=0;
		while(i<v.size()){
			sum+=v.get(i).getScore();
			i++;
		}
		return (sum/v.size());
	}
	
	}
	public static void main(String args[]){
		ArrayList<Rating> allRating = new ArrayList<Rating>();
		Scanner j = new Scanner(System.in);
		String s=j.nextLine();
		while(!s.contains("-1")){
			String[] v = s.split(";");
			Rating r = new Rating(v[0],Integer.parseInt(v[1]));
			allRating.add(r);
			s=j.nextLine();
		}
		j.close();
		if(allRating.size()!=0){
			callGetAverage c = new callGetAverage();
			System.out.print(c.getAverage(allRating));		
		}
		else{
			return;
		}
		
	}
}




