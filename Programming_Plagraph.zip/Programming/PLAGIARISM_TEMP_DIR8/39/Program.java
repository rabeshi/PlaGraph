import java.util.*;


public class Program {
	
	public double getAverage(ArrayList<Rating> v){
		int sum=0;
		for(int i=0;i<v.size();i++)
		{
		sum+=v.get(i).getScore();
		}
		return sum/v.size();
	}
	
	public static void main(String[]args)
	{
		Program p = new Program();
		Scanner in=new Scanner(System.in);
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		String username;
		int score;
		int num=in.nextInt();
		
		
		while(num!=-1)
		{
			String input=in.nextLine();
			String[] vals=input.split(";");
			username=vals[0];
			score=Integer.parseInt(vals[1]);
			allRatings.add(new Rating(username,score));
		}
		System.out.println(p.getAverage(allRatings));
	}
}
