import java.util.ArrayList;
import java.util.Scanner;


public class Program {
	ArrayList<Rating> allRatings = new ArrayList<Rating>();
	public double getAverage(ArrayList<Rating> v){
		double total = 0;
		for (int k = 0; k < v.size(); k++){
			total = total + v.get(k).getScore();
		}
		return total/v.size();
	}
	
	public static void main(String args[]){
		Program ours = new Program();
		Scanner in = new Scanner (System.in);
		String next = in.nextLine();
		int k = 0;
		double total = 0;
		while (!(next.equals("-1"))){
			String [] both = next.split(";");
			ours.allRatings.add(k, new Rating(both[0], Integer.parseInt(both[1])));
			k++;
			next = in.nextLine();
		}
		System.out.println(ours.getAverage(ours.allRatings));
		
	}
}
