import java.util.ArrayList;
import java.util.Scanner;


public class Program {
	public static void main(String args[])
	{
		Scanner in = new Scanner(System.in);
		ArrayList<Rating> allRatings= new ArrayList<Rating>();
		String dummy= in.nextLine(), dummy1="", dummy2="", decoy="-1";
		while(dummy.equals(decoy)==false)
		{
			/*for (int i=0; i<dummy.length(); i++)
			{
				if (dummy.charAt(i)!=';')
				{
					dummy1=dummy1+dummy.charAt(i);
				}
				else
				{
					for (int j=i+2; j<dummy.length(); j++)
					{
						dummy2=dummy.charAt(j)+dummy2;
					}
					i=dummy.length();
				}
			}*/
			String[] vals = dummy.split(";");
			Rating newrating= new Rating(vals[0],Integer.parseInt(vals[1]));
			allRatings.add(newrating);
			dummy= in.nextLine();
		}
		System.out.println((getAverage(allRatings)));
	}
	public static double getAverage(ArrayList<Rating> v){
		int count=0,sum=0;
		for (int i=0; i<v.size(); i++)
		{
			count=count+1;
			sum= sum+ v.get(i).score;
		}
		return (double)sum/count;
	}

}
