//Imports 
//Jared Tremayne Naidoo......
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Collections;

public class Program {
	
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		ArrayList<Rating> allRatings = new ArrayList<Rating>();
		String temp,usr,scr;
		int k,i,j,intscr;
		
		for(i = 1,j = 0; i > 0; j++){
			
			//Initial input.
			temp = input.nextLine();
			//Finds the ;
			k = temp.indexOf(';');
			//Separate user name(Messy).
			usr = temp.substring(0,k+1);
			usr = usr.replace(';', ' ');
			usr = usr.trim();
			//Separate score.
			scr = temp.substring(k+1,temp.length());
			// score to an int.
			intscr = Integer.parseInt(scr);
			//Import into array.
			allRatings.add(new Rating(usr,intscr));
			//System.out.println(allRatings.get(j).score);
			//if statement to find the -1.
			if(temp.contains("-1")){
				i = -1;
			}
			//Rating new setList(allRatings);
			
		}
		input.close();
		Program p = new Program();
		System.out.println(p.getAverage(allRatings));
	}
	
	//Required function from notes.
	public double getAverage(ArrayList<Rating> v){
		double avg = 0.0;
		for (int i=0;i<v.size()-1;i++) {
			avg = avg + (double)v.get(i).score;
		}
		avg = avg/(v.size()-1);
		
		return avg;
	}

}
