#include <thread>

int main() {
	fread_unlocked(NULL, 1, NULL, NULL);
	return 0;
}