package com.example.pangs
;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener{
	ArrayList<Ball> balls = new ArrayList<Ball>();
	Ball Line;
	DrawView drawView;
	int width;
	int height;
	int yy;
	int xx;
	//boolean check = false;
	Random r = new Random();

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
//		drawView.setOnTouchListener(this);
		Display display = getWindowManager().getDefaultDisplay();
		 width = display.getWidth();
		 height = display.getHeight();
//		int width = 400;
//		int height = 400;
		balls.add(new Ball(100,100,2,0,width,height));
		balls.add(new Ball(200,200,3,0,width,height));
		balls.add(new Ball(300,180,1,0,width,height));
		Line = new Ball(width,height,10,0,width,height);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		 xx=r.nextInt(height-0)+0;
		 yy=r.nextInt(width-0)+0;
		for(Ball i:balls){
		    i.update(0.5);
		    paint.setColor(Color.BLACK);
			canvas.drawCircle((int) i.x,(int) i.y,5,paint);
		}
	}
//		paint.setColor(Color.RED);
//		if(check)
//		Line.UpdateLine(0.0);
//		if(Line.x<=0){
//			balls.clear();
//			check=false;
//			Line.x = width;
//		 }
//		canvas.drawLine((float) Line.x, height,(float) Line.x, 0, paint);
//		canvas.drawRect((float) Line.x-50, height, (float) Line.x, 0, paint);
//	}


	@Override
	public boolean onTouch(View arg0, MotionEvent arg1) {
		int action = arg1.getAction();
		if(arg1.getX()>=width/2){
			balls.clear();
//			check=true;
		}
		if(arg1.getX()<=width/2){
		switch (action) {
	    case MotionEvent.ACTION_DOWN:
	    balls.add(new Ball(xx,yy,80,0,width,height));
	        break;
	    case MotionEvent.ACTION_MOVE:
		balls.add(new Ball(xx,yy,80,0,width,height));
	        break;
	    case MotionEvent.ACTION_UP:
		balls.add(new Ball(xx,yy,80,0,width,height));
	        break;
	    }
	}
		return false;
	}
}
