package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener {
	ArrayList<Ball> arr = new ArrayList<Ball>();
	Ball b1,b2,b3;
	int width;
	int height;
	Random rand = new Random();
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		b1 = new Ball(100, 100, 2, 0, width, height);
		b2 = new Ball(200, 200, 3, 0, width, height);
		b3 = new Ball(300, 180, 1, 0, width, height);
		arr.add(b1);
		arr.add(b2);
		arr.add(b3);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		Ball n;
		for(int i = 0;i<arr.size();i++){
			n = arr.get(i);
			n.update(0.5);
			
			canvas.drawCircle((int) n.x, (int) n.y, 5, paint);
			}
		}
	
	public boolean onTouch(View arg0, MotionEvent arg1){
		double n = arg1.getX();
		double x = rand.nextInt(width);
		double y = rand.nextInt(height);
		if(n>width/2){
			arr.add(new Ball(x,y,0,0,width,height));
		}
		else{
			arr.clear();
		}
		return true;
	}
}
