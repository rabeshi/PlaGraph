package com.example.animationgame;

import java.util.ArrayList;
import java.util.Collection;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

@SuppressLint("ClickableViewAccessibility") public class MainActivity  extends Activity implements OnTouchListener
 {
	int x=30,y=20;
	int y1 = 100, y2= 50;
	int v1 = 10, v2=20, v3=15;
	int screenHeight, width;
	Bitmap myImage,myImage1, myImage2;
	
	DrawView drawView;
	ArrayList<Object> BallList = new ArrayList<Object>();
	@Override
	public void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		// Set full screen view
		/*getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		Display display = getWindowManager().getDefaultDisplay();
		Point size = new Point();
		display.getSize(size);
		int width = size.x;
		screenHeight = size.y;*/
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
		WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener((OnTouchListener) this); //Add this line when doing touch events
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		screenHeight = display.getHeight();
		//myImage=BitmapFactory.decodeResource(getResources(), (Integer) R.drawable.ball);
		//myImage1=BitmapFactory.decodeResource(getResources(), (Integer) R.drawable.ball1);
		//myImage2=BitmapFactory.decodeResource(getResources(), (Integer) R.drawable.ball2);
		Ball b1 = new Ball(100, 100, 2, 0, width,screenHeight);
		Ball b2 = new Ball(200, 200, 3, 0, width, screenHeight);
		Ball b3 = new Ball(300, 180, 1, 0, width, screenHeight);
		BallList.add(b1);
		BallList.add(b2);
		BallList.add(b3);
		
	}
	public boolean onTouch1(View arg0, MotionEvent arg1){
		if(arg1.getAction() == MotionEvent.ACTION_POINTER_UP){
			y = 50;
			double x = arg1.getX();
			x = -1*x;
			
		}return true;
	}



	public void doDraw(Canvas canvas, Paint paint) {
		Ball b1 = new Ball(100, 100, 2, 0, width,screenHeight);
		Ball b2 = new Ball(200, 200, 3, 0, width, screenHeight);
		Ball b3 = new Ball(300, 180, 1, 0, width, screenHeight);
		canvas.drawCircle((int) b1.x, (int) b1.y, 5, paint);
		b1.Update(0.5);
		canvas.drawCircle((int) b2.x, (int) b2.y, 5, paint);
		b2.Update(0.5);
		canvas.drawCircle((int) b3.x, (int) b3.y, 5, paint);
		b3.Update(0.5);

		/*paint.setColor(Color.BLACK);
		canvas.drawCircle(x, y, 5, paint);
		//canvas.drawBitmap(myImage, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawCircle(100, y1, 30, paint);
		//canvas.drawBitmap(myImage1, 100, y1, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawCircle(300, y2, 10, paint);
		//canvas.drawBitmap(myImage2, 300, y2, paint);
		y = y + v1;
		if((y > screenHeight)||(y<0)){
			v1= -1*v1;
		}
		y1= y1 + v2;
		if((y1> screenHeight)||(y1<0)){
			v2=-1*v2;
		}
		y2= y2 + v3;
		if((y2> screenHeight)||(y2<0)){
			v3=-1*v3;
		}*/
	}


	@Override
	public boolean onTouch(View arg0, MotionEvent arg1) {
		// TODO Auto-generated method stub
		return false;
	}
}

