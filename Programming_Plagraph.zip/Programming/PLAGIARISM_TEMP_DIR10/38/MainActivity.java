package com.example.bounceballs;
import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener {
	int height, width;
	Balls b1, b2,b3;
	Bitmap myImage, myImage2,myImage3;
//	int direcBlk = 10, direcGrn = 20, direcYel = 15;
//	int blkx=30,blky=20, grnx=100,grny=100,yelx=300,yely=50;;
	ArrayList<Balls> myBalls = new ArrayList<Balls>();
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		drawView.setOnTouchListener(this);
		setContentView(drawView);
		drawView.requestFocus();
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		
		//myImage=BitmapFactory.decodeResource(getResources(), R.drawable.poke);
		//myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.soccerball);
		//myImage3=BitmapFactory.decodeResource(getResources(), R.drawable.stripes);
		
		b1 = new Balls(100, 100, 2, 0, width, height); //Black ball
		b2 = new Balls(200, 200, 3, 0, width, height); //Yellow ball
		b3 = new Balls(300, 180, 1, 0, width, height); //Green ball
		myBalls.add(b1);
		myBalls.add(b2);
		myBalls.add(b3);
		
		
		
	}


	public void doDraw(Canvas canvas, Paint paint) {		
		//if (blky <= 0 || blky >= height){
		//	direcBlk = -1*direcBlk;						
		//}				
		//canvas.drawCircle(blkx, blky, 5, paint);
		//paint.setColor(Color.BLACK);		
		//canvas.drawBitmap(myImage, blkx, blky, paint);
		//blky = blky + direcBlk;	
		
		//if (grny <= 0){
		//	direcGrn = 20;						
		//}	
		//if(grny >= height){
		//	direcGrn = -20;
		//}		
		//paint.setColor(Color.GREEN);
		//canvas.drawCircle(grnx, grny, 30, paint);
		//canvas.drawBitmap(myImage2, grnx, grny, paint);
		//grny = grny + direcGrn;
		
		//if (yely <= 0){
		//	direcYel = 15;						
		//}	
		//if(yely >= height){
		//	direcYel = -15;
		//}		
		//paint.setColor(Color.YELLOW);
		//canvas.drawCircle(yelx, yely, 10, paint);
		//canvas.drawBitmap(myImage3, yelx, yely, paint);
		//yely = yely + direcYel;
		
		
		for (int i = 0; i < myBalls.size(); i++){
			myBalls.get(i).update(0.5);
			canvas.drawCircle((int)myBalls.get(i).x, (int)myBalls.get(i).y, 5, paint);
		}
		
//		b1.update(0.5);
//		paint.setColor(Color.BLACK);
//		canvas.drawCircle((int)b1.x, (int)b1.y, 5, paint);
//		b2.update(0.5);
//		paint.setColor(Color.YELLOW);
//		canvas.drawCircle((int)b2.x, (int)b2.y, 5, paint);
//		b3.update(0.5);
//		paint.setColor(Color.GREEN);
//		canvas.drawCircle((int)b3.x, (int)b3.y, 5, paint);
		
		
	}


	@Override
	public boolean onTouch(View drawView, MotionEvent arg1) {
		// TODO Auto-generated method stub	
		for (int i = 0; i < myBalls.size(); i++){
			myBalls.get(i).changeXY(arg1.getX());
		}
		
		Random rand = new Random();
		int xVal = rand.nextInt(width);
		int yVal = rand.nextInt(height);
		
		myBalls.add(new Balls(xVal, yVal, 0, 0, width, height));
		
		if (arg1.getX() < (width*0.5)){
			myBalls.clear();
		}
		
//			b1.changeXY(arg1.getX());	
//			b2.changeXY(arg1.getX());
//			b3.changeXY(arg1.getX());
		return false;
	}

}
