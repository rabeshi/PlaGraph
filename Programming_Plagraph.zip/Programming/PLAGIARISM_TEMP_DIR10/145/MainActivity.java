package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener {
//int x=30,y=20;
	Random r = new Random();
    ArrayList<Ball> arr =  new ArrayList<Ball>();
	DrawView drawView;
	int width;
	int height;
	Ball b1;
	Ball b2;
	Ball b3;
	@Override
	public void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	// Set full screen view
	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
	WindowManager.LayoutParams.FLAG_FULLSCREEN);
	requestWindowFeature(Window.FEATURE_NO_TITLE);
	drawView = new DrawView(this);
	setContentView(drawView);
	drawView.requestFocus();
	//Add this line when doing touch events
	drawView.setOnTouchListener(this);
	Display display = getWindowManager().getDefaultDisplay();
	int width = display.getWidth();
	int height = display.getHeight();
	b1 = new Ball(100, 100, 5, 0, width, height,20);
	b2 = new Ball(200, 200, 3, 0, width, height,20);
	b3 = new Ball(300, 180, 8, 0, width, height,20);
	//adding to arraylist
	arr.add(b1);
	arr.add(b2);
	arr.add(b3);
	}
	
	public void doDraw(Canvas canvas, Paint paint) {
		for(int i =0 ;i<arr.size();i++){
		canvas.drawCircle((int) arr.get(i).x, (int) arr.get(i).y, 20, paint);
		arr.get(i).update(0.5);
		}

	}
	
	public boolean onTouch(View arg0, MotionEvent arg1)
	{
		Display display = getWindowManager().getDefaultDisplay();
		
		width = display.getWidth();
		height = display.getHeight();
		
		if(arg1.getAction()==MotionEvent.ACTION_DOWN){
			//Pressing on screen
			int x =(int) arg1.getX();
			
			int c = r.nextInt(width);
		    int d = r.nextInt(height);
			if(x>width/2){
				arr.add(new Ball(c,d,0,0,width,height, 20));
			}
			else{
				
				arr.clear();
			}
	}
		
		return true;
	
	
	}
}
