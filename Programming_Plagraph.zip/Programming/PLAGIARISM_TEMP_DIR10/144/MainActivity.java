package com.example.animationgame;
import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener {

	ArrayList<Ball> bal = new ArrayList<Ball> ();
	Random m = new Random();
	DrawView drawView;
	int width, height;
	Ball b1;
	Ball b2;
	Ball b3;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this); //Add this line when doing touch events
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		bal.add( new Ball(100, 100, 2, 0, width, height, 10));
		b2 = new Ball(200, 200, 3, 0, width, height, 20);
		bal.add(b2);
		b3 = new Ball(300, 180, 1, 0, width, height, 15);
		bal.add(b3);
	}




	public void doDraw(Canvas canvas, Paint paint) {
		
		for(int i = 0; i < bal.size(); i++){
			Ball h=bal.get(i);
			canvas.drawCircle((int) h.x, (int) h.y, 10 , paint);
			h.update(0.5);
		}
	}


	@Override
	public boolean onTouch(View arg0, MotionEvent arg1) {
		// TODO Auto-generated method stub
		
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		int x_random = m.nextInt(width);
		int y_random = m.nextInt(height);
		int s = arg1.getAction();
		if(s == MotionEvent.ACTION_DOWN){
			int x_coordinate = (int) arg1.getX();
			if(x_coordinate >= width*0.5){
				bal.add( new Ball(x_random, y_random, 2, 0, width, height, 10));
				
			}else{
				bal.clear();
			}
			
		}

		return false;
	}
}
