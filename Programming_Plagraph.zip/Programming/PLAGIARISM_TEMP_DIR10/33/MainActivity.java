package com.example.lab6;

import java.util.ArrayList;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener{
	
	DrawView drawView;
	Point size = new Point();	
	ArrayList<Ball> ballsArr = new ArrayList<Ball>();
	int width, height;


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
		Display display = getWindowManager().getDefaultDisplay();		
		display.getSize(size);
		
		
		height = size.y;
		width = size.x;
		
		ballsArr.add(new Ball(100, 100, 2, 0, width, height));
		ballsArr.add(new Ball(200, 200, 3, 0, width, height));
		ballsArr.add(new Ball(300, 180, 1, 0, width, height));
		
	}


	public void doDraw(Canvas canvas, Paint paint) {

		for(int i = 0; i < ballsArr.size();i++)
		{
			ballsArr.get(i).update(0.5);
			canvas.drawCircle((int) ballsArr.get(i).x, (int) ballsArr.get(i).y, 5, paint);
		}

}


	@Override
	public boolean onTouch(View arg0, MotionEvent arg1) {
		// TODO Auto-generated method stub
		
		if (arg1.getX() >= width/2)
		{
			ballsArr.add(new Ball((int)(Math.random()*width),(int)(Math.random()*height), 0, 0, width, height));
		}
		else 
		{
			ballsArr.clear();
		}
		return false;
	}
	
}
