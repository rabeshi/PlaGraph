package com.example.animationgamev2;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener{
	int x=0,y=0;
	float textx=300f;
	float texty=300f;
	DisplayMetrics displaymetrics = new DisplayMetrics();
	int height;
	int width;
	Bitmap myImage1;
	Bitmap myImage2;
	Bitmap myImage3;

	DrawView drawView;

	boolean allowadd=true;
	boolean allowmovetext=false;
	boolean initialTextPos=true;

	Ball b1;
	Ball b2;
	Ball b3;
	static ArrayList<Ball> listOfBalls=new ArrayList<Ball>();
	Rect bounds = new Rect();
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		width = displaymetrics.widthPixels;
		height = displaymetrics.heightPixels;

		listOfBalls.add(new Ball(100, 100, 2, 0, width, height,5));
		listOfBalls.add(new Ball(200, 200, 3, 0, width, height,5));
		listOfBalls.add(new Ball(300, 180, 1, 0, width, height,5));
	}

	public void doDraw(Canvas canvas, Paint paint) {
		for(int i=0;i<listOfBalls.size();i++){
			canvas.drawCircle((int)listOfBalls.get(i).x,(int)listOfBalls.get(i).y, 5, paint);
			listOfBalls.get(i).update(0.5);
		}
		
		paint.setColor(Color.BLACK); 
		paint.setTextSize(40);
		paint.getTextBounds("No. of Balls "+listOfBalls.size(), 0, ("No. of Balls "+listOfBalls.size()).length(), bounds);
		if(initialTextPos){
			textx=width/2-bounds.width()/2;
			texty=height/10;
			initialTextPos=false;
		}
		canvas.drawText("No. of Balls "+listOfBalls.size(),textx,texty, paint);
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		x=(int) event.getX();
		y=(int) event.getY();
		if(allowadd){
			Random rdm=new Random();
			if(x>width/2){
				listOfBalls.add(new Ball(rdm.nextInt(x),rdm.nextInt(y),0,0, width, height,5));
			}else{
				listOfBalls.clear();
			}
		}
		if(allowmovetext){
			textx=event.getX()-bounds.width()/2;
			texty=event.getY()-bounds.height()/2;
		}
		return ((allowadd) || allowmovetext);
	}
/*
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		MenuInflater inflater = getMenuInflater();    
		inflater.inflate(R.menu.main, menu);
		menu.getItem(1).setChecked(allowadd);
		menu.getItem(2).setChecked(allowmovetext);
		return true;
	}

	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		switch(id){
		case(R.id.item1):{
			for(int i=0;i<listOfBalls.size();i++){
				listOfBalls.get(i).goCrazy(x+10,y+10);
			}
			return true;
		}
		case(R.id.item2):{
			allowadd=!allowadd;
			item.setChecked(allowadd);
			return true;
		}
		case(R.id.item3):{
			allowmovetext=!allowmovetext;
			item.setChecked(allowmovetext);
			return true;
		}
		default:return super.onOptionsItemSelected(item);
		}
	}
*/
}
