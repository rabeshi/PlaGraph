package com.example.animationgame_v2;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends Activity implements OnTouchListener{
	int x=30,y=20,m=100,n=50;
	ArrayList<Ball> balls = new ArrayList<Ball>();
	DrawView drawView;
	int height = 0,width=0;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	// Set full screen view
	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
	WindowManager.LayoutParams.FLAG_FULLSCREEN);
	requestWindowFeature(Window.FEATURE_NO_TITLE);
	drawView = new DrawView(this);
	setContentView(drawView);
	drawView.requestFocus();
	drawView.setOnTouchListener(this); //Add this line when doing touch events
	Display display = getWindowManager().getDefaultDisplay();
	width = display.getWidth();
	height = display.getHeight();
	balls.add(new Ball(100, 100, 2, 0, width, height));
	balls.add(new Ball(200, 200, 3, 0, width, height));
	balls.add(new Ball(300, 180, 1, 0, width, height));
	}


	public void doDraw(Canvas canvas, Paint paint) {
		
		for(int i=0;i<balls.size();i++){
			Ball temp = balls.get(i);
			canvas.drawCircle((int) temp.x, (int) temp.y, 5, paint);
			temp.update(0.5);
		}
	}


	@Override
	public boolean onTouch(View arg0, MotionEvent arg1) {
		// TODO Auto-generated method stub
		int x = (int) arg1.getX();
		Random m = new Random();
		if(x >= width/2){
			balls.add(new Ball(m.nextInt(width), m.nextInt(height),0 , 0, width, height));
		}else{
			balls.clear();
		}
		return true;
	}
	
}
