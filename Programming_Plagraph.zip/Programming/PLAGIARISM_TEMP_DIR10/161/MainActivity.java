package com.example.animationgame;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Canvas;

import java.util.Iterator;

import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;



@SuppressLint("ClickableViewAccessibility")
public class MainActivity extends Activity
    implements android.view.View.OnTouchListener
{

    ArrayList<Ball> amabolo;
    DrawView drawView;
    int height;
    int width;
    public MainActivity()
    {
        amabolo = new ArrayList<Ball>();
    }

    public void doDraw(Canvas canvas, Paint paint)
    {
        Iterator<Ball> iterator = amabolo.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                return;
            }
            Ball ball = (Ball)iterator.next();
            canvas.drawCircle((int)ball.x, (int)ball.y, 5, paint);
            ball.update(0.5);
        } while (true);
    }



	@SuppressWarnings("deprecation")
	public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
        WindowManager.LayoutParams.FLAG_FULLSCREEN);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        drawView = new DrawView(this);
        setContentView(drawView);
        drawView.requestFocus();
        drawView.setOnTouchListener(this); //Add this line when doing touch events
        Display display = getWindowManager().getDefaultDisplay();
        width = display.getWidth();
        height = display.getHeight();
        Ball bolo = new Ball(100, 100, 2, 0, width, height);
        Ball bolo1 = new Ball(200, 200, 2, 0, width, height);
        Ball bolo2 = new Ball(300, 180, 2, 0, width, height);
        amabolo.add(bolo);
        amabolo.add(bolo1);
        amabolo.add(bolo2);
    }

    public boolean onTouch(View arg0, MotionEvent arg1)
    {
        if (arg1.getX() > (int)400)
        {
            amabolo.clear();
        } else
        {
            Ball Diski = new Ball((int)400 * Math.random(), (int)100 * Math.random(), 0, 0, width, height);
            amabolo.add(Diski);
        }
        return true;
    }
}