package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends Activity implements OnTouchListener {
	double width,height;
	int ballSize = 5;
	Bitmap red;
	DisplayMetrics metrics = new DisplayMetrics();
	BitmapFactory.Options optionsRed = new BitmapFactory.Options();
	DrawView drawView;
	ArrayList<Ball> Balls = new ArrayList<Ball>();


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		drawView.setOnTouchListener(this);
		setContentView(drawView);
		drawView.requestFocus();
		// height/width minus 5 to account for size of ball (5px)
		width = (double) metrics.widthPixels-ballSize;
		height = (double) metrics.heightPixels-ballSize;
		Balls.add(new Ball(100.0, 100.0, 2.0, 0.0, 0.0, 0.5, width, height));
		Balls.add(new Ball(200.0, 200.0, 3.0, 0.0, 0.0, 0.5, width, height));
		Balls.add(new Ball(300.0, 180.0, 1.0, 0.0, 0.0, 0.5, width, height));
		
	}

	public void doDraw(Canvas canvas, Paint paint) {
		int index;
		
		for (index = 0; index < Balls.size(); index++){
			Balls.get(index).update();
			canvas.drawCircle((int)Balls.get(index).x, (int)Balls.get(index).y, ballSize, paint);
		}
	}

	
	public static double randomdouble(double max){
		return new Random().nextDouble()*(max);
	}
	
	@Override
	public boolean onTouch(View arg0, MotionEvent arg1){
		if (arg1.getAction()==MotionEvent.ACTION_DOWN) {
			if (arg1.getX() <= width/2)
				{Balls.add(new Ball(randomdouble(width), randomdouble(height), 
						0.0, 0.0, 0.0, 0.5, width, height));}
			else
				{Balls.clear();}
		}
		return true;
	}
}