package com.example.animationgame2;

import java.util.ArrayList;
import java.util.Random;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;


public class MainActivity extends Activity implements OnTouchListener {
	int x=30,y=20;
	int height;//variable to store screen height
	int width;
	ArrayList<Ball> Balls;
	//Ball ball1; these are no longer needed with the ArrayList being used instead
	//Ball ball2; and so all associated code with them has been removed as well
	//Ball ball3; 
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		height = displaymetrics.heightPixels;
		width = displaymetrics.widthPixels;
		Balls = new ArrayList<Ball>();
		for (int i = 0; i < 3; i++){
			Balls.add(new Ball(100 * i, 100 * i, 2, 0, width - 5, height - 5));//this makes sure that part of the ball is not rendered offscreen
		}		
	}


	public void doDraw(Canvas canvas, Paint paint) {
		for (int i = 0; i < Balls.size(); i++){
			canvas.drawCircle((int) Balls.get(i).x, (int) Balls.get(i).y, 5, paint);
			Balls.get(i).update(0.5);
		}		
	}
	
	public boolean onTouch(View arg0, MotionEvent arg1){
		if (arg1.getX() > width / 2){			
			Random Rand = new Random();			
			Balls.add(new Ball(Rand.nextInt(width - 5), Rand.nextInt(height - 5), 0, 0, width - 5, height - 5));
		}
		else{
			Balls.clear();
		}
		return true;
	}

}
