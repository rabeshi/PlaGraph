package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener {
	float x = 30, y = 20, gy = 100, py = 50;

	DrawView drawView;

	/*
	 * Bitmap myImage; Bitmap myGreenImage; Bitmap myPinkImage; boolean flagR =
	 * false; boolean flagG = false; boolean flagP = false; float velR = 10;
	 * float velG = 20; float velP = 15;
	 */
	Ball b1;
	Ball b2;
	Ball b3;
	double width, height;
	ArrayList<Ball> var = new ArrayList<Ball>();
	Random numw = new Random();

	public boolean onTouch(View arg0, MotionEvent arg1) {

		if (arg1.getX() >= width / 2) {
			double randomxValue = width * numw.nextDouble();
			double randomyValue = (height - 0) * numw.nextDouble();
			double randxspeed = (20*numw.nextDouble())-10;

			var.add(new Ball(randomxValue, randomyValue, randxspeed, 0, width, height));
		} else {
			var.clear();

		}
		return (true);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);// need this when doing touch
		// events
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		b1 = new Ball(100, 100, 2, 0, width, height);
		var.add(b1);
		b2 = new Ball(200, 200, 3, 0, width, height);
		var.add(b2);
		b3 = new Ball(300, 180, 1, 0, width, height);
		var.add(b3);

		/*
		 * //myImage = BitmapFactory.decodeResource(getResources(),
		 * R.drawable.ball); //myGreenImage =
		 * BitmapFactory.decodeResource(getResources(), R.drawable.ballgreen);
		 * //myPinkImage = BitmapFactory.decodeResource(getResources(),
		 * R.drawable.ballpink);
		 */
	}

	public void doDraw(Canvas canvas, Paint paint) {
		/*
		 * Display display = getWindowManager().getDefaultDisplay(); Point size
		 * = new Point(); DisplayMetrics metrics = new DisplayMetrics();
		 * getWindowManager().getDefaultDisplay().getMetrics(metrics);
		 * canvas.drawBitmap(myImage, x, y, paint);
		 * canvas.drawBitmap(myGreenImage, 200, gy, paint);
		 * canvas.drawBitmap(myPinkImage, 500, py, paint); // paint.setColor();
		 */

		for (Ball d : var) {
			canvas.drawCircle((int) d.x, (int) d.y, 10, paint);
			d.update(0.5);
		}

		/*
		 * // -----------moving down if (flagR == false && !((Math.abs(velR)
		 * <0.6)&&(y >=metrics.heightPixels - 47 ))) { y = y + velR; velR = velR
		 * + 0.1f;
		 * 
		 * } if (flagG == false && !((Math.abs(velG) <0.6)&&(gy
		 * >=metrics.heightPixels-202))) { gy = gy + velG; velG = velG + 0.1f;
		 * 
		 * } if (flagP == false && !((Math.abs(velP) <0.6)&&(py
		 * >=metrics.heightPixels-295 ))) { py = py + velP; velP = velP + 0.1f;
		 * 
		 * // ------------------------moving up } if (flagR == true &&
		 * !((Math.abs(velR) <0.6)&&(y >=metrics.heightPixels - 47 ))) { y = y -
		 * velR; velR = velR - 0.5f; } if (flagG == true && !((Math.abs(velG)
		 * <0.6)&&(gy >=metrics.heightPixels -202))) { gy = gy - velG; velG =
		 * velG - 0.5f; } if (flagP == true && !((Math.abs(velP) <0.6)&&(py
		 * >=metrics.heightPixels -295 ))) { py = py - velP; velP = velP - 0.5f;
		 * }
		 * 
		 * 
		 * // ------at the bottom of the screen if (y >= metrics.heightPixels -
		 * 43) { flagR = true; } if (gy >= metrics.heightPixels - 200) { flagG =
		 * true; } if (py >= metrics.heightPixels - 288) { flagP = true; } //
		 * -------top of screen if (y <= 0) { flagR = false; } if (gy <= 0) {
		 * flagG = false; } if (py <= 0) { flagP = false; }
		 * 
		 * if ((velR <= 0) && (flagR ==true)) { flagR = false; } if ((velG <= 0)
		 * && (flagG ==true)) { flagG = false; } if ((velP <= 0) && (flagP
		 * ==true)) { flagP = false; }
		 */
		for (Ball e : var) {
			if (e.y > height) {
				e.y = height;
			}
		}

	}
}
