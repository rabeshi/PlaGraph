package com.example.animationgame;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

//@SuppressLint({ "NewApi")
public class MainActivity extends Activity implements OnTouchListener {
	
	double height;
	double width;
	double xspeed;

	DrawView drawView;
	ArrayList<Ball> list = new ArrayList<Ball>();

	@SuppressWarnings("deprecation")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener((OnTouchListener) this); // Add this line
																// when doing
																// touch events
		Display display = getWindowManager().getDefaultDisplay();
		
		 width = display.getWidth();
		 height = display.getHeight();
		Ball b1 = new Ball(100.0,100.0,2.0,2.0, width, height);
		list.add(b1);
		
		Ball b2 = new Ball(200.0,200.0,2.0,2.0, width, height);
		list.add(b2);

		Ball b3 = new Ball(300.0,180.0,2.0,2.0, width, height);
		list.add(b3);

	}
	@SuppressLint("NewApi")
	public void doDraw(Canvas canvas, Paint paint) {
		for (Ball b:list){
			canvas.drawCircle((int) b.x, (int) b.y, 5, paint);
			b.update(0.5);
		}
	
	}

	@SuppressLint("ClickableViewAccessibility") @Override
	public boolean onTouch(View arg0, MotionEvent arg1) 
	{
		// TODO Auto-generated method stub
		if ((arg1.getX()) >= (width / 2))//right touch 
	    {
			list.add(new Ball(Math.random()*width,Math.random()*height,0.0,0.0,width,height)); 
			return true;
	    } 
		
		else if (arg1.getX()<=(width / 2))//left touch
		{
			list.clear();
		}
			return false;
  }
}
