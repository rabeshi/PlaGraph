package com.example.nviek;



import java.util.ArrayList;
import java.util.Random;

import com.example.nviek.DrawView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener{

	
	ArrayList<Ball> Balls = new ArrayList<Ball>();
	
	DrawView drawView;


int Half ,width1 , height1 ;


@Override
public void onCreate(Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
// Set full screen view
getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
WindowManager.LayoutParams.FLAG_FULLSCREEN);
requestWindowFeature(Window.FEATURE_NO_TITLE);
drawView = new DrawView(this);
setContentView(drawView);
drawView.requestFocus();
drawView.setOnTouchListener(this); //Add this line when doing touch events

DisplayMetrics displaymetrics = new DisplayMetrics();
getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
int height = displaymetrics.heightPixels;
int width = displaymetrics.widthPixels;
Half = width/2 ;
width1 = width ;
height1 = height ;

Balls.add(new Ball(100, 100, 2, 0, width, height)) ;
Balls.add(new Ball(200, 200, 3, 0, width, height));
Balls.add(new Ball(300, 180, 1, 0, width, height)) ;



}
public void doDraw(Canvas canvas, Paint paint) {
	
	for(int i = 0 ; i<Balls.size(); i++)
	{
		Balls.get(i).update(0.5) ;
		canvas.drawCircle((int) Balls.get(i).x, (int) Balls.get(i).y, 5, paint) ;
	}
	
}


 @Override
public boolean onTouch(View arg0, MotionEvent arg1)
{
	 if (arg1.getX() > Half){
	  double randomw  = new Random().nextDouble();
		double randomy  = new Random().nextDouble();
	 
		double testx = 0 +randomw*(width1) ;
		double testy = 0 +randomy*(height1) ;
 
		 Balls.add(new Ball(testx, testy, 0, 0, width1, height1)) ;
	 
	 }
	 else
		 Balls.clear() ;
	/*if (arg1.getX() > Half)
	{
		b1.y = 50 ;
		b2.y = 50 ;
		b3.y = 50 ;
		
	}
	if(arg1.getX() <= Half)
	{
		b1.xspeed = b1.xspeed*(-1) ;
		b2.xspeed = b2.xspeed*(-1) ;
		b3.xspeed = b3.xspeed*(-1) ;
		//return true ;
	}*/
	return true ;

	

}
}
	
	