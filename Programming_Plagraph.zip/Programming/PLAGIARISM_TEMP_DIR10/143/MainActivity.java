package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

public class MainActivity extends Activity implements OnTouchListener {
	public ArrayList<Ball> BallsList = new ArrayList<Ball>();
	Ball b1;
	Ball b2;
	Ball b3;
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState); 
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN); requestWindowFeature(Window.FEATURE_NO_TITLE); drawView = new DrawView(this);
		setContentView(drawView); drawView.requestFocus();
		drawView.setOnTouchListener(this);
		Display display = getWindowManager().getDefaultDisplay(); 
		int width = getApplicationContext().getResources().getDisplayMetrics().widthPixels;
		int height = getApplicationContext().getResources().getDisplayMetrics().heightPixels;
		b1 = new Ball(100, 100, 2, 2, width, height);
		b2 = new Ball(200, 200, 3, 3, width, height); 
		b3 = new Ball(300, 180, 1, 1, width, height); 
		BallsList.add(b1);
		BallsList.add(b2);
		BallsList.add(b3);		
	}


	public void doDraw(Canvas canvas, Paint paint) {
		int width = getApplicationContext().getResources().getDisplayMetrics().widthPixels;
		int height = getApplicationContext().getResources().getDisplayMetrics().heightPixels;
		for (int i = 0; i < BallsList.size(); i++) 
		{
			Ball b = BallsList.get(i);
			b.update(0.5);
			canvas.drawCircle((int) b.x, (int) b.y, 5, paint);
			
		}
	}
	public boolean onTouch(View arg0, MotionEvent arg1)
	{
		int width = getApplicationContext().getResources().getDisplayMetrics().widthPixels;
		int height = getApplicationContext().getResources().getDisplayMetrics().heightPixels;
        double half = width/2;
		
		Random rand = new Random();	
		if(arg1.getX() <= half)
		{
			Ball b = new Ball(rand.nextInt(width/2), rand.nextInt(height),0,0,width,height);
			BallsList.add(b);	
		}
		
		else
		{	
			BallsList.clear();
		}
		return true;
	}
}
