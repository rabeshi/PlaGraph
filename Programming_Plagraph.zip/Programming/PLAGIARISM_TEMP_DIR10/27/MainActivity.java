package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener {
	
	Random rand = new Random();
	int width, height;
	ArrayList<Ball> balls = new ArrayList<Ball>();

	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
		WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this); //Add this line when doing touch events
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		
		balls.add(new Ball(100, 100, 2, 0, width, height));
		balls.add(new Ball(200, 200, 3, 0, width, height));
		balls.add(new Ball(300, 180, 1, 0, width, height));
	}
	
	
	public boolean onTouch(View arg0, MotionEvent arg1){
		// example program does not match what is in pdf, pdf followed
		if (arg1.getX() > (int)(width/2)) {
			balls.add(new Ball(rand.nextInt(width+1),rand.nextInt(height+1), /*rand.nextInt(10)*/ 0, 0, width, height));
		}else {
			balls.clear();
		}
		return true;
	}
	
	public void doDraw(Canvas canvas, Paint paint) {
		for (Ball ball : balls){
			canvas.drawCircle((int) ball.x, (int) ball.y, 5, paint);
			ball.update(0.5);
		}
	}

}
