package com.example.animationgame;
import java.util.ArrayList;

import android.app.Activity;
import android.graphics.Bitmap;
//import android.graphics.BitmapFactory;
import android.graphics.Canvas;
//import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
//import android.util.DisplayMetrics;
import android.view.Display;
//import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener{
	int x=30,y=20,y_gre=100,y_yel=50;
	int turn1=1,turn2=1,turn3=1;
	Bitmap myImage,Bella,Fedora;
	Ball b1, b2, b3;
	int width, height;
	ArrayList<Ball> balls;
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
	
		drawView.setOnTouchListener(this); //Add this line when doing touch events
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		balls = new ArrayList<Ball>();

		balls.add(new Ball(100,100,4,2,width,height));
		balls.add(new Ball(150,150,2,5,width,height));
		balls.add(new Ball(300,300,3,7,width,height));
		//myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		//Bella=BitmapFactory.decodeResource(getResources(), R.drawable.bella);
		//Fedora=BitmapFactory.decodeResource(getResources(), R.drawable.fedora);
		
	}


	public void doDraw(Canvas canvas, Paint paint) {
		//paint.setColor(Color.BLACK);
		//canvas.drawBitmap(myImage, x, y, paint);
		//paint.setColor(Color.GREEN);
		//canvas.drawBitmap(Bella, 300, y_gre, paint);
		//paint.setColor(Color.YELLOW);
		//canvas.drawBitmap(Fedora, 100, y_yel, paint);
		for (int k = 0; k < balls.size(); k++)
		{
			canvas.drawCircle((int) balls.get(k).x, (int) balls.get(k).y, 5, paint);
			balls.get(k).Update(0.5);
		}
	}
	
	public boolean onTouch(View arg0, MotionEvent arg1){
		if (arg1.getX() > width/2)
		{
			balls.add(new Ball(Math.random()*width,Math.random()*height,0,0,width,height));
		}
		else
		{
			balls.clear();
		}
		return true;
	}

}
