package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
//import android.util.DisplayMetrics;
//import android.view.ContextThemeWrapper;
//import android.view.Display;
//import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

public class MainActivity extends Activity  implements OnTouchListener{
	int x=30,y=200,x2=100,y2=100,x3=300,y3=50;
	int ycount=0,yInitial=200;
	int y2count=0,yInitial2=100;
	int y3count=0,yInitial3=50;
	Bitmap myImage;
	Bitmap myImage2;
	Bitmap myImage3;
	Ball b1,b2,b3,b4;
	int xspeed=2,yspeed=0;

	ArrayList<Ball> balls= new ArrayList<Ball>();
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.ball_ll);
		myImage3=BitmapFactory.decodeResource(getResources(), R.drawable.ball_lll);
		//double height= getResources().getDisplayMetrics().heightPixels;
		Display display = getWindowManager().getDefaultDisplay();
		int width = display.getWidth();
		int height = display.getHeight();
		b1 = new Ball(100, 100, 2, 0, width, height);
		b2 = new Ball(200, 200, 3, 0, width, height);
		b3 = new Ball(300, 180, 1, 0, width, height);
		balls.add(b1);balls.add(b2);balls.add(b3);
	}
	
	
	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.GREEN);
		
		for(int i=0;i<balls.size();i++){
			canvas.drawCircle( (int) balls.get(i).x,(int) balls.get(i).y, 10, paint);
			balls.get(i).update(0.5);
		}
	
	}
	public boolean onTouch(View drawView, MotionEvent arg1){
			Display display = getWindowManager().getDefaultDisplay();
			int width = display.getWidth();
			int height = display.getHeight();

			double x = 0 +(double)(Math.random()*width);
			double y = 0 +(double)(Math.random()*height);
			if(arg1.getX()>width/2){
				b4=new Ball(x,y,0,0,width,height);
				balls.add(b4);
			}else{
				balls.removeAll(balls);
			}
	return false;
	}

}
