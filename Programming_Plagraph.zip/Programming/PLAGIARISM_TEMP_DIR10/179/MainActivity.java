package com.example.animationgame;
import java.util.ArrayList;
import java.util.Random;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener{
	ArrayList <Ball> balls = new ArrayList<Ball>();
	DrawView drawView;
	Ball b1;
	Ball b2;
	Ball b3;
	int	width;
	int height;
	int yup =0;
	int zup=0;
	Random r = new Random();
	@SuppressWarnings("deprecation")
	@SuppressLint("ClickableViewAccessibility") @Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener((OnTouchListener) this); //Add this line when doing touch events
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		balls.add(new Ball(100, 100, 2, 0, (Integer) width, height));
		balls.add(new Ball(200, 200, 3, 0, (Integer) width, height));
		balls.add(new Ball(300, 180, 1, 0, (Integer) width, height));
	}


	public void doDraw(Canvas canvas, Paint paint) {
	
		for(int i =0; i < balls.size(); i++)
		{
			Ball ball = balls.get(i);
			canvas.drawCircle((int) ball.x, (int) ball.y, 5, paint);
			ball.update(0.5);
		}
		
		}


	@Override
	public boolean onTouch(View arg0, MotionEvent arg1) {
		// TODO Auto-generated method stub
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		int action = arg1.getAction();
		int newx = r.nextInt(width-width/2-1);
		int newy = r.nextInt(height- height/2);
		yup = (int) arg1.getY();
		zup = (int) arg1.getX();
		if(action==MotionEvent.ACTION_DOWN){
			int x= (int)arg1.getX();
			
			if(x<=width*0.5){
				balls.add(new Ball(newx, newy, 2, 0, width, height));
			}
			else
				balls.clear();
			
		}
		
		return false;
		
	}

}
