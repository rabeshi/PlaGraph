package com.example.pangs;

import java.util.ArrayList;
import java.util.Random;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.v4.view.MotionEventCompat;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener {
	Ball b1;
	Ball b2;
	Ball b3;
	DrawView drawView;
	int width;
	int height;
	ArrayList<Ball> data = new ArrayList<Ball>();
	Ball line;
	Random rand = new Random();
	boolean check = false;

	@SuppressLint("ClickableViewAccessibility") @SuppressWarnings("deprecation")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		line = new Ball(width, height, -3, 0, width, height);
		Log.d("Tahr", Double.toString(line.x));
		b1 = new Ball(100, 100, 2, 0, width, height);
		b2 = new Ball(200, 200, 3, 0, width, height);
		b3 = new Ball(300, 180, 1, 0, width, height);
		data.add(b1);
		data.add(b2);
		data.add(b3);
	}

	public void doDraw(Canvas canvas, Paint paint) {
		if (check) {
			paint.setColor(Color.RED);
			line.UpdateLine(10);
			canvas.drawLine((float) line.x, (float) line.y, (float) line.x, 0,
					paint);
			if (line.x < 0) {
				check = false;
			}
		}
		// paint.setColor(Color.BLACK);
		for (int i = 0; i < data.size(); i++) {
			Ball b = data.get(i);
			b.Update(0.98, line.x, check);
			paint.setColor(Color.BLACK);
			if (line.x <= 0) {
				data.clear();
				line.x=width;
			} else {
				if(b.y<-1){
					canvas.drawCircle((int) b.x,0, 5, paint);
				}else{
					canvas.drawCircle((int) b.x, (int) b.y, 5, paint);	
				}
			}
		}
	}

	@SuppressLint("ClickableViewAccessibility") @Override
	public boolean onTouch(View arg0, MotionEvent arg1) {

		if (arg1.getX() <= width / 2) {

			int action = MotionEventCompat.getActionMasked(arg1);
			switch (action) {
			case (MotionEvent.ACTION_DOWN):
				data.add(new Ball(rand.nextInt(width / 2), 0, 0, 0, width,
						height));
				break;
			case (MotionEvent.ACTION_UP):
				data.add(new Ball(rand.nextInt(width / 2), 0, 0, 0, width,
						height));
				break;
			}
		} else {
//			line = new Ball(width, height, -3, 0, width, height);
//			check = true;
			data.clear();
		}
		return false;
	}
}
