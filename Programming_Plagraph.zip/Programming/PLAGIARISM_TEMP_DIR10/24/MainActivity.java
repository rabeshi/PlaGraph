package com.example.lab6;

import java.util.ArrayList;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener {
	int x=30,y=20;
	int Gy = 100;
	int Yy = 50;
	int YMove = 10;
	int GMove = 20;
	int YyMove = 15;
	int lol = 1;
	int Glol = 1;
	int Ylol = 1;
	
	ArrayList<Ball> LOL = new ArrayList<Ball>();
	
	DrawView drawView;
	
	Bitmap myImage;
	Bitmap myImage2;
	Bitmap myImage3;
	
	Ball b1;
	Ball b2;
	Ball b3;


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		
		drawView.setOnTouchListener(this);
		
		Display display = getWindowManager().getDefaultDisplay();
		int width = display.getWidth();	
		int height = display.getHeight();
		
		LOL.add(new Ball(100,100,2,0,width,height));
		LOL.add(new Ball(200,200,3,0,width,height));
		LOL.add(new Ball(300,180,1,0,width,height));
		
		//myImage = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		//myImage2 = BitmapFactory.decodeResource(getResources(),R.drawable.pokeball);
		//myImage3 = BitmapFactory.decodeResource(getResources(), R.drawable.ball3);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		int counter = 0;
		
		for (Ball b:LOL){
			canvas.drawCircle((int) b.x, (int) b.y, 5, paint);
			b.update(0.5);
			counter += 1;
		}
		//paint.setColor(Color.BLACK);
		//canvas.drawCircle((int) b1.x, (int)b1.y, 5, paint);
		//b1.update(0.5);
		//canvas.drawBitmap(myImage, x,y, paint);
		//paint.setColor(Color.GREEN);
		//canvas.drawCircle((int) b2.x, (int) b2.y, 5, paint);
		//b2.update(0.5);
		///canvas.drawBitmap(myImage2, 100, Gy,paint);
		//paint.setColor(Color.YELLOW);
		//canvas.drawCircle((int) b3.x, (int) b3.y, 5, paint);
		//b3.update(0.5);
		//canvas.drawBitmap(myImage3, 450, Yy, paint);
		
		int height = this.getResources().getDisplayMetrics().heightPixels;
		

		if(y<=height){
			y =y+ (YMove*lol);
		}
		if(y>=height){
			lol = lol * (-1);
			y=height;
		}
		if(y<=0){
			lol = lol * (-1);
			y=0;
		}
		
		if(Gy<=height){
			Gy = Gy + (GMove * Glol);
		}
		if(Gy>=height){
			Glol = Glol * (-1);
			Gy = height;
		}
		if(Gy<=0){
			Glol = Glol * (-1);
			Gy =0;
		}
		
		if(Yy<=height){
			Yy = Yy + (YMove * Ylol);
		}
		if(Yy>=height){
			Ylol = Ylol * (-1);
			Yy = height;
		}
		if(Yy<=0){
			Ylol = Ylol * (-1);
			Yy =0;
		}
		
		
		
	}


	@Override
	public boolean onTouch(View arg0,MotionEvent arg1){
		
		double x = arg1.getX();
		
		Display display = getWindowManager().getDefaultDisplay();
		
		int randX, randY;
		
		if(x > (display.getWidth()/2)){
			randX = (int)(Math.random() * display.getWidth());
			randY = (int)(Math.random() * display.getHeight());
			
			LOL.add(new Ball(randX,randY,0,0,display.getWidth(),display.getHeight()));
		}
		else if (x< (display.getWidth()/2)){
			LOL.clear();
		}
		
		return(true);
	}
	

}
