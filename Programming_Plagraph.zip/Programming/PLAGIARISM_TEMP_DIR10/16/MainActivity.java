package merand.tau.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import java.util.ArrayList;
import java.util.Random;

import static android.view.View.OnTouchListener;


public class MainActivity extends Activity implements OnTouchListener {

    ArrayList<Ball> B=new ArrayList<Ball>();


    DrawView drawView;
    @Override
    public boolean onTouch(View arg0, MotionEvent arg1){
        int midpoint=drawView.getWidth()/2;
        if (arg1.getX()>midpoint){ //right
            Random randInt=new Random();
            int xpos=randInt.nextInt(drawView.getWidth());
            int ypos=randInt.nextInt(drawView.getHeight());
            Display display = getWindowManager().getDefaultDisplay();
            DisplayMetrics displaymetrics = new DisplayMetrics();
            display.getMetrics(displaymetrics);
            int width=displaymetrics.widthPixels;
            int height = displaymetrics.heightPixels;
            Ball b=new Ball(xpos, ypos,0,0,width,height);
            B.add(b);

        }
        else if (arg1.getX()<midpoint){
            B.clear();

        }



        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
        WindowManager.LayoutParams.FLAG_FULLSCREEN);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        drawView = new DrawView(this);
        setContentView(drawView);
        drawView.requestFocus();

        drawView.setOnTouchListener(this);

        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics displaymetrics = new DisplayMetrics();
        display.getMetrics(displaymetrics);
        int width=displaymetrics.widthPixels;
        int height = displaymetrics.heightPixels;
        Ball b1=new Ball(100, 100, 2, 0, width, height);
        Ball b2= new Ball(200, 200, 3, 0, width, height);
        Ball b3= new Ball(300, 180, 1, 0, width, height);
        B.add(b1);
        B.add(b2);
        B.add(b3);


    }

    public void doDraw(Canvas canvas, Paint paint) {
        for(Ball b:B) {
            b.update(0.5);
            canvas.drawCircle((int) b.x, (int) b.y, 5, paint);
        }
    }



}
