package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener {
	ArrayList<Ball> sci =new ArrayList<Ball>();
	Ball b1;
	Ball b2;
	Ball b3;
	int width, height;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		DrawView drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this); //Add this line when doing touch events
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();

		b1 = new Ball(100, 100, 2, 0, width, height);
		b2 = new Ball(200, 200, 3, 0, width, height);
		b3 = new Ball(300, 180, 1, 0, width, height);
		//Ball b4 = new Ball(1000, 500, 10, 10, width, height);
		sci.add(b1);
		sci.add(b2);
		sci.add(b3);
		//sci.add(b4);
		
	}
	public void doDraw(Canvas canvas, Paint paint) {
		
		for (int i = 0;i<sci.size();i++){
			sci.get(i).update(0.5);
		}
		for (int i = 0;i<sci.size();i++){
			
		canvas.drawCircle((int) sci.get(i).x,(int)sci.get(i).y, (float)50, paint);
	}
	}


	@Override
	public boolean onTouch(View arg0, MotionEvent arg1) {	
		Random x = new Random();
		Random y = new Random();
		int X = x.nextInt(width);
		int Y = y.nextInt(height);
		
		//while(X<=width && Y<=height)
		Ball bn =new Ball(X, Y, 0, 0, width, height);
		if (arg1.getX()>width/2){
			sci.add(bn);
		}
		if(arg1.getX()<width/2){
			 sci.clear();
		}
		return false;
	}

}
