package com.example.animationgame;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;


public class MainActivity extends Activity implements OnTouchListener {

	double height;
	double width;
	double xspeed;

	
	DrawView drawView;
	ArrayList<Ball> lion = new ArrayList<Ball>();

	@SuppressWarnings("deprecation")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener((OnTouchListener) this); // Add this line
																// when doing
																// touch events
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		Ball b1 = new Ball(100, 100, 2, 0, width, height);
		lion.add(b1);
		
		Ball b2 = new Ball(200, 200, 3, 0, width, height);
		lion.add(b2);

		Ball b3 = new Ball(300, 180, 1, 0, width, height);
		lion.add(b3);

	}

	@SuppressLint("NewApi") public void doDraw(Canvas canvas, Paint paint) 
	{
		for (Ball b:lion)
		{
			canvas.drawCircle((int) b.x, (int) b.y, 5, paint);
			b.update(0.5);
		}
	
	}

	@SuppressLint("ClickableViewAccessibility") @Override
	public boolean onTouch(View arg0, MotionEvent arg1) 
	{
		   if (arg1.getX() >= (width/2)) 
		   {
			   lion.add(new Ball(Math.random()*width,Math.random()*height,0.0,0.0,width,height));
			
				return true;
		   }
	      else  if (arg1.getX() <= (width/2)) 
	      {
	    	  lion.clear();
	      }
		   
		  return false;
	    
  }
}

