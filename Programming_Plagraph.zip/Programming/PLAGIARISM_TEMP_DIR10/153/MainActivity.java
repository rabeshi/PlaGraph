package com.example.animationgame;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnTouchListener;

public class MainActivity extends Activity implements OnTouchListener {
	
	double screenheight ,screenwidth;
	
	DrawView drawView;
	Ball balll1,balll2,balll3;
	ArrayList <Ball> mybouncingballs = new ArrayList<Ball>(); 
	
	@SuppressWarnings("deprecation")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
		Display display = getWindowManager().getDefaultDisplay();
		screenwidth = display.getWidth();
		screenheight = display.getHeight();
		
	Ball balll1= new Ball(100.0,100.0,2.0,2.0,screenwidth,screenheight);
	Ball balll2= new Ball(200.0,200.0,2.0,2.0,screenwidth,screenheight);
	Ball balll3= new Ball(300.0,180.0,2.0,2.0,screenwidth,screenheight);
		//myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		//myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
		//myImage3=BitmapFactory.decodeResource(getResources(), R.drawable.ball3);
     mybouncingballs.add(balll1);
     mybouncingballs.add(balll2);
     mybouncingballs.add(balll3);
     
	}


	@SuppressLint("NewApi") public void doDraw(Canvas canvas, Paint paint) {
	
	for (int i = 0 ; i < mybouncingballs.size();i++)
	{
		canvas.drawCircle((int) mybouncingballs.get(i).x, (int)mybouncingballs.get(i).y, 5, paint);
		mybouncingballs.get(i).update(0.5);
	}
		
	//canvas.drawCircle((int) balll1.x, (int) balll1.y, 5, paint);
	//balll1.update(0.5);
	//canvas.drawCircle((int) balll2.x, (int) balll2.y, 5, paint);
	//balll2.update(0.5);
	//canvas.drawCircle((int) balll3.x, (int) balll3.y, 5, paint);
	//balll3.update(0.5); 
	  
		//c=c+number1;
		//greenbally=greenbally+number2;
		//yellowbally=yellowbally+number3;
//if ((c>screenheight)||(c< 0))
//{
	//number1=-number1;	
//}
//else if( (greenbally>screenheight)||(greenbally<0))
	//{
	//	number2=-number2;
		
	}


	@SuppressLint("ClickableViewAccessibility") @Override
	public boolean onTouch(View arg0, MotionEvent arg1) {
		if (arg1.getX()>=(0.5*screenwidth))//right touch
		{
			//for (int i=0;i<mybouncingballs.size();i++)
			//{
				//mybouncingballs.get(i).setY(50.0);
				//mybouncingballs.get(i).setXspeed(-1*(mybouncingballs.get(i).xspeed));//mybouncingballs.get(i).update(0.5);
		//}
			mybouncingballs.add(new Ball(Math.random()*screenwidth,Math.random()*screenheight,0.0,0.0,screenwidth,screenheight));
		
			

		return true;
		}
		else if  (arg1.getX()<=(0.5*screenwidth))//left touch
		{
			mybouncingballs.clear();
		}
		return false;
	}



}		
	

	


	
		
	


