package com.example.balls;

import java.util.ArrayList;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;
import java.util.Random;
@SuppressWarnings("unused")
public class MainActivity extends Activity implements OnTouchListener {
	Ball b1;
	Ball b2;
	Ball b3;	
	int width,height;
	Bitmap myImage;
	boolean check = false;
	DrawView drawView;
	ArrayList<Ball> balls = new ArrayList<Ball>();
	
	Random rand = new Random();
	
	@SuppressWarnings("deprecation")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
		WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		
		b1 = new Ball(180,200, 3, 0, width, height);
		b2 = new Ball(100, 180, 2, 0, width, height);
		b3 = new Ball(300, 200,1, 0, width, height);
		balls.add(b1);
		balls.add(b2);
		balls.add(b3);
	}

	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		
		for(int i=0;i<balls.size();i++)
		{
		canvas.drawCircle((int) balls.get(i).x, (int) balls.get(i).y, 5, paint);
		balls.get(i).update(0.5);
		}

	}

	@Override
	public boolean onTouch(View arg0, MotionEvent arg1) {
		
		if (arg1.getX()>(width/2)){	
			Ball b5 = new Ball(rand.nextInt(width/2),rand.nextInt(height) , 0, 0, width, height);
			balls.add(b5);
			b5.y = 50;
			
			
	
		}
		
		else {
			balls.clear();
			}
		
		return false;
	}

}
