package com.example.applicationgame;
import java.util.ArrayList;
import java.util.Iterator;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
//import android.graphics.BitmapFactory;

@SuppressLint("ClickableViewAccessibility") public class MainActivity extends Activity implements OnTouchListener {
	ArrayList<Ball>balls=new ArrayList<Ball>();
	DrawView drawView;
	Ball b1;
	Ball b2;
	Ball b3;
	@Override
	public void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	// Set full screen view
	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
	WindowManager.LayoutParams.FLAG_FULLSCREEN);
	requestWindowFeature(Window.FEATURE_NO_TITLE);
	drawView = new DrawView(this);
	setContentView(drawView);
	drawView.requestFocus();
	drawView.setOnTouchListener(this); //Add this line when doing touch events
	Display display = getWindowManager().getDefaultDisplay();
	int width = display.getWidth();
	int height = display.getHeight();
	b1 = new Ball(100, 100, 2, 0, width, height);
	b2 = new Ball(200, 200, 3, 0, width, height);
	b3 = new Ball(300, 180, 1, 0, width, height);
	balls.add(b1);
	balls.add(b2);
	balls.add(b3);
	}
	public void doDraw(Canvas canvas, Paint paint) {
		Iterator<Ball> track=balls.iterator();
		while(true)
		{
			if(!track.hasNext())
			{
				return;
			}
			Ball b=track.next();
			canvas.drawCircle((int)b.x,(int)b.y,5,paint);
			b.Update(0.5);
		}
	}
	
	
	public boolean onTouch(View arg0, MotionEvent arg1) 
	{
		Display display=getWindowManager().getDefaultDisplay();
		int width=display.getWidth();
		int height=display.getHeight();
		int s=arg1.getAction();
		if(s==MotionEvent.ACTION_DOWN)
		{
			int a=(int)arg1.getX();
			if(a<width/2)
			{
				Ball newA=new Ball((width/2)*Math.random(),Math.random(),0,0,width,height);
				balls.add(newA);
			}
			else if(a>width/2)
			{
				balls.clear();
			}
		}
		return false;
	}
}
