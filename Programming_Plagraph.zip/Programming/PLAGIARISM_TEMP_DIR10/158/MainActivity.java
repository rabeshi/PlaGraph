package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener{
	ArrayList<Ball> arr = new ArrayList<Ball>();
	Bitmap myImage;
	DrawView drawView;
	int width;
	int height;
	
	Random rand = new Random();
	Ball b1;
	Ball b2;
	Ball b3;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		//myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.requestFocus();
		drawView.setOnTouchListener(this); //Add this line when doing touch events
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		b1 = new Ball(100, 100, 2, 0, width, height);
		b2 = new Ball(200, 200, 3, 0, width, height);
		b3 = new Ball(300, 180, 1, 0, width, height);
		arr.add(b1);
		arr.add(b2);
		arr.add(b3);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		for(int i =0;i<arr.size();i++){
		canvas.drawCircle((int) arr.get(i).x, (int) arr.get(i).y, 5, paint);
		arr.get(i).update(0.5);
		}
		//canvas.drawCircle((int) b2.x, (int) b2.y, 5, paint);
		//b2.update(0.5);
		//canvas.drawCircle((int) b3.x, (int) b3.y, 5, paint);
		//b3.update(0.5);

//		
	}


	@Override
	public boolean onTouch(View arg0, MotionEvent arg1) {
		// TODO Auto-generated method stub
		if(arg1.getX()>width/2){
			Ball fea = new Ball(rand.nextInt(width/2), rand.nextInt(height), 0, 0, width, height);
			arr.add(fea);
			//Ball abs =new Ball(rand.nextInt(width/2), rand.nextInt(height), 0, 0, width, height);
			//arr.add(abs);
		}
		
		else{
			arr.clear();
		}
			
		return false;
	}

}
