package com.example.animationgame;
 
import java.util.ArrayList;



import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener{
	DrawView drawView;
	ArrayList<Ball> ball = new ArrayList();
	int width, height; 
	

	
	//@SuppressLint("ClickableViewAccessibility")
	//@SuppressWarnings("deprecation")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		 height = display.getHeight();
		
		
		
	 
	ball.add(new Ball(100, 100, 2, 0, width, height));
	ball.add(new Ball(200, 200, 3, 0, width, height));
	ball.add(new Ball(300, 180, 1, 0, width, height));
		
	
	}

	public void doDraw(Canvas canvas, Paint paint) {
		for(int i=0; i < ball.size(); i++){
			canvas.drawCircle((int) ball.get(i).x, (int)ball.get(i).y, 5, paint);
			ball.get(i).update(0.5);
			
		}
		
	}

	public boolean onTouch(View arg0, MotionEvent arg1){
		
		int touch = (int) arg1.getX();
		
		if(touch >= width/2){
			int x = (int) (Math.random() * (width));
			int y = (int) (Math.random() * (height));
			
			ball.add(new Ball(x,y,0,0,width,height));
		
		}else if(touch < width/2){
			for(int i=0; i<ball.size(); i++){
			ball.remove(i);
			
		}
		
		
		
	}
	// y = y + 10;
		return true;
	}}
	
