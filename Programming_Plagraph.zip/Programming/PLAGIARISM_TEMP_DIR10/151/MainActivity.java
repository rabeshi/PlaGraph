package com.example.lab6;


import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener{
	Random m=new Random();
	ArrayList<Ball>mogau=new ArrayList<Ball>();
	Ball b1;
	Ball b2;
	Ball b3;
	@Override
	public void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	// Set full screen view
	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
	WindowManager.LayoutParams.FLAG_FULLSCREEN);
	requestWindowFeature(Window.FEATURE_NO_TITLE);
	DrawView drawView  = new DrawView(this);
	setContentView(drawView);
	drawView.requestFocus();
	drawView.setOnTouchListener(this); //Add this line when doing touch events
	Display display = getWindowManager().getDefaultDisplay();
	int width = display.getWidth();
	int height = display.getHeight();
	b1 = new Ball(100, 100, 2, 0, width, height,10);
	b2 = new Ball(200, 200, 3, 0, width, height,10);
	b3 = new Ball(300, 180, 1, 0, width, height,10);
	mogau.add(b1);
	mogau.add(b2);
	mogau.add(b3);
	
	}
	public void doDraw(Canvas canvas, Paint paint) {
//	canvas.drawCircle((int) b1.x, (int) b1.y, 10, paint);
//	b1.update(0.5);
//	canvas.drawCircle((int) b2.x, (int) b2.y, 10, paint);
//	b2.update(0.5);
//	canvas.drawCircle((int) b3.x, (int) b3.y, 10, paint);
//	b3.update(0.5);
	
	for(int i=0;i<mogau.size();i++)
	{	
		mogau.get(i).update(0.5);
		canvas.drawCircle((int)mogau.get(i).x,(int) mogau.get(i).y, 20, paint);
	}

	}
	@Override
	public boolean onTouch(View arg0, MotionEvent arg1) {
		
		
		
		Display display = getWindowManager().getDefaultDisplay();
		int width = display.getWidth();
		int height = display.getHeight();
		
		
		int x= m.nextInt(width-0)+0;
		int y= m.nextInt(height-0)+0;
		
		int press=arg1.getAction();
		if(press==MotionEvent.ACTION_DOWN)
		{
			int i=(int) arg1.getX();
			
			if(i>=(width/2))
			{
				Ball v = new Ball(x,y,3,2,width,height,10);
				mogau.add(v);
			}else{
				mogau.clear();
			}
			
		}
		
		return false;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}	

