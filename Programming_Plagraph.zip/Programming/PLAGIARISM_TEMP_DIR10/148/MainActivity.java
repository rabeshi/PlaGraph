package com.example.animationgame;
import java.util.ArrayList;
import java.util.Random;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener {
	int x=30,b=20,g=100, y=50;
	
	DrawView drawView;
	
	Ball b1;
	Ball b2;
	Ball b3;
	ArrayList<Ball> arr = new ArrayList<Ball>();

	@SuppressWarnings("deprecation")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this); //Add this line when doing touch events
		Display display = getWindowManager().getDefaultDisplay();
		double width = display.getWidth();
		double height = display.getHeight();
		b1 = new Ball(100, 100, 2, 0, width, height);
		b2 = new Ball(200, 200, 3, 0, width, height);
		b3 = new Ball(300, 180, 1, 0, width, height);
		arr.add(b1);
		arr.add(b2);
		arr.add(b3);
		
	}
	@SuppressWarnings ("deprecation")
	public boolean onTouch(View arg0, MotionEvent arg1){
		int x = (int) arg1.getX();
		Display display = getWindowManager().getDefaultDisplay();
		if(x>=display.getWidth()/2){
			arr.clear();
		}
		else{
			Random rand = new Random();
			double xrand = rand.nextInt(display.getWidth());
			double yrand = rand.nextInt(display.getHeight());
			Ball temp = new Ball(xrand,yrand,0,0,display.getWidth(),display.getHeight());
			arr.add(temp);
		}
		
		return true;
	}


	public void doDraw(Canvas canvas, Paint paint) {
		
		for(int i=0; i<arr.size(); i++){
			Ball curr = arr.get(i);
			canvas.drawCircle((int) curr.x, (int) curr.y, 5, paint);
			curr.update(0.5);
		}
	}
}