package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener {
	
	ArrayList<Ball> balls;
	Random rand;
	
	int height,width;
	
	DrawView drawView;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
		WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
		
		//get screen dimensions
		DisplayMetrics metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		height = metrics.heightPixels;
		width = metrics.widthPixels;
		
		/*//deprecated
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		*/
		
		//initialise random generator
		rand = new Random();
		
		//initialise balls
		balls = new ArrayList<Ball>();
		addBall(100, 100, 2, 0);
		addBall(200, 200, 3, 0);
		addBall(300, 180, 1, 0);
	}
	
	public void addBall(double x, double y, double xspeed, double yspeed) {
		balls.add(new Ball(x,y,xspeed,yspeed,width,height));
	}
	

	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.RED);
		for(Ball b : balls) {
			b.update(0.5);
			canvas.drawCircle((int)b.x, (int)b.y, Ball.radius, paint);
		}
		
	}
	
	
	public boolean onTouch(View arg0, MotionEvent arg1) {
		double x = arg1.getX();
		//double y = arg1.getY();
		
		if(x<width/2) {
			balls.clear(); //clear screen of balls
			/*for(Ball b : balls) {
				b.setY(50);
			}*/
		}
		else {
			addBall(rand.nextInt(width),rand.nextInt(height),0,0);
			/*for(Ball b : balls) {
				b.flipX();
			}*/
			
		}
		
		return true; //necessary?
	}

}
