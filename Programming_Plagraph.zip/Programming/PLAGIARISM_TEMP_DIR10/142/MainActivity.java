package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener {
	
	int height, width;
	ArrayList<Ball> ballArr = new ArrayList<Ball>();
	
	DrawView drawView;
	
	
	Ball b1;
	Ball b2;
	Ball b3;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
		WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this); 
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		b1 = new Ball(100, 100, 2, 0, width, height);
		ballArr.add(b1);
		b2 = new Ball(200, 200, 3, 0, width, height);
		ballArr.add(b2);
		b3 = new Ball(300, 180, 1, 0, width, height);
		ballArr.add(b3);
		}
	
		public void doDraw(Canvas canvas, Paint paint) {
			for(int i=0; i<ballArr.size(); i++)
			{
				canvas.drawCircle((int) ballArr.get(i).x, (int) ballArr.get(i).y, 5, paint);
				ballArr.get(i).update(0.5);
			}
		}
	
	public boolean onTouch(View arg0, MotionEvent arg1){
			
			
			Random ran = new Random();
			if(arg1.getX() >= (width/2))
			{
			
				Ball b4 = new Ball(ran.nextInt(width), ran.nextInt(height), 0, 0, width, height);
				ballArr.add(b4);
			}
			else
			{
				ballArr.clear();
			}
			
			return true;
		
		}
}
