package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.*;
import android.view.View.OnTouchListener;
public class MainActivity extends Activity implements OnTouchListener{
	ArrayList <Ball> balls = new ArrayList<Ball>();
	Ball b1;
	Ball b2;
	Ball b3;
	int x=30,y=20, x2 = 100, y2 = 100, x3 = 300, y3 = 50;
	Bitmap myImage;
	Bitmap myImage2;
	Bitmap myImage3;
	DrawView drawView;
	Boolean falling1 = true;
	Boolean falling2 = true;
	Boolean falling3 = true;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
		Display display = getWindowManager().getDefaultDisplay(); 

		b1 = new Ball(30, 20, 15, 4,  (double)display.getWidth(), (double)display.getHeight());
		b2 = new Ball(100, 150, 20, 5,  (double)display.getWidth(), (double)display.getHeight());
		b3 = new Ball(250, 85, 1, 3,  (double)display.getWidth(), (double)display.getHeight());
		balls.add(b1);
		balls.add(b2);
		balls.add(b3);

		//		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball1);
		//		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
		//		myImage3=BitmapFactory.decodeResource(getResources(), R.drawable.ball3);

	}

	public boolean onTouch(View arg0, MotionEvent arg1){
		Display display = getWindowManager().getDefaultDisplay(); 
		switch(arg1.getAction()){
		case MotionEvent.ACTION_DOWN:
				if(arg1.getX() > display.getWidth()/2 ){
					int xb = (int) (Math.random()*display.getWidth());
					int yb = 0;
					Ball b = new Ball(xb, yb, 0, 0, display.getWidth(), display.getHeight());
					balls.add(b);
//					b1.y = 50;
//					b2.y = 50;
//					b3.y = 50;
				}else{
					balls.clear();
					
//					b1.xspeed = -b1.xspeed;
//					b2.xspeed = -b2.xspeed;
//					b3.xspeed = -b3.xspeed;
				}
			
			break;
		}

		return true;
	}

	public void doDraw(Canvas canvas, Paint paint) {

	//	paint.setColor(Color.BLACK);
		//canvas.drawText(balls.size()+"", 0, 20, paint);
		Random rnd = new Random();
		paint.setARGB(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
		for(int i = 0; i < balls.size(); i++){
			//canvas.drawText(i+"", (int)balls.get(i).x-10,(int) balls.get(i).y, paint);
			balls.get(i).update(0.5,0);
			canvas.drawCircle((int)balls.get(i).x, (int) balls.get(i).y, 5, paint);

		}
		//		}
		//		b1.update(0.5, 0);
		//		canvas.drawCircle((int)b1.x, (int) b1.y, 5, paint);
		//		paint.setColor(Color.GREEN);
		//		b2.update(0.5, 0);
		//		canvas.drawCircle((int)b2.x, (int) b2.y, 5, paint);
		//		paint.setColor(Color.YELLOW);
		//		b3.update(0.5, 0);

		Display display = getWindowManager().getDefaultDisplay(); 
		int screenHeight = display.getHeight();

		//		if(falling1){
		//			y = y + 10;
		//
		//		} else{
		//			y = y-10;
		//		}
		//		if(y > screenHeight- b1.y || y < 0){
		//				falling1 = !falling1;				
		//		}
		//		
		//		
		//		if(falling2){
		//			y2 = y2 + 20;
		//
		//		} else{
		//			y2 = y2-20;
		//		}
		//		if(y2 > screenHeight - b2.y  || y2 < 0){
		//				falling2 = !falling2;				
		//		}
		//		
		//		
		//		if(falling3){
		//			y3 = y3 + 15;
		//
		//		} else{
		//			y3 = y3-15;
		//		}
		//		if(y3 > screenHeight - b3.y || y3 < 0){
		//				falling3 = !falling3;				
		//		}
	}

}
