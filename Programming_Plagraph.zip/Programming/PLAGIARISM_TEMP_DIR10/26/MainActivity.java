package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener{
	
	ArrayList<Ball> alBalls = new ArrayList<Ball>();
	
	
	double width, height;
	DrawView drawView;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
		WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);//this changed
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		alBalls.add(new Ball(100, 100, 2, 0, width, height));
		alBalls.add(new Ball(200, 200, 3, 0, width, height));
		alBalls.add(new Ball(300, 180, 1, 0, width, height));
	}


	public void doDraw(Canvas canvas, Paint paint) {
		for (int i = 0; i < alBalls.size(); i++){
			alBalls.get(i).update(0.5);
			canvas.drawCircle((int) alBalls.get(i).x, (int) alBalls.get(i).y, 5, paint);
		}
	}


	@Override
	public boolean onTouch(View arg0, MotionEvent arg1) {
		double touch = arg1.getX();
		if (touch > (width/2)){
			Random rand = new Random();
			double xPos = rand.nextInt((int)width);
			double yPos = (int)Math.random() * width;
			alBalls.add	(new Ball (xPos,yPos,0,0,width,height));
		} else if (touch < (width/2)){
			alBalls.clear();
		}
		return false;
	}
	

}
