package com.example.animationgame;
import java.util.ArrayList;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

 public  class MainActivity extends Activity implements OnTouchListener{
	Ball b1;
	Ball b2;
	Ball b3;
	ArrayList<Ball> balls= new ArrayList<Ball> ();
	DrawView drawView;

	@SuppressLint({ "NewApi", "ClickableViewAccessibility" }) @Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
	Display display = getWindowManager().getDefaultDisplay();
		Point size = new Point();
	    display.getSize(size); 
	      int height= size.y;
	      int width = size.x;
		for (int i=0;i<3;i++)
		{
			Ball mess= new Ball((double)25*(i+1),(double)50*(i+1),2,0,width,height);
			balls.add(mess);
		}
	}


	@SuppressLint
	("NewApi")public void doDraw(Canvas canvas, Paint paint) {
		for(int i=0;i<balls.size();i++)
		{
			paint.setColor(Color.BLUE);
			balls.get(i).update(0.5);
			canvas.drawCircle((int )balls.get(i).x,(int)balls.get(i).y,5,paint);
		}
	
}


	
	@SuppressLint("ClickableViewAccessibility") @SuppressWarnings("deprecation")
	@Override
	public boolean onTouch(View arg0, MotionEvent arg1) {
		// TODO Auto-generated method stub
		Display j=getWindowManager().getDefaultDisplay();
		if(arg1.getX()<j.getWidth()/2)
		{
			balls.clear();
		}
		else
		{
			Ball l= new Ball((double)100*Math.random(),(double)100*Math.random(),2,0,j.getWidth(),j.getHeight());
			balls.add(l);
		}
		
		return false;
	}
	
	
 }