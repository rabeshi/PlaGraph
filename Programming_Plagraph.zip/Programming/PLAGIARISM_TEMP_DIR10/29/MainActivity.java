package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;


import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;


 public class MainActivity extends Activity implements OnTouchListener {
	int x=30,y=20;
	int speed=1,speed2=1;
	int speed1=1,i=100,k,j=100;
	int d=50,c=300;
	
	Ball ball1,ball2,ball3;

	ArrayList<Ball> ballz =new ArrayList<Ball>();
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
		
		Display display = getWindowManager().getDefaultDisplay();
		double width = display.getWidth();
		int height = display.getHeight();
		
		
		ball1 = new Ball(100, 100, 2, 2, width, height);
		ball2 = new Ball(200, 300, 2, 2, width, height);
		ball3 = new Ball(30, 180, 2, 2, width, height);
		
		ballz.add(ball1);
		ballz.add(ball2);
		ballz.add(ball3);
		
	}


	 public void doDraw(Canvas canvas, Paint paint) {
		
		 
		 for(Ball i : ballz){
		paint.setColor(Color.BLACK);
		 i.Update(0.5);
		 canvas.drawCircle((int)i.x, (int)i.y,5, paint);
		 }

	}
	 public boolean onTouch(View arg0, MotionEvent arg1){
		 
		   Display display = getWindowManager().getDefaultDisplay();
			int width = display.getWidth();
			 int height = display.getHeight();
			
			//
		
			if(arg1.getX() >= width/2){
			/*	ball1.setY(50);
				ball2.setY(50);
				ball3.setY(50);
				
				ball1.setXspeed(-ball1.xspeed);
				ball2.setXspeed(-ball2.xspeed);
				ball3.setXspeed(-ball3.xspeed);*/
				
				Random position =new Random();
				Ball i =new Ball(position.nextInt(width),position.nextInt(height),0,0,width,height);
				ballz.add(i);
				
				
			}
			
			if(arg1.getX() <= width/2)
				ballz.clear();
			
			
			return true;
	 }

}
