package com.example.animationgame;

import java.util.ArrayList;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener{
	int x=30,y=20;
	double width,height;
	ArrayList<Ball> ballArr=new ArrayList<Ball>();
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
		Display display=getWindowManager().getDefaultDisplay();
		width=display.getWidth();
		height=display.getHeight();
		ballArr.add(new Ball(100,100,2,0,width,height));
		ballArr.add(new Ball(200,200,3,0,width,height));
		ballArr.add(new Ball(300,180,1,0,width,height));
		
	}


	public void doDraw(Canvas canvas, Paint paint) 
	{
		paint.setColor(Color.BLACK);
		for(Ball b:ballArr)
		{
			canvas.drawCircle((int)b.x, (int)b.y, 5, paint);
			b.update(0.5);
		}
	}


	@Override
	public boolean onTouch(View v, MotionEvent me) {
		switch(me.getAction())
		{
			case MotionEvent.ACTION_DOWN:
				if(me.getX()>width/2)
				{
					ballArr.add(new Ball((int)(Math.random()*width),(int)(Math.random()*height),0,0,width,height));
				}
				else
				{
					ballArr.clear();
				}
				break;
		}
		
		return false;
	}

}
