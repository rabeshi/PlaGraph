package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener {
	Ball b1;
	Ball b2;
	Ball b3;
	int height,width;
	DrawView drawView;
	ArrayList <Ball> Array = new ArrayList <Ball>();
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
		WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this); //Add this line when doing touch events
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		b1 = new Ball(100, 100, 2, 0, width, height);
		Array.add(b1);
		b2 = new Ball(200, 200, 3, 0, width, height);
		Array.add(b2);
		b3 = new Ball(300, 180, 1, 0, width, height);
		Array.add(b3);
	}
	
	public void doDraw(Canvas canvas, Paint paint){
		//canvas.drawCircle((int) b1.x, (int) b1.y, 5, paint);
		//b1.update(0.5);
		//canvas.drawCircle((int) b2.x, (int) b2.y, 5, paint);
		//b2.update(0.5);
		//canvas.drawCircle((int) b3.x, (int) b3.y, 5, paint);
		//b3.update(0.5);
		for(int i = 0;i<Array.size();i++){
			Array.get(i).update(0.5);
			canvas.drawCircle((int) Array.get(i).x, (int) Array.get(i).y, 5, paint);
		}
	}

	public boolean onTouch(View arg0, MotionEvent arg1){
		
		float xtouch = arg1.getX();
		Random rand = new Random();
		int randx = rand.nextInt(Math.round(width/2));
		int randy = rand.nextInt(height);
		
		if(xtouch<width*0.5){
			//b1.flip();
			//b2.flip();
			//b3.flip();
			
		}
		if(xtouch<width*0.5){
			Array.add(new Ball(randx, randy, 0, 0, width, height));
		}
		
		if(xtouch>width*0.5){
			
			Array.clear();
			
		}
		
		return true;
	}

}
