package com.example.animationgame;

import java.util.ArrayList;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;


public class MainActivity extends Activity implements OnTouchListener {
	DrawView drawView;
	int Width, Height;
	
	ArrayList <Ball> ball = new ArrayList();
//	Ball b1;
//	Ball b2;
//	Ball b3;
	@Override
	public void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	// Set full screen view
	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
	WindowManager.LayoutParams.FLAG_FULLSCREEN);
	requestWindowFeature(Window.FEATURE_NO_TITLE);
	drawView = new DrawView(this);
	setContentView(drawView);
	drawView.requestFocus();
	drawView.setOnTouchListener(this); //Add this line when doing touch events
	Display display = getWindowManager().getDefaultDisplay();
	Width = display.getWidth();
	Height = display.getHeight();
	
	ball.add(new Ball(100, 100, 2, 0, Width, Height));
	ball.add(new Ball(200, 200, 3, 0, Width, Height));
	ball.add(new Ball(300, 180, 1, 0, Width, Height));
	
	}
	
	public void doDraw(Canvas canvas, Paint paint) {
		
		for(int i =0; i<ball.size(); i ++){
			canvas.drawCircle((int) ball.get(i).x, (int)ball.get(i).y, 5, paint);
			ball.get(i).update(0.5);
		}
	}
	
	
	public boolean onTouch(View arg0, MotionEvent arg1){
		int xtouched = (int) arg1.getX();
		
		Display display = getWindowManager().getDefaultDisplay();
		Width = display.getWidth();
		Height = display.getHeight();
		
		if(xtouched >= Width/2){
			int x = (int) (Math.random() * (Width));
			int y = (int) (Math.random() *(Height));
			
			ball.add(new Ball(x,y,0,0,Width, Height));
			
		}
		else if (xtouched < Width/2){
			for(int i =0; i<ball.size(); i ++){
				ball.remove(i);
			}
		}
		return true;
	}
}
	
	
	
    
