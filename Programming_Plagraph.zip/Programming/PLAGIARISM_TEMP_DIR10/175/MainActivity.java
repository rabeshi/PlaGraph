package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener {
	Ball b1;
	Ball b2;
	Ball b3;
	ArrayList<Ball> ball = new ArrayList<Ball>();
	@Override
	public void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	// Set full screen view
	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
	WindowManager.LayoutParams.FLAG_FULLSCREEN);
	requestWindowFeature(Window.FEATURE_NO_TITLE);
	View drawView = new DrawView(this);
	setContentView(drawView);
	drawView.requestFocus();
	drawView.setOnTouchListener(this); //Add this line when doing touch events
	Display display = getWindowManager().getDefaultDisplay();
	double width = display.getWidth();
	double height = display.getHeight();
//	b1 = new Ball(100, 100, 2, 0, width, height,20);
//	b2 = new Ball(200, 200, 3, 0, width, height,10);
//	b3 = new Ball(300, 180, 1, 0, width, height,30);
	
	Ball b1=new Ball(100, 100, 2, 0, width, height,20);
	ball.add(b1);
	Ball b2=new Ball(200, 200, 3, 0, width, height, 10);
	ball.add(b2);
	Ball b3=new Ball(300, 180, 1, 0, width, height, 30);
	ball.add(b3);
	}
	
	public boolean onTouch(View arg0, MotionEvent arg1) {
		// TODO Auto-generated method stub
		Display display = getWindowManager().getDefaultDisplay();
	int width = display.getWidth();
		int height = display.getHeight();
		int s = arg1.getAction();
		if(s==MotionEvent.ACTION_DOWN){
			int x = (int) arg1.getX();
			if(x>=width/2){
//				b1.y = 50;
//				b2.y  = 50;
//				b3.y = 50;
//				b1.xspeed *=-1;
//				b2.xspeed*=-1;
//				b3.xspeed*=-1;
				Random random= new Random();
				int u=random.nextInt(width)+1;
				int v=random.nextInt(height)+1;
				Ball b4=new Ball(u, v, 0, 0, width, height, 10);
				ball.add(b4);
			}
			else{
				ball.clear();
			}
		}
		
		return false;
	}
	public void doDraw(Canvas canvas, Paint paint) {
//		paint.setColor(Color.GREEN);
//		canvas.drawCircle((int) b1.x, (int) b1.y, 20, paint);
//		b1.update(0.5);
//		canvas.drawCircle((int) b2.x, (int) b2.y, 10, paint);
//		b2.update(0.5);
//		canvas.drawCircle((int) b3.x, (int) b3.y, 30, paint);
//		b3.update(0.5);
		for(int i=0; i<ball.size();i++){
			paint.setColor(Color.GREEN);
			canvas.drawCircle((int) ball.get(i).x, (int) ball.get(i).y, 20, paint);
			//ball.get(i).update(0.5);
			ball.get(i).update(0.5);
			
			}
		}


	
	}

