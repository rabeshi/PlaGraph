package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;



public class MainActivity extends Activity implements OnTouchListener{
	int x=30,y=20,k=100,l=100,m=300,n=50;
	Bitmap myImage,myImage1,myImage2; 
	boolean bottom,bottom1,bottom2 = false;
	int height,width;
	DrawView drawView;
	
	ArrayList<Ball> ballList = new ArrayList<Ball>();
	
	Ball ball0;
	Ball ball1;
	Ball ball2;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this); //Add this line when doing touch events

		
		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		height = (int) ((displaymetrics.heightPixels) - 2.5);
		width = (int) (displaymetrics.widthPixels - 2.5);
				
		
		//myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		//myImage1=BitmapFactory.decodeResource(getResources(), R.drawable.ball1);
		//myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
		//int height0 = height - (myImage.getHeight());
		//int height1 = height - (myImage1.getHeight());
		//int height2 = height - (myImage2.getHeight());
		//int width0 = width - myImage.getWidth();
		//int width1 = width - myImage1.getWidth();
		//int width2 = width - myImage2.getWidth();
		
		//ball0 = new Ball(100, 100, 2, 0, width0, height0);
		//ball1 = new Ball(200, 200, 3, 0, width1, height1);
		//ball2 = new Ball(300, 180, 1, 0, width2, height2);
		ball0 = new Ball(100, 100, 2, 0, width, height);
		ballList.add(ball0);
		ball1 = new Ball(200, 200, 3, 0, width, height);
		ballList.add(ball1);
		ball2 = new Ball(300, 180, 1, 0, width, height);
		ballList.add(ball2);
	}
	
	
	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		
		for (int i = 0 ; i< ballList.size() ; i++){
			canvas.drawCircle((int) ballList.get(i).x, (int) ballList.get(i).y, 5, paint);
			ballList.get(i).update(0.5);
		}
		//canvas.drawBitmap(myImage, (int) ball0.x, (int) ball0.y, paint);
		//canvas.drawCircle((int) ball0.x, (int) ball0.y, 5, paint);
		//canvas.drawBitmap(myImage1, (int) ball1.x, (int) ball1.y, paint);
		//canvas.drawCircle((int) ball1.x, (int) ball1.y, 5, paint);
		//canvas.drawBitmap(myImage2, (int) ball2.x , (int) ball2.y , paint);
		//canvas.drawCircle((int) ball2.x, (int) ball2.y, 5, paint);
		//ball0.update(0.5);
		//ball1.update(0.5);
		//ball2.update(0.5);
		
	
	}
	@Override
	public boolean onTouch(View arg0, MotionEvent arg1){
		float love = arg1.getX(0);
		float hate = arg1.getY(0);
		
		Random numberX = new Random();
		Random numberY = new Random();
		int ranX = numberX.nextInt(width);
		int ranY = numberY.nextInt(height);
		
		if (love > (width/2)){
			Ball newball = new Ball(ranX, ranY, 0, 0, width, height);
			ballList.add(newball);
		}
		else ballList.clear();
		
		
		//float love = arg1.getX(0);
		//if (love > (width/2)){
			//ball0.y = 50;
			//ball1.y = 50;
			//ball2.y = 50;
			//ball0.xspeed = -ball0.xspeed;
			//ball1.xspeed = -ball1.xspeed;
			//ball2.xspeed = -ball2.xspeed;
		//}
		return false;
			
	}


	
	

}
