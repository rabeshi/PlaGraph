package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener{
	/*int x=30,y=20;
	int gx = 100;
	int gy = 100;
	int yx = 300;
	int yy = 50;
	Bitmap myImage;
	Bitmap myImage2;
	Bitmap myImage3;
	boolean bBot1 = false;
	boolean bBot2 =false;
	boolean bBot3 = false;*/
	
	Ball b1;
	Ball b2;
	Ball b3;
	ArrayList<Ball> balls = new ArrayList<Ball>();
	
	DrawView drawView;
@Override
	public boolean onTouch(View arg0, MotionEvent arg1)
	{
		double xval = arg1.getX();
		double yval = arg1.getY();
		
		
		Display display = getWindowManager().getDefaultDisplay();
		if (xval<= display.getWidth()/2)
		{
			balls.clear();
		}
		else
		{
			Random rand = new Random();
			double xrand = rand.nextInt(display.getWidth());
			double yrand = rand.nextInt(display.getHeight());
			Ball newBall = new Ball(xrand, yrand, 0,0,display.getWidth(), display.getHeight());
			balls.add(newBall);
		}
		
		
		
		return(true); //need to return true it tells android that the on touch screen will handel this event,
		///for example we may have a button, which is contained in a linear layout , that is within a linear layout
		//once the user presses the screen and the button is on screen then the compiler needs to know that this event is handeled... in out case we return true so that android knows that the event is handeled
		//and that the event isnt handeled by some other linear layout component perhaps contained within
	}
	
	@Override
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);//this must be added when doing touch events
		Display display = getWindowManager().getDefaultDisplay();
		double width = display.getWidth();
		double height = display.getHeight();
		
		
		b1 = new Ball(100, 100, 2,0,width, height);
		b2 = new Ball(200,200,3,0,width,height);
		b3 = new Ball(300,180,1,0,width,height);
		balls.add(b1);
		balls.add(b2);
		balls.add(b3);
		//myImage =BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		//myImage2 = BitmapFactory.decodeResource(getResources(), R.drawable.dbzball);
		//myImage3 = BitmapFactory.decodeResource(getResources(), R.drawable.pokeball);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		
		/*b1.update(0.5);
		canvas.drawCircle((int)b1.x, (int)b1.y,5,paint);
		b2.update(0.5);
		canvas.drawCircle((int)b2.x, (int)b2.y, 5, paint);
		b3.update(0.5);
		canvas.drawCircle((int)b3.x, (int)b3.y, 5, paint);
		*/
		for (int i =0; i<balls.size(); i++)
		{
			balls.get(i).update(0.5);
			canvas.drawCircle((int)balls.get(i).x, (int)balls.get(i).y,5,paint);
		}
		
		//paint.setColor(Color.BLACK);
		//canvas.drawCircle(x, y, 5, paint);
		//canvas.drawBitmap(myImage,x,y,paint);
		
		
		//paint.setColor(Color.GREEN);
		//canvas.drawCircle(gx, gy, 30, paint);
		//canvas.drawBitmap(myImage2, gx, gy,paint);
		//paint.setColor(Color.YELLOW);
		//canvas.drawBitmap(myImage3, yx, yy,paint);
		//canvas.drawCircle(yx, yy, 10, paint);
		
		//code for getting the width and height of the screen
		//Display display = getWindowManager().getDefaultDisplay();
		//DisplayMetrics metrics = new DisplayMetrics();
		//display.getMetrics(metrics);
		//int screenWidth = metrics.widthPixels;
		//int screenHeight = metrics.heightPixels;
		
		//if  (y > screenHeight || y<0)
		///{
			//bBot1= !bBot1;
		//}
	
		
		//if (bBot1 == false  ) //means is going down
		//{
	//		y = y +10;
			
			
	//	}
		//else 
		//{
			//y=y-10;
		//}
		
		
		///////
		//if  (gy > screenHeight || gy<0)
		//{
			//bBot2= !bBot2;
		//}
	
		
		//if (bBot2 == false  )
		//{
			//gy = gy +10;
			
			
		//}
		//else 
	//	{
		//	gy=gy-10;
		//}
		///////
		
		//////
	/*	if  (yy > screenHeight || yy<0)
		{
			bBot3= !bBot3;
		}
	
		
		if (bBot3 == false  )
		{
			yy = yy +15;
			
			
		}
		else 
		{
			yy=yy-15;
		}
		//////
		
	*/
		
		
		
		
		
		
	}

}
