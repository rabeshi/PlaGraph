package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener {
	int x=30,y=20,z=100,a=50;
	boolean c1=false,c2=false,c3=false;
	Bitmap myImage,myImage1,myImage2;
	DrawView drawView;
	ArrayList<Ball> balls=new ArrayList<Ball>();
	Ball ball0,ball1,ball2;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this); //Add this line when doing touch events
		Display display = getWindowManager().getDefaultDisplay();
		double width = display.getWidth();
		double height = display.getHeight();
		ball0 = new Ball(100, 100, 2, 0, width, height);
		ball1 = new Ball(200, 200, 3, 0, width, height);
		ball2 = new Ball(300, 180, 1, 0, width, height);
		balls.add(ball0);
		balls.add(ball1);
		balls.add(ball2);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		for(int i=0;i<balls.size();i++){
			canvas.drawCircle((int) balls.get(i).x, (int) balls.get(i).y, 5, paint);
			balls.get(i).update(0.5);
		}
		
		/*canvas.drawCircle((int) ball0.x, (int) ball0.y, 5, paint);
		ball0.update(0.5);
		canvas.drawCircle((int) ball1.x, (int) ball1.y, 5, paint);
		ball1.update(0.5);
		canvas.drawCircle((int) ball2.x, (int) ball2.y, 5, paint);
		ball2.update(0.5);
		if(y==0)
			c1=false;
		else if(y>height)
			c1=true;
		if(c1==false)
			y+=10;
		else
			y-=10;
		
		if(z==0)
			c2=false;
		else if(z>height)
			c2=true;
		if(c2==false)
			z+=20;
		else
			z-=20;
		
		if(a<=0)
			c3=false;
		else if(a>height)
			c3=true;
		if(c3==false)
			a+=15;
		else
			a-=15;
		*/
		
			
	}

	public class Ball{
		double x,y,xspeed,yspeed,max_x,max_y;
		
		public Ball(double x,double y,double xspeed,double yspeed,double max_x,double max_y){
			this.x=x;
			this.y=y;
			this.xspeed=xspeed;
			this.yspeed=yspeed;
			this.max_x=max_x;
			this.max_y=max_y;
		}
		public void update(double acc){
			yspeed+=acc;
			y+=yspeed;
			x+=xspeed;
			if((y>max_y)||(y<0)){
				yspeed*=-0.8;
				y=max_y;
			}
			if((x>max_x)){
				xspeed*=-0.8;
				x=max_x;
			}
			if(x<0){
				x=0;
				xspeed=-xspeed;
			}
		}
	}

	public boolean onTouch(View arg0, MotionEvent arg1){
		Display display = getWindowManager().getDefaultDisplay();
		double width = display.getWidth();
		double height = display.getHeight();
		Random random1=new Random(), random2=new Random();
		
		if((arg1.getX())<=(ball0.max_x/2)){
			Ball ball3=new Ball(random2.nextDouble()*height,random1.nextDouble()*height,0.0,0.0,width,height);
			balls.add(ball3);
			
		}
		if((arg1.getX())>(ball0.max_x/2)){
			balls.clear();
		}
		return true;
			
	}
}
/* there were differences between pang.apk and lab6.pdf so I followed pang.apk where I was unsure.  */