package com.example.animationgame;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends Activity implements OnTouchListener
{
   //int x = 30, y = 20, y_green = 100, y_yellow = 50;

   ArrayList<Ball> balls;
   DrawView drawView;
   Point displaySize;
   Random random;

   @Override
   public void onCreate(Bundle savedInstanceState)
   {
      super.onCreate(savedInstanceState);
      // Set full screen view
      getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                                WindowManager.LayoutParams.FLAG_FULLSCREEN);
      requestWindowFeature(Window.FEATURE_NO_TITLE);
      drawView = new DrawView(this);
      setContentView(drawView);
      drawView.requestFocus();
      drawView.setOnTouchListener(this);
      displaySize = new Point();
      getWindowManager().getDefaultDisplay().getSize(displaySize);
      balls = new ArrayList<Ball>();
      random = new Random();
      balls.add(new Ball(100, 100, 2, 0, displaySize.x, displaySize.y));
      balls.add(new Ball(200, 200, 3, 0, displaySize.x, displaySize.y));
      balls.add(new Ball(300, 180, 1, 0, displaySize.x, displaySize.y));
   }


   public void doDraw(Canvas canvas, Paint paint)
   {
      for (Ball b : balls)
      {
         b.update(0.5);
         b.draw(canvas, paint);
      }
   }

   @Override
   public boolean onTouch(View v, MotionEvent event)
   {
      if (event.getX() >= displaySize.x / 2)
      {
         for (Ball b : balls)
         {
            b.flipX();
            b.setY(50);
         }
         balls.add(new Ball(random.nextInt(displaySize.x + 1), random.nextInt(displaySize.y + 1), 0, 0, displaySize.x, displaySize.y));
      }
      else
         balls.clear();

      return true;
   }
}