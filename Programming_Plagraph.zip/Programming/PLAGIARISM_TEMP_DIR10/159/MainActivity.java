package com.example.bouncingballs;

import java.util.ArrayList;
import java.util.Iterator;

import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

@SuppressLint("ClickableViewAccessibility") public class MainActivity extends Activity implements OnTouchListener {

	Ball b1;
	Ball b2;
	Ball b3;
	int width;
	int height;
	
	ArrayList<Ball> myBall = new ArrayList<Ball>();
	
	DrawView drawView;
	
	 
	@Override
	public void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	// Set full screen view
	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
	WindowManager.LayoutParams.FLAG_FULLSCREEN);
	requestWindowFeature(Window.FEATURE_NO_TITLE);
	drawView = new DrawView(this);
	setContentView(drawView);
	drawView.requestFocus();
	drawView.setOnTouchListener(this); //Add this line when doing touch events
	Display display = getWindowManager().getDefaultDisplay();
	@SuppressWarnings("deprecation")
	int width = display.getWidth();
	@SuppressWarnings("deprecation")
	int height = display.getHeight();
	//b1 = new Ball(100, 100, 2, 0, width, height);
	b1 = new Ball(100, 100, width, height);
	myBall.add(b1);
	//b2 = new Ball(200, 200, 3, 0, width, height);
	b2 = new Ball(200, 200, width, height);
	myBall.add(b2);
	//b3 = new Ball(300, 180, 1, 0, width, height);
	b3 = new Ball(300, 180, width, height);
	myBall.add(b3);
	
	
	}
	public void doDraw(Canvas canvas, Paint paint) {
		
		Iterator<Ball> it = myBall.iterator();
		
		do{
			if(it.hasNext()){
				Ball myBall = (Ball)it.next();
				canvas.drawCircle((int) myBall.x, (int) myBall.y, 5, paint);
				myBall.update(0.5);
			}else{
				return;
			}
		}while(true);
	//canvas.drawCircle((int) b1.x, (int) b1.y, 5, paint);
	//b1.update(0.5);
	//canvas.drawCircle((int) b2.x, (int) b2.y, 5, paint);
	//b2.update(0.5);
	//canvas.drawCircle((int) b3.x, (int) b3.y, 5, paint);
	//b3.update(0.5);
	}
	
	public boolean onTouch(View arg0, MotionEvent arg1) {

		if(arg1.getX() < width/2){
			myBall.clear();
		}else{
			Ball newBall = new Ball((width/2)*Math.random(),height*Math.random(), width, height);
			myBall.add(newBall);
		}
		
		return true;
		
	}
    
}
