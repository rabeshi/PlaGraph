package com.example.bouncingballapp2;

import java.util.ArrayList;
import java.util.Random;
import java.util.RandomAccess;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener {
	int x=30,y=20,a=100,b=100,c=300,d=50, flip3 = -1,flip2 = -1, flip = -1;
	
	Bitmap myImage;
	Bitmap secondImage;
	Bitmap thirdImage;
	
	DrawView drawView;
	Ball b1;
	Ball b2;
	Ball b3;
	int height, width;
	

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
		drawView.setOnTouchListener(this);
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		b1 = new Ball(100, 100, 2, 2, width, height);
		b2 = new Ball(200, 200, 3, 3, width, height);
		b3 = new Ball(300, 180, 1, 1, width, height);
		
		CollectionBalls.add(b1);
		CollectionBalls.add(b2);
		CollectionBalls.add(b3);
		
		}
	
		public ArrayList<Ball> CollectionBalls = new ArrayList<Ball>();
		
	public void doDraw(Canvas canvas, Paint paint) {
		
		for (int i = 0; i < CollectionBalls.size(); i++) {
			Ball b = CollectionBalls.get(i);
			canvas.drawCircle((int) b.x, (int) b.y, 5, paint);
			b.Update(0.5);
		}
		
		}
		
	public boolean onTouch(View arg0, MotionEvent arg1){
		
		double h= width/2;
		Random r = new Random();
		if(arg1.getX() >= h)
		{
			
		 Ball b = new Ball(r.nextInt(width), r.nextInt(height),0,0,width,height);
		CollectionBalls.add(b);	

		}else{	
			
			CollectionBalls.clear();
			
		}
		return true;
	}
	
}
