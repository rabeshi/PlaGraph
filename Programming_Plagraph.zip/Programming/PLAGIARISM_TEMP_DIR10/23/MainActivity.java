package com.example.animationgame;
import java.util.ArrayList;
import java.util.Random;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener {
	Ball b1;
	Ball b2;
	Ball b3;
	DrawView drawView;
	int width,height;
	ArrayList<Ball>g=new ArrayList<Ball>();
	@SuppressWarnings("deprecation")
	@SuppressLint("ClickableViewAccessibility") @Override
	public void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	// Set full screen view
	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
	WindowManager.LayoutParams.FLAG_FULLSCREEN);
	requestWindowFeature(Window.FEATURE_NO_TITLE);
	drawView = new DrawView(this);
	setContentView(drawView);
	drawView.requestFocus();
	drawView.setOnTouchListener(this); //Add this line when doing touch events
	Display display = getWindowManager().getDefaultDisplay();
	width = display.getWidth();
	height = display.getHeight();
	Ball b1 = new Ball(100, 100, 2, 0, width, height);
	Ball b2 = new Ball(200, 200, 3, 0, width, height);
	Ball b3 = new Ball(300, 180, 1, 0, width, height);
	g.add(b1);g.add(b2);g.add(b3);
	}
	public void doDraw(Canvas canvas, Paint paint) {
		for(int i=0;i<g.size();i++){
			Ball h=g.get(i);
			paint.setColor(Color.GREEN);
	canvas.drawCircle((int) h.x, (int) h.y, 5, paint);
	g.get(i);
	h.update(0.5);
		}
	}
	@SuppressLint("ClickableViewAccessibility") @Override
	public boolean onTouch(View arg0, MotionEvent arg1) {
		if(arg1.getX()>=width/2){
			Random rand = new Random();
			Ball f=new Ball( rand.nextInt(width/2) + 1, rand.nextInt(height/2) + 1,0.0,0.0,width,height);
			g.add(f);
			return true;

//		}if(arg1.getX()<=width/2){
//			
		}else{
			g.clear();
		return false;
		}
	}
}
