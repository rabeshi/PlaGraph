package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener{
int x=30,y=20,yspeed=10,a=100,bspeed=20,b=100,i=300,p=50,pspeed=15;
public ArrayList<Ball> Ballslist =new ArrayList<Ball>();
	DrawView drawView;
	Ball b1;
	Ball b2;
	Ball b3;

	

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
		WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
		Display display = getWindowManager().getDefaultDisplay();
		int width = getApplication().getResources().getDisplayMetrics().widthPixels;
		int height = getApplication().getResources().getDisplayMetrics().heightPixels;
		b1 = new Ball(100, 100, 2, 2, width, height);
		b2 = new Ball(200, 200, 3, 3, width, height);
		b3 = new Ball(300, 180, 1, 1, width, height);
		
		Ballslist.add(b1);
		Ballslist.add(b2);
		Ballslist.add(b3);
	}
	public void doDraw(Canvas canvas, Paint paint) {
		for(int i = 0;i< Ballslist.size();i++)
		{
		       Ball b4 =Ballslist.get(i);
		       b4.update(0.5);
		       canvas.drawCircle((int) b4.x, (int) b4.y, 5, paint);
		}
	}
	public boolean onTouch(View arg0 , MotionEvent arg1){
		int width = getApplication().getResources().getDisplayMetrics().widthPixels;
		int height = getApplication().getResources().getDisplayMetrics().heightPixels;
		Random rand = new Random();
		if(arg1.getX()<=width/2)
		{
			Ball b4= new Ball(rand.nextInt(width/2),rand.nextInt(height),0,0,width,height);
			Ballslist.add(b4);
		}
		if(arg1.getX()>=width/2)
		{
			Ballslist.clear();
		}
		
		return true;
	}

}
