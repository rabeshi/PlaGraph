package com.example.animationgame;
import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener {

	int x=30,posball1=20,posball2=20,posball3=20,accelball1=10,accelball2=20,accelball3=15;
	
	DrawView drawView;

	Ball b1;
	Ball b2;
	Ball b3;
	ArrayList<Ball> saved = new ArrayList<Ball>();
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
		//onTouch(getCurrentFocus(), arg1)
		
		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		int height = displaymetrics.heightPixels;
		int width = displaymetrics.widthPixels;

		
		b1 = new Ball(100, 100, 2, 0, width, height-5,5);
		b2 = new Ball(200, 200, 3, 0, width, height-5,5);
		b3 = new Ball(300, 180, 1, 0, width, height-5,5);
		
		
		saved.add(b1);
		saved.add(b2);
		saved.add(b3);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		
		
		for(int i=0;i<saved.size();i++)
		{
		canvas.drawCircle((float) saved.get(i).x, (float) saved.get(i).y, (float)saved.get(i).size, paint);
		saved.get(i).update(0.5);
		}

	}
	
	
	public boolean onTouch(View arg0, MotionEvent arg1)
	{
		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		int height = displaymetrics.heightPixels;
		int width = displaymetrics.widthPixels;

		if(arg1.getX()<=width/2)
		{
			saved.clear();
		}
		if(arg1.getX()>width/2)
		{
			Random k= new Random();
			saved.add(new Ball((float)k.nextDouble()*width, (float)k.nextDouble()*height, 0, 0, width, height-5,5));
		}
		
		
		return true;

	}

}
