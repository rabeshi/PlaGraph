package com.example.animationgame;
import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

@SuppressLint({ "NewApi", "ClickableViewAccessibility" })
public class MainActivity extends Activity implements OnTouchListener {
	//Ball b1, b2, b3;
	
	ArrayList<Ball> balls = new ArrayList<Ball>();
	
	int width, height;
	
	DrawView drawView;

	@SuppressWarnings("deprecation")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
		
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
		
		/*b1 = new Ball(100, 100, 2, 0, width, height);
		b2 = new Ball(200, 200, 3, 0, width, height);
		b3 = new Ball(300, 180, 1, 0, width, height);*/
		
		balls.add(new Ball(100, 100, 2, 0, width, height));
		balls.add(new Ball(200, 200, 3, 0, width, height));
		balls.add(new Ball(300, 180, 1, 0, width, height));
	}

	public void doDraw(Canvas canvas, Paint paint) {
		/*canvas.drawCircle((int) b1.x, (int) b1.y, 5, paint);
		b1.update(0.5);
		canvas.drawCircle((int) b2.x, (int) b2.y, 5, paint);
		b2.update(0.5);
		canvas.drawCircle((int) b3.x, (int) b3.y, 5, paint);
		b3.update(0.5);*/
		
		int Asize = balls.size();
		
		for(int i=0; i < Asize;i++){
			canvas.drawCircle((int) balls.get(i).x, (int) balls.get(i).y, 5, paint);
			balls.get(i).update(0.5);
		}
	}


	public boolean onTouch(View arg0, MotionEvent arg1) {
		int touch = (int) arg1.getX();
		
		if(touch >= width/2){
			int x = (int) (Math.random() * (width));
			int y = (int) (Math.random() * (height));
			balls.add(new Ball(x, y, 0 , 0, width, height));
			
		} else if(touch < width/2){
				balls.clear();
		}
		return true;
	}
}
