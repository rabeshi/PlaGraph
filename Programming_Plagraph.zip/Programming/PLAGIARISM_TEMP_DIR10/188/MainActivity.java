package com.example.bouncing_balls;

import java.util.ArrayList;
import java.util.Random;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

	public class MainActivity extends Activity implements OnTouchListener{
	int x=30,y=20, height = 0, width = 0;
	ArrayList<Ball> balls = new ArrayList<Ball>();
	DrawView drawView;
	Ball b1;
	Ball b2;
	Ball b3;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
		 DisplayMetrics metrics = new DisplayMetrics();
		 getWindowManager().getDefaultDisplay().getMetrics(metrics);
		 height = metrics.heightPixels;
		 width = metrics.widthPixels;
		 balls.add(new Ball(100, 100, 2, 0, width, height));
		 balls.add(new Ball(200, 200, 3, 0, width, height));
		 balls.add(new Ball(300, 180, 1, 0, width, height));
	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		for(int i = 0; i < balls.size(); i++){
			balls.get(i).Update(0.5);
			canvas.drawCircle((int) balls.get(i).x, (int) balls.get(i).y, 5, paint);
		}
	}


	@Override
	public boolean onTouch(View arg0, MotionEvent arg1) {
		// TODO Auto-generated method stub
		boolean onRight = false, onLeft = false;
		int halfWidth = width/2;
		if(arg1.getX() < halfWidth){
			onLeft = true;
		}else{
			onRight = true;
		}
		if(onLeft == true){
			balls.clear();
		}
		if(onRight == true){
			Random random = new Random();
			balls.add(new Ball(random.nextInt()%width, random.nextInt()%height, 0, 0, width, height));
		}
		return true;
	}

}
