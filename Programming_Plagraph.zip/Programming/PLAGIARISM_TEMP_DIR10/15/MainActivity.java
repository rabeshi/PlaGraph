package com.example.animationgame;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements OnTouchListener{
Random ran = new Random();

	double speed1 = 0.5, speed2=0.5, speed3=0.5;
	ArrayList<Ball> balls = new ArrayList<Ball>();
	
	DrawView drawView;
	Ball b1;
	Ball b2;
	Ball b3;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		drawView.setOnTouchListener(this);
		Display display = getWindowManager().getDefaultDisplay();
		int width = display.getWidth();
		int height = display.getHeight();
		b1 = new Ball(100, 100, 2, 2, width, height,30);
		b2 = new Ball(200, 200, 2, 2, width, height,30);
		b3 = new Ball(300, 180, 2, 2, width, height,30);
		balls.add(b1);
		balls.add(b2);
		balls.add(b3);
		
		
		

		}
	
	
	DisplayMetrics metrics = new DisplayMetrics();
	//this.getWindowManager().getDefaultDisplay().getMetrics(metrics);
	int Width = metrics.widthPixels;
	int Height = metrics.heightPixels;
	
	
	public boolean onTouch(View arg0, MotionEvent arg1) {
		int touch=arg1.getAction();

		Display display = getWindowManager().getDefaultDisplay();
		int width = display.getWidth();
		int height = display.getHeight();

		int x = ran.nextInt(width-0)+0;
		int y = ran.nextInt(height-0)+0;
		if(touch == MotionEvent.ACTION_DOWN){
			int a =(int) arg1.getX();
		
		if(a>=width/2){
			Ball dope = new Ball(x,y,2,1,width,height,30);
			balls.add(dope);
		}
		else
		{
			balls.clear();
		}
		}
		return false;
	}

	public void doDraw(Canvas canvas, Paint paint) {
		for(int i=0; i<balls.size();i++){
			Ball d = balls.get(i); 
			canvas.drawCircle((int) d.x, (int) d.y, 30, paint);
			d.update(speed1);
		}
		
			
	}

}

