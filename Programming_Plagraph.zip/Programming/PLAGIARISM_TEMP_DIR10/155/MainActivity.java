package com.example.animationggame;





import java.util.ArrayList;
import java.util.Random;

import android.R;
import android.support.v7.app.ActionBarActivity;
import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;


public class MainActivity extends Activity implements OnTouchListener {
	 	DrawView drawView; 
	Ball b1, b2, b3;
	int width, height;
   ArrayList<Ball> balls = new ArrayList<Ball> ();
   Random generator = new Random();

	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
      //  setContentView(R.layout.activity_main);
     // Set full screen view
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
        WindowManager.LayoutParams.FLAG_FULLSCREEN);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        drawView = new DrawView(this);
        setContentView(drawView);
        drawView.requestFocus();
        drawView.setOnTouchListener(this); //Add this line when doing touch events
        Display display = getWindowManager().getDefaultDisplay();
        width = display.getWidth();
        height = display.getHeight();
        b1 = new Ball(100, 100, 2, 0, width, height);
        b2 = new Ball(200, 200, 3, 0, width, height);
        b3 = new Ball(300, 180, 1, 0, width, height);
        balls.add(b1);
        balls.add(b2);
        balls.add(b3);
    }


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		
		for(int i=0; i<balls.size(); i++){
			
			canvas.drawCircle( (float) balls.get(i).getX(),(float) balls.get(i).getY(), 5, paint);
			balls.get(i).update(0.5);
			
		}
		
	}
	
	@Override
	public boolean onTouch(View arg0, MotionEvent arg1){
		Display display = getWindowManager().getDefaultDisplay();
		 height = display.getHeight();
		 width = display.getWidth();
	
			int l = generator.nextInt(width);
			int k = generator.nextInt(height);
		 if(arg1.getAction()==MotionEvent.ACTION_DOWN){
			 int xCoord = (int) arg1.getX();
		
			if(xCoord>(width/2)){
				balls.add(new Ball(l, k, 0, 0, width, height));
			}else{
				balls.clear();
			}
		 }
		 
		
		return false;
	}
	}
	

