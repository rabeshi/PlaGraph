package com.example.statsapp;

import java.util.ArrayList;

public class Calculator {
	 public static double getMean(ArrayList<Double> stuff)
	 {
		 int n = stuff.size();
		 double sum = 0;
		 for(int i=0; i<n;i++)
			 sum += stuff.get(i);
		 
		return sum/n;
		 
	 }
	 public static double getVariance(ArrayList<Double> stuff)
	 {
		double mean = getMean(stuff);
		int n = stuff.size();
		double var = 0;
		for(int i =0; i <n; i++)
			var += Math.pow((stuff.get(i)-mean),2);
		return var/n;
		 
	 }
	
	public static double getStdDev(ArrayList<Double> stuff)
	 {
		double Std = getVariance(stuff);
		
		return Math.sqrt(Std);
		 
	 }
}
