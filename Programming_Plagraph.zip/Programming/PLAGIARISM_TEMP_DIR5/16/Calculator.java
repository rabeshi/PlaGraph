package com.example.statsapp;

import java.util.ArrayList;
import java.util.Iterator;

public class Calculator {	

	public static double getMean(ArrayList<Double> ary){
		double sumMn = 0.0;		
		Iterator<Double> it = ary.iterator();
				
		while(it.hasNext()){
			sumMn = sumMn + it.next();
		}		
		return sumMn/ary.size();
	}
	
	public static double getVariance(ArrayList<Double> ary){
		double mean = getMean(ary);
		double sumVr = 0.0;			
		Iterator<Double> it = ary.iterator();
				
		while(it.hasNext()){
			sumVr = sumVr + Math.pow((it.next() - mean),2);
		}		
		return sumVr/ary.size();
	}
	
	public static double getStdDev(ArrayList<Double> ary){		
		double variance = getVariance(ary);			 
		return Math.sqrt(variance);
	}

}

