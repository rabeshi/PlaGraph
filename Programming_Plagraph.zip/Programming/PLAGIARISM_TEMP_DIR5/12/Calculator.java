package com.example.statsapp;

import java.util.ArrayList;

public class Calculator {
	public static Double getMean(ArrayList<Double> arr) {
		Double sum = new Double(0);
		for(Double d: arr) sum+=d;
		return (sum/arr.size());
	}
	public static Double getVariance(ArrayList<Double> arr) {
		Double sum = new Double(0);
		Double mean = getMean(arr);
		for(Double d: arr) sum+=(mean-d)*(mean-d);
		return (sum/arr.size());
	}
	public static Double getStdDev(ArrayList<Double> arr) {
		Double var = getVariance(arr);
		return (Math.sqrt(var));
	}
}
