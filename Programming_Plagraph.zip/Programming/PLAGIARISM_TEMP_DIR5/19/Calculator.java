package com.example.statsapp;

import java.util.ArrayList;

public class Calculator {
	public static double getMean(ArrayList<Double> arr){
		double sum=0,arrMean;
		
		for(int x=0;x<arr.size();x++){
			sum = sum+arr.get(x);
		}
		arrMean = sum/arr.size();
		return arrMean;
	}
	public static double getVariance(ArrayList<Double> arr){
		double sum=0,Mean = getMean(arr),arrVariance,dev,devsq;
		
		for(int x=0;x<arr.size();x++){
			dev = arr.get(x)-Mean;
			devsq = Math.pow(dev,2);
			sum = sum+devsq;
		}
		arrVariance = sum/arr.size();
		return arrVariance;
	}
	public static double getStdDev(ArrayList<Double> arr){
		double Variance=getVariance(arr),arrStdDev;
		
		arrStdDev = Math.sqrt(Variance);
		return arrStdDev;
	}

}
