package com.example.statsapp;

import java.util.ArrayList;

public class Calculator {
	//Calculates the mean
	public static double getMean(ArrayList<Double> list){
		double sum=0;
		for(int i=0;i<list.size();i++){
			sum+=list.get(i);
		}
	return sum/((double)list.size());	
	}
	//Calculates the variance
	public static double getVariance(ArrayList<Double> list){
		double sum=0,mean = getMean(list);
		for(int i=0;i<list.size();i++){
			sum+=Math.pow((list.get(i)-mean), 2);
		}
		return sum/((double)list.size());
	}
	//Calculates the standard deviation
	public static double getStdDev(ArrayList<Double> list){
		return Math.sqrt(getVariance(list));
	}
} 
