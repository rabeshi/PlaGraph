package com.example.statsapp;

import java.util.ArrayList;

public class Calculator {
	public static double getMean(ArrayList<Double> arr){
		double sum = 0;
		for(int i = 0;i<arr.size();i++){
			sum = sum + arr.get(i);
		}
		return sum/arr.size();
	}
	
	public static double getVariance(ArrayList<Double> arr){
		double mean = getMean(arr);
		double sum = 0;
		double n = 0;
		
		for(int i=0;i<arr.size();i++){
			n = arr.get(i)-mean;
			n = Math.pow(n,2);
			sum = sum + n;
		}
		return sum/arr.size();
	}
	
	public static double getStdDev(ArrayList<Double> arr){
		double var = getVariance(arr);
		return Math.pow(var, 0.5);
	}

}
