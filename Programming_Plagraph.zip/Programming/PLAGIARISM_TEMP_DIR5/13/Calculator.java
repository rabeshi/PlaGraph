package com.example.statsapp;

import java.util.ArrayList;

public class Calculator {
	public static double getMean(ArrayList<Double> v){
		double mean=0, sum=0;
		int size = v.size();
		
		for(int i=0;i<size;i++){
			sum = sum + v.get(i);
		}
		
		mean = sum/size;
		
		return mean;
	}
	
	public static double getVariance(ArrayList<Double> v){
		double variance, mean=0, sum = 0;
		double preSum;
		int size = v.size();
		mean = getMean(v);
		
		for(int i=0; i<size;i++){
			preSum = v.get(i) - mean;
			
			sum = sum + Math.pow(preSum, 2);
		}
		
		variance = sum/size;
		
		return variance;
	}
	
	public static double getStdDev(ArrayList<Double> v){
		double stdDev, variance;
		variance = getVariance(v);
		stdDev = Math.sqrt(variance);
		
		return stdDev;
	}
}
