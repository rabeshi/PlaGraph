package com.animetiongame;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20;
	int a=100;
	int b=100;
	int z=300,v=50;
	int s=10,h=20,g=15;
	DrawView drawView;
	Bitmap myImage;
	Bitmap mypic;
	Bitmap pic;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.balll);
		mypic=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		pic=BitmapFactory.decodeResource(getResources(), R.drawable.max);
	
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
	}


	public void doDraw(Canvas canvas, Paint paint) {
		int height = this.getResources().getDisplayMetrics().heightPixels;
		
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(mypic, a, b, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(pic, z, v, paint);
		if(y<=0){
			h=10;
		}
		if(y>=height){
			h=-10;
			
		}
		y=y+h;
		if(b<=0){
			s=20;
		}
		if(b>=height){
			s=-20;
		}
		b=b+s;
		if(v<=0){
			g=15;
		}
		if(v>=height){
			g=-12;
		}
		v=v+g;
	}



}
