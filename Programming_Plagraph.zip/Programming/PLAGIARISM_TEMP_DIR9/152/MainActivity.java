package com.example.animationgame;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,c=20,greenbally=100,greenballx=100,yellowbally=50,yellowballx=300;
	int screenheight ;
	int number1 =10,number2=20,number3=15;
	Bitmap myImage,myImage2,myImage3;
	 
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
		myImage3=BitmapFactory.decodeResource(getResources(), R.drawable.ball3);
	}


	@SuppressLint("NewApi") public void doDraw(Canvas canvas, Paint paint) {
		Display display = getWindowManager().getDefaultDisplay();
		Point size = new Point();
		display.getSize(size);
	screenheight = size.y;
		
		
		canvas.drawBitmap(myImage, x, c,paint);
		
	    canvas.drawBitmap(myImage2, greenballx, greenbally, paint);
		
		canvas.drawBitmap(myImage3,yellowballx, yellowbally, paint);
	  
		c=c+number1;
		greenbally=greenbally+number2;
		yellowbally=yellowbally+number3;
if ((c>screenheight)||(c< 0))
{
	number1=-number1;	
}
else if( (greenbally>screenheight)||(greenbally<0))
	{
		number2=-number2;
		
	}


else if ((yellowbally>screenheight)||(yellowbally<0))
	{
		number3=-number3;
	}
}		
	

	}



	
		
	


