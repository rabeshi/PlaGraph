package com.example.animagame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

public class MainActivity extends Activity {
	int x = 200, y = 20, i = 20, j = 20, l;
	int ySpeed = 10;
	int iSpeed = 15;
	int jSpeed = 20;
	Bitmap myImage;
	boolean check = false;
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		myImage = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
	}

	public void doDraw(Canvas canvas, Paint paint) {
		// int w=y,u=y,t=y;
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage, 400, i, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage, 600, j, paint);
		y += ySpeed;
		i += iSpeed;
		j += jSpeed;

		if (y > canvas.getHeight()) {
			ySpeed = ySpeed*-1;
		}
		if (y < 0) {
			ySpeed = ySpeed*-1;
		}
		
		if (i > canvas.getHeight()) {
			iSpeed = iSpeed*-1;
		}
		if (i < 0) {
			iSpeed = iSpeed*-1;
		}
		
		if (j > canvas.getHeight()) {
			jSpeed = jSpeed*-1;
		}
		if (j < 0) {
			jSpeed = jSpeed*-1;
		}


		// else if(j<=0){
		// j=canvas.getHeight();
		// }
	}

}
