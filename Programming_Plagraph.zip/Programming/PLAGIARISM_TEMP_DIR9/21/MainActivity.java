package com.example.drawing;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity 
{
	int x=30,y=20,x1=100,y1=0,x2=200,y2=0;
	Bitmap myImage,myImage1,myImage2;
	boolean upDown=true,upDown1=true,upDown2=true;
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ninja1);
		myImage1=BitmapFactory.decodeResource(getResources(), R.drawable.ninja2);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.ninja3);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage,x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage1,x1, y1, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage2,x2, y2, paint);
		if(upDown)
			y=y+10;
		else
			y=y-10;
		if(upDown1)
			y1=y1+20;
		else
			y1=y1-20;
		if(upDown2)
			y2=y2+15;
		else
			y2=y2-15;
		
		
		DisplayMetrics dm=new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int height=dm.heightPixels;
		if(y>height)
			upDown=false;
		else if(y<0)
			upDown=true;
		if(y1>height)
			upDown1=false;
		else if(y1<0)
			upDown1=true;
			
		if(y2>height)
			upDown2=false;
		else if(y2<0)
			upDown2=true;
	}

}
