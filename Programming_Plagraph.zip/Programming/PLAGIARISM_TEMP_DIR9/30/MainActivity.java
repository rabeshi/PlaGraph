package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20, x2 = 100, y2 = 100, x3 = 300, y3 = 50;
	Bitmap myImage;
	Bitmap myImage2;
	Bitmap myImage3;
	DrawView drawView;
	Boolean falling1 = true;
	Boolean falling2 = true;
	Boolean falling3 = true;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball1);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
		myImage3=BitmapFactory.decodeResource(getResources(), R.drawable.ball3);

	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage2, x2, y2, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage3, x3, y3, paint);
		Display display = getWindowManager().getDefaultDisplay(); 
		int screenHeight = display.getHeight();
		
		if(falling1){
			y = y + 10;

		} else{
			y = y-10;
		}
		if(y > screenHeight- myImage.getHeight() || y < 0){
				falling1 = !falling1;				
		}
		
		
		if(falling2){
			y2 = y2 + 20;

		} else{
			y2 = y2-20;
		}
		if(y2 > screenHeight - myImage2.getHeight()  || y2 < 0){
				falling2 = !falling2;				
		}
		
		
		if(falling3){
			y3 = y3 + 15;

		} else{
			y3 = y3-15;
		}
		if(y3 > screenHeight - myImage3.getHeight() || y3 < 0){
				falling3 = !falling3;				
		}
	}

}
