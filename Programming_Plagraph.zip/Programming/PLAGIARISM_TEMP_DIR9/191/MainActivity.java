package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20, height = 0, gy = 100, yy = 50, yspeed = 10, gyspeed = 20, yyspeed = 15;
	Bitmap myImage, myImage2, myImage3;;
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		 DisplayMetrics metrics = new DisplayMetrics();
		 getWindowManager().getDefaultDisplay().getMetrics(metrics);
		 height = metrics.heightPixels;
		 myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		 myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.soccer_ball);
		 myImage3=BitmapFactory.decodeResource(getResources(), R.drawable.other_ball);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage2, 100, gy, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage3, 300, yy, paint);
		y = y + yspeed;
		if(y >= (height - myImage.getHeight()) || y <= 0){
			yspeed = yspeed*(-1);
		}
		gy = gy + gyspeed;
		if(gy >= (height - myImage2.getHeight()) || gy <= 0){
			gyspeed = gyspeed*(-1);
		}
		yy = yy + yyspeed;
		if(yy >= (height - myImage3.getHeight()) || yy <= 0){
			yyspeed = yyspeed*(-1);
		}
	}

}
