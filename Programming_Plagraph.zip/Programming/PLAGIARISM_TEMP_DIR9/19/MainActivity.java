package com.example.animationgame;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20,a=100,b=100,c=300,d=50;
	Bitmap mylmage,mylmage2,mylmage3;
	boolean letter = false;
	boolean reader = false;
	boolean marker = false;
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		mylmage = BitmapFactory.decodeResource(getResources(),R.drawable.ball);
		mylmage2 = BitmapFactory.decodeResource(getResources(),R.drawable.ball2);
		mylmage3 = BitmapFactory.decodeResource(getResources(),R.drawable.ball3);
	}


	@SuppressLint("NewApi") public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(mylmage,x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(mylmage2,a, b, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(mylmage3,c,d, paint);
		
		Display dispaly = getWindowManager().getDefaultDisplay();
		Point size = new Point();
		dispaly.getSize(size);
		int height = size.y;
		
		if (y < height && letter == false){
			y = y + 10;
		}
		else {
			letter = true;
		}
		if(letter == true){
			y = y - 10;
			if(y < 0){
				letter = false;
			}
		}
		if(b < height && reader == false){
			b = b + 20;
		}
		else{
			reader = true;
		}
		if(reader == true){
			b = b - 20;
			if(b < 0){
				reader = false;
			}
		}
		if(d < height && marker == false){
			d = d + 15;
		}
		else{
			marker = true;
		}
		if(marker == true){
			d = d - 15;
			if(d < 0){
				marker = false;
			}
		}
	}

}
