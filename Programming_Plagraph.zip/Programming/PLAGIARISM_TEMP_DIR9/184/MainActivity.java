package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20;
	int y1 = 100,y2=50;
	Bitmap myImage,myImage1, myImage2;
	
	DrawView drawView;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		
		myImage=BitmapFactory.decodeResource(getResources(), (Integer) R.drawable.ball);
		myImage1=BitmapFactory.decodeResource(getResources(), (Integer) R.drawable.ball1);
		myImage2=BitmapFactory.decodeResource(getResources(), (Integer) R.drawable.ball2);
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		//canvas.drawCircle(x, y, 5, paint);
		canvas.drawBitmap(myImage, x, y, paint);
		paint.setColor(Color.GREEN);
		//canvas.drawCircle(100, y1, 30, paint);
		canvas.drawBitmap(myImage1, 100, y1, paint);
		paint.setColor(Color.YELLOW);
		//canvas.drawCircle(300, y2, 10, paint);
		canvas.drawBitmap(myImage2, 300, y2, paint);
		Display display = getWindowManager().getDefaultDisplay();
		int screenHeight = display.getHeight();
		y = y - 10;
		if((y > screenHeight)||(y<0)){
			y= -50*y;
		}
		y1= y1 - 20;
		if((y1> screenHeight)||(y1<0)){
			y1=-30*y1;
		}
		y2= y2 - 15;
		if((y2> screenHeight)||(y2<0)){
			y2=-50*y2;
		}
	}

}
