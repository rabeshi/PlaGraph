package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20, a= 100, b=100, c =300, d =50;
	int i=1,j=1,k=1;
	Bitmap myImage;
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		int height = canvas.getHeight();
		int h=myImage.getHeight();
		//The black ball, or this was the black ball
		paint.setColor(Color.BLACK);
		//canvas.drawCircle(x, y, 5, paint);
		canvas.drawBitmap(myImage, x, y, paint);
		
		if (y+h >= height)
		{
			i = -1;
			//y = 0;
		}
		if (y <= 0)
		{
			i = 1;
		}
		y = y + 10*i;
		

		
		
		//It was the Green ball
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage, a, b, paint);
		//canvas.drawCircle(a, b, 30, paint);
		
		if (b+h >= height)
		{
			j = -1;
		}
		if (b <= 0){
			j = 1;
		}
		b = b + 20*j;		
		
		//this was the Yellow ball
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage, c, d, paint);
		//canvas.drawCircle(c, d, 10, paint);
		
		if (d+h >= height)
		{
			k = -1;
			//d = 0;
		}
		if (d <= 0)
		{
			k = 1;
		}
		d = d+15*k;
		
		
	}

}
