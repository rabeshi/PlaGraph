package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x1=30,y1=20,x2=200,y2=100,x3=400,y3=50;
	
	DrawView drawView;
	Point size = new Point();	
	Bitmap myImage1,myImage2,myImage3;
	boolean falling1,falling2,falling3;


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		
		Display display = getWindowManager().getDefaultDisplay();		
		display.getSize(size);
		myImage1=BitmapFactory.decodeResource(getResources(), R.drawable.pogo);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.falling1);
		myImage3=BitmapFactory.decodeResource(getResources(), R.drawable.flyingsquirrel);
		
		falling1 = falling2 = falling3 = true;
		
	}


	public void doDraw(Canvas canvas, Paint paint) {
		canvas.drawBitmap(myImage1, x1, y1, paint);
		canvas.drawBitmap(myImage2, x2, y2, paint);
		canvas.drawBitmap(myImage3, x3, y3, paint);
		
		int height = size.y;
		
		if (falling1 == true)
		{
			y1 = y1+10;
			if (y1+myImage1.getHeight() > height)
			{
				falling1 = false;
			}
		}
		else if (falling1 == false)
		{
			y1 = y1-10;
			if (y1 < 0)
			{
				falling1 = true;
			}
		}
		
		if (falling2 == true)
		{
			y2 = y2+20;
			if (y2+myImage2.getHeight() > height)
			{
				falling2 = false;
			}
		}
		else if (falling2 == false)
		{
			y2 = y2-20;
			if (y2 < 0)
			{
				falling2 = true;
			}
		}
		
		if (falling3 == true)
		{
			y3 = y3+15;
			if (y3+myImage3.getHeight() > height)
			{
				falling3 = false;
			}
		}
		else if (falling3 == false)
		{
			y3 = y3-15;
			if (y3 < 0)
			{
				falling3 = true;
			}
		}
	}

}
