package com.example.animationgame;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity
{
	int x=30,y=20, x1=100,y1=100, x2=300,y2=50;
	
	int Height;
    int yspeed = 15;
	int y1speed = 20;
	int y2speed = 15;
	
	Bitmap myImage;
	Bitmap myImage1;
	Bitmap myImage2;
	
	
	DrawView drawView;

	@SuppressLint("NewApi") @Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
		WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		
        Display display = getWindowManager().getDefaultDisplay();
		Point size = new Point();
		display.getSize(size);
		int Width = size.x;
		 Height = size.y;
		drawView = new DrawView(this);
		setContentView(drawView);
	    drawView.requestFocus();

		myImage = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage1 = BitmapFactory.decodeResource(getResources(), R.drawable.balls);
		myImage2 = BitmapFactory.decodeResource(getResources(), R.drawable.balll);
		
	}


	public void doDraw(Canvas canvas, Paint paint)
	{
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage1, x1, y1, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage2, x2, y2, paint);
		y = y + yspeed;
		if((y>Height) || (y<0))   
		{ 
			yspeed = -1 *yspeed;
			}   
				
	    y1 = y1 + y1speed;
	    
	    if((y1>Height) || (y1<0))
		{ 
	    	y1speed = -1 *y1speed;
	    	} 
				
		y2 = y2 + y2speed;
		
        if((y2>Height) || (y2<0))
		{ 
        	y2speed = -1 *y2speed;
        	} 
	}

}
