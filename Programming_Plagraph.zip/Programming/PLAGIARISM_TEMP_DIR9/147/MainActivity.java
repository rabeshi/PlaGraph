package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20,y_g = 100,y_y = 50;
	Bitmap myImage;
	Bitmap myImage2;
	Bitmap myImage3;
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
		myImage3=BitmapFactory.decodeResource(getResources(), R.drawable.ball3);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage2,100, y_g, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage3,300, y_y, paint);



		
		
		DisplayMetrics metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		int x = metrics.heightPixels;
		
		boolean x1;
		if (y <= x){
			 x1 = true;
		}
		else {
			 x1 = false;
		}
			if (x1 == true){
				y = y + 10;
			}
			else {
				y = x - 10;
		}
		
		
		if (y_g < x){
			y_g = y_g + 20;
		}
		else if (y_g == x){
			y_g = y_g + 10;
		}
		if (y_y < x){
			y_y = y_y + 15;
		}
		else if (y_y == x){
			y_y = y_y + 10;
		}
	}

}
