package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=0,y=0,i=0,j=0,k,l,m;
	Bitmap myImage;
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		//canvas.drawCircle(x, y, 5, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage, 100, i, paint);
		//canvas.drawCircle(100, i, 30, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage, 300, j, paint);
		//canvas.drawCircle(300, j, 10, paint);
		//y = y+10;
		//i = i+20;
		//j = j+15;
		
		int v=canvas.getHeight();
		if(y<=0)
			k=1;
		if(y>=v)
			k=-1;
		y=y+10*k;
		
		if(i<=0)
			l=1;
		if(i>=v)
			l=-1;
		i=i+20*l;
		
		if(j<=0)
			m=1;
		if(j>=v)
			m=-1;
		j=j+15*m;
	}

}
