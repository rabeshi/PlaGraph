package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	float x = 30, y = 20, gy = 100, py = 50;

	DrawView drawView;
	Bitmap myImage;
	Bitmap myGreenImage;
	Bitmap myPinkImage;
	boolean flagR = false;
	boolean flagG = false;
	boolean flagP = false;
	float velR = 10;
	float velG = 20;
	float velP = 15;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myGreenImage = BitmapFactory.decodeResource(getResources(),
				R.drawable.ballgreen);
		myPinkImage = BitmapFactory.decodeResource(getResources(),
				R.drawable.ballpink);
	}

	public void doDraw(Canvas canvas, Paint paint) {
		Display display = getWindowManager().getDefaultDisplay();
		Point size = new Point();
		DisplayMetrics metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		
		// paint.setColor(Color.BLACK);
		
		// canvas.drawCircle(x, y, 5, paint);
		canvas.drawBitmap(myImage, x, y, paint);
		// paint.setColor(Color.GREEN);
		// canvas.drawCircle(100, gy, 30, paint);
		canvas.drawBitmap(myGreenImage, 200, gy, paint);
		// paint.setColor(Color.YELLOW);
		// canvas.drawCircle(300, yy, 10, paint);
		canvas.drawBitmap(myPinkImage, 500, py, paint);
		// -----------moving down
		if (flagR == false && !((Math.abs(velR) <0.6)&&(y >=metrics.heightPixels - 47 ))) {
			y = y + velR;
			velR = velR + 0.1f;

		}
		if (flagG == false && !((Math.abs(velG) <0.6)&&(gy >=metrics.heightPixels-202))) {
			gy = gy + velG;
			velG = velG + 0.1f;

		}
		if (flagP == false && !((Math.abs(velP) <0.6)&&(py >=metrics.heightPixels-295  ))) {
			py = py + velP;
			velP = velP + 0.1f;

			// ------------------------moving up
		}
		if (flagR == true && !((Math.abs(velR) <0.6)&&(y >=metrics.heightPixels - 47 ))) {
			y = y - velR;
			velR = velR - 0.5f;
		}
		if (flagG == true && !((Math.abs(velG) <0.6)&&(gy >=metrics.heightPixels -202))) {
			gy = gy - velG;
			velG = velG - 0.5f;
		}
		if (flagP == true && !((Math.abs(velP) <0.6)&&(py >=metrics.heightPixels -295 ))) {
			py = py - velP;
			velP = velP - 0.5f;
		}

		
		// ------at the bottom of the screen
		if (y >= metrics.heightPixels - 43) {
			flagR = true;
		}
		if (gy >= metrics.heightPixels - 200) {
			flagG = true;
		}
		if (py >= metrics.heightPixels - 288) {
			flagP = true;
		}
		// -------top of screen
		if (y <= 0) {
			flagR = false;
		}
		if (gy <= 0) {
			flagG = false;
		}
		if (py <= 0) {
			flagP = false;
		}

		if ((velR <= 0) && (flagR ==true)) {
			flagR = false;
		}
		if ((velG <= 0) && (flagG ==true)) {
			flagG = false;
		}
		if ((velP <= 0) && (flagP ==true)) {
			flagP = false;
		}
	}
}
