package com.example.animationgame;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20;
	int ax = 20, by = 15;
	int speed = 1;

	Bitmap myImage, myImage2, myImage3;

	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();

		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.red_ball);
		myImage3=BitmapFactory.decodeResource(getResources(), R.drawable.black_ball);
	}


	public void doDraw(Canvas canvas, Paint paint) {

		canvas.drawBitmap(myImage, x, y, paint);
		canvas.drawBitmap(myImage2, x+100, y, paint);
		canvas.drawBitmap(myImage3, x+200, y, paint);
		/*paint.setColor(Color.BLACK);
		canvas.drawCircle(x, y, 5, paint);
		paint.setColor(Color.GREEN);
		canvas.drawCircle(100, 100+ax, 30, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawCircle(300, 50+by, 10, paint);*/

		Display display = getWindowManager().getDefaultDisplay(); 
		//int width = display.getWidth();  // deprecated
		int height = display.getHeight(); 

		y = y + speed*10;
		ax = ax + 20;
		by = by + 15;

		if(y >= height) {
			speed = -1;
			//y = 0;
			ax = 0;
			by = 0;

		}
	}
}
