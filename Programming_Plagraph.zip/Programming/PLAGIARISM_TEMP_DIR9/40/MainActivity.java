package com.example.lab5;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20;
	
	DrawView drawView;
	
	Bitmap myImage ;
	Bitmap dB;
	Bitmap sup;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		

		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.panda1);
		dB=BitmapFactory.decodeResource(getResources(), R.drawable.panda2);
		sup = BitmapFactory.decodeResource(getResources(), R.drawable.panda3);
	}

	int j = 10;
	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(dB, y, x, paint);
		
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(sup, x, y, paint);
		
		y = y + j;
		
		
		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		int height = displaymetrics.heightPixels;
		int width = displaymetrics.widthPixels;
		
		if(y >=height)
		{
			j=-j;
		}
		if(y ==0)
		{
			//System.out.println("hello");
			j=-j;
		}
				
		
	}

}
