package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20;
	int gx = 100;
	int gy = 100;
	int yx = 300;
	int yy = 50;
	Bitmap myImage;
	Bitmap myImage2;
	Bitmap myImage3;
	boolean bBot1 = false;
	boolean bBot2 =false;
	boolean bBot3 = false;
	
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage =BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage2 = BitmapFactory.decodeResource(getResources(), R.drawable.dbzball);
		myImage3 = BitmapFactory.decodeResource(getResources(), R.drawable.pokeball);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		//canvas.drawCircle(x, y, 5, paint);
		canvas.drawBitmap(myImage,x,y,paint);
		
		
		paint.setColor(Color.GREEN);
		//canvas.drawCircle(gx, gy, 30, paint);
		canvas.drawBitmap(myImage2, gx, gy,paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage3, yx, yy,paint);
		//canvas.drawCircle(yx, yy, 10, paint);
		
		//code for getting the width and height of the screen
		Display display = getWindowManager().getDefaultDisplay();
		DisplayMetrics metrics = new DisplayMetrics();
		display.getMetrics(metrics);
		//int screenWidth = metrics.widthPixels;
		int screenHeight = metrics.heightPixels;
		
		if  (y > screenHeight || y<0)
		{
			bBot1= !bBot1;
		}
	
		
		if (bBot1 == false  ) //means is going down
		{
			y = y +10;
			
			
		}
		else 
		{
			y=y-10;
		}
		
		
		///////
		if  (gy > screenHeight || gy<0)
		{
			bBot2= !bBot2;
		}
	
		
		if (bBot2 == false  )
		{
			gy = gy +10;
			
			
		}
		else 
		{
			gy=gy-10;
		}
		///////
		
		//////
		if  (yy > screenHeight || yy<0)
		{
			bBot3= !bBot3;
		}
	
		
		if (bBot3 == false  )
		{
			yy = yy +15;
			
			
		}
		else 
		{
			yy=yy-15;
		}
		//////
		
	
		
		
		
		
		
		
	}

}
