package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20,w=20,v=20; boolean bool,boolg,booly; Bitmap myImage,myImage1,myImage2;
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage1=BitmapFactory.decodeResource(getResources(), R.drawable.blue);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.bluecircle);
		setContentView(drawView);
		drawView.requestFocus();
	}
	

	public void doDraw(Canvas canvas, Paint paint) {
		canvas.drawBitmap(myImage, x, y, paint);
		canvas.drawBitmap(myImage1, 2, v, paint);
		canvas.drawBitmap(myImage2,1,w, paint);
		if(y<20){
			bool=false;
		}else if(y>canvas.getHeight()){
			bool=true;
		}
		if(bool==false){
			y+=10;
		}else if(bool==true){
			y-=10;
		}
		if(w<20){
			boolg=false;
		}else if(w>canvas.getHeight()){
			boolg=true;
		}
		if(boolg==false){
			w+=15;
		}else if(boolg==true){
			w-=15;
		}
		if(v<20){
			booly=false;
		}else if(v>canvas.getHeight()){
			booly=true;
		}
		if(booly==false){
			v+=20;
		}else if(booly==true){
			v-=20;
		}
	}

}
