package com.example.animationgame;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20,i=1,j=1,k=1;int yg = 20;int yy = 10;
	
	DrawView drawView;
	Bitmap myImage, myImage2, myImage3;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage2 = BitmapFactory.decodeResource(getResources(), R.drawable.soccer_ball);
		myImage2 = Bitmap.createScaledBitmap(myImage2, 40, 40, true);
		myImage3 = BitmapFactory.decodeResource(getResources(), R.drawable.tennis_ball);
		myImage3 = Bitmap.createScaledBitmap(myImage3, 40, 40, true);
	}


	@SuppressLint("NewApi")
	public void doDraw(Canvas canvas, Paint paint) {
		
		Display display = getWindowManager().getDefaultDisplay();
		Point size = new Point();
		display.getSize(size);
		int height = size.y;
		
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		/*paint.setColor(Color.GREEN);
		canvas.drawCircle(200, yg, 30, paint);
		paint.setColor(Color.BLACK);
		canvas.drawCircle(400, yy, 10, paint);*/
		
		canvas.drawBitmap(myImage2, 200, yg, paint);
		canvas.drawBitmap(myImage3, 400, yy, paint);
		
		
		if(y<=0){
			i = 1;
		} if(y + myImage.getHeight()>=height){
			i = -1;
		}
		y = y + 10*i;
		
		if(yg <= 0){
			j = 1;
		} if(yg + myImage2.getHeight() >= height){
			j= -1;
		}
		yg = yg + 20*j;
		
		if(yy <= 0){
			k = 1;
		} if(yy + myImage3.getHeight() >= height) {
			k = -1;
		}
		yy = yy + 15*k;

	}
	
}
