package com.example.animationgame;


import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20,m=100,n=50;

	DrawView drawView;
	int height = 0;
	boolean attop=true,attop1=true,attop2=true;
	Bitmap myImage,myImage1,myImage2;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();

		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		height = displaymetrics.heightPixels;

		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage1=BitmapFactory.decodeResource(getResources(), R.drawable.ball1);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage1, 100, m , paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage2, 300, n, paint);

		if(attop){
			y+=10;

			if((y/(height-myImage.getHeight()))>=1){
				attop=false;
			}
		}else{
			y-=10;

			if(y<=0){
				attop=true;
			}
		}



		if(attop1){
			m+=20;

			if((m/(height-myImage.getHeight()))>=1){
				attop1=false;
			}
		}else{
			m-=20;

			if(m<=0){
				attop1=true;
			}
		}

		if(attop2){
			n+=15;

			if(n/(height-myImage.getHeight())>=1){
				attop2=false;
			}
		}else{
			n-=15;

			if(n<=0){
				attop2=true;
			}
		}
		
	}

}