package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	Bitmap myImage ;
	Bitmap myImag ;
	Bitmap myIma ;
	int x=30,y=20,i = 1;
	int x1 = 100,y1=100, j =1;
	int x2 = 300,y2=50, k =1;

	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
		WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImag=BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
		myIma=BitmapFactory.decodeResource(getResources(), R.drawable.ball3);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		//paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage,x,y, paint);
		//paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImag,x1+300,y1, paint);
		//canvas.drawCircle(x1+1000, y1, 30, paint);
		//paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myIma,x2+500,y2, paint);
	//	canvas.drawCircle(x2+500, y2, 10, paint);

		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		int height = displaymetrics.heightPixels;
		int width = displaymetrics.widthPixels;
		if (y>height-myImage.getHeight())
		{
			i = -1;

		}
		if (y1>height-myImage.getHeight())
		{
			j = -1;

		}
		if (y2>height-myImage.getHeight())
		{
			k = -1;

		}
		if (y==0)
		{
			i = 1;

		}
		if (y1==0)
		{
			j = 1;

		}
		if (y2<=0)
		{
			k = 1;

		}
		y = y+10*i;
		y1 = y1+20*j;
		y2 = y2+15*k;

	}

}
