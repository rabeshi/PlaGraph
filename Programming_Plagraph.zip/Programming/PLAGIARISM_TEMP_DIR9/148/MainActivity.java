package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    int x=30,y=20,y_green=100,y_yellow=50;

    Bitmap ball1, ball2, ball3;
    int step1 = 10, step2 = 20, step3 = 15;
    DrawView drawView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set full screen view
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        ball1 = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
        ball2 = BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
        ball3 = BitmapFactory.decodeResource(getResources(), R.drawable.ball3);
        drawView = new DrawView(this);
        setContentView(drawView);
        drawView.requestFocus();
    }


    public void doDraw(Canvas canvas, Paint paint) {
        canvas.drawBitmap(ball1, x, y, paint);
        canvas.drawBitmap(ball2, 100, y_green, paint);
        canvas.drawBitmap(ball3, 300, y_yellow, paint);

        y += step1;
        y_green += step2;
        y_yellow += step3;

        if (y > canvas.getHeight() || y < 0)
            step1 = -step1;
        if (y_green > canvas.getHeight() || y_green < 0)
            step2 = -step2;
        if (y_yellow > canvas.getHeight() || y_yellow < 0)
            step3 = -step3;
    }

}