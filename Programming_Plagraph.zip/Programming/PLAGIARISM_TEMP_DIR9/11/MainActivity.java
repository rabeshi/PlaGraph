package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20;
	int p = 100;
	int q = 50;
	Bitmap myimage,myimage2,myimage3;
	int dir1 = 0;
	int dir2 = 0;
	int dir3 = 0;
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myimage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myimage2=BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
		myimage3=BitmapFactory.decodeResource(getResources(), R.drawable.ball3);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		int height = displaymetrics.heightPixels;
		
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myimage, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myimage2, 100, p, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myimage3, 300, q, paint);
		
		if(dir1==0){
			y = y + 10;
			if(y>height)
				dir1=1;
		}
		
		if(dir1==1){
			y = y - 10;
			if(y<0)
				dir1=0;
			}
		
		if(dir2==0){
			p = p + 20;
			if(p>height)
				dir2=1;
		}
		
		if(dir2==1){
			p = p - 20;
			if(p<0)
				dir2=0;
			}
		
		if(dir3==0){
			q = q + 15;
			if(q>height)
				dir3=1;
		}
		
		if(dir3==1){
			q = q - 15;
			if(q<0)
				dir3=0;
			}
	}

}
