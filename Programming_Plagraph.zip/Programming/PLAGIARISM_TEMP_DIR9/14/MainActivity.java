package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x = 30, y = 20;

	DrawView drawView;
	Bitmap red,green,yellow;
	boolean check = false;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		red = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		green = BitmapFactory.decodeResource(getResources(), R.drawable.green);
		yellow = BitmapFactory.decodeResource(getResources(), R.drawable.yellow);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
	}

	public void doDraw(Canvas canvas, Paint paint) {
		
		canvas.drawBitmap(red, x, y, paint);
		canvas.drawBitmap(yellow, 100, y, paint);
		canvas.drawBitmap(green,300, y, paint);
		if (check == false) {
			if (y+red.getHeight() < canvas.getHeight()) {
				y += 10;
			}else{
				check=true;
			}
		}else{
			if(y>0){
				y-=10;
			}else{
				check=false;
			}
		}
	}
}
