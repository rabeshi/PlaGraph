package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20;
	int i=100, j=50;
	double velA=9.8, velB=19.6, velC=4.9;
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		Bitmap myImage, myImage2, myImage3;
		myImage2= BitmapFactory.decodeResource(getResources(),R.drawable.ball2);
		myImage3= BitmapFactory.decodeResource(getResources(), R.drawable.ball3);
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		//canvas.drawCircle(x, y, 5, paint);
		canvas.drawBitmap(myImage, x, y, paint);
		paint.setColor(Color.GREEN);
		//canvas.drawCircle(100, i, 30, paint);
		canvas.drawBitmap(myImage2,100,i,paint);
		canvas.drawBitmap(myImage3,300,j,paint);
		paint.setColor(Color.YELLOW);
		//canvas.drawCircle(300, j, 10, paint);
		y+=velA;
		i+=velB;
		j+=velC;
		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		int height = displaymetrics.heightPixels;
		int width = displaymetrics.widthPixels;

	
		if (y>height || y<0)
		{
			velA=-velA;
		}
		if (i>height || i<0)
		{
			velB=-velB;
		}
		if (j>height || j<0)
		{
			velC=-velC;
		}
	}

}
