package com.example.animationgame;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20,a=100,b=100,c=300,d=50;
	Bitmap myImage, myImage2,myImage3;
	int speed=10, speed1=20,speed2=15;

	
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.tennis);
		myImage3=BitmapFactory.decodeResource(getResources(), R.drawable.basket);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage2, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage, a, b, paint);
		

		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage3, c, d, paint);
		int height = canvas.getHeight();
		
		y+=speed;
		b+=speed1;
		d+=speed2;
		
		if (y>height){
			speed=-speed;
		}
		if (y<0){
			speed=-speed;
		}
		
		
		if (b>height){
			speed1=-speed1;
		}
		if (b<0){
			speed1=-speed1;
		}
		
		if (d>height){
			speed2=-speed2;
		}
		if (d<0){
			speed2=-speed2;
		}
		
		}
		}
	


