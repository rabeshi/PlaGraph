package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int y=20;
	int a=100,b=50;
	
	DisplayMetrics displaymetrics = new DisplayMetrics();
	int height;
	int width;
	Bitmap myImage1;
	Bitmap myImage2;
	Bitmap myImage3;
	int maxHeight1=0;
	int maxHeight2=0;
	int maxHeight3=0;
	boolean gravityOn=false;
	
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		height = displaymetrics.heightPixels;
		width=displaymetrics.widthPixels;
		
		myImage1=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
		myImage3=BitmapFactory.decodeResource(getResources(), R.drawable.ball3);
	}

	boolean top1 = true,top2=true,top3=true;
	public void doDraw(Canvas canvas, Paint paint) {
		
		canvas.drawBitmap(myImage1, (width/4)-(myImage1.getWidth()/2), y, paint);
		
		canvas.drawBitmap(myImage2, (width/2)-(myImage2.getWidth()/2), a, paint);
		
		canvas.drawBitmap(myImage3, (3*width/4)-(myImage3.getWidth()/2), b, paint);
		
		
		if(top1){
		y+=10;
			if((y/(height-myImage1.getHeight()))>=1){
			top1=false;
		}
		}else if(height-maxHeight1>0){
			y-=10;
			if(y<=maxHeight1){
				top1=true;
			}
			if(gravityOn){
				maxHeight1+=10;
			}
		}
		
		if(top2){
		a+=20;
		if((a/(height-myImage2.getHeight()))==1){
			top2=false;
		}
		}else if(height-maxHeight2>0){
			a-=20;
			if(a<=maxHeight2){
				top2=true;
			}
			if(gravityOn){
				maxHeight2+=20;
			}
		}
		
		if(top3){
		b+=15;
		if((b/(height-myImage3.getHeight()))==1){
			top3=false;
		}
		}else if(height-maxHeight3>0){
			b-=15;
			if(b<=maxHeight3){
				top3=true;
			}
			if(gravityOn){
				maxHeight3+=15;
			}
		}
		
	}
	/*
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		switch(id){
		case(R.id.item1):{
			gravityOn=!gravityOn;
			if(gravityOn){
				item.setChecked(true);
			}else{
				item.setChecked(false);
				maxHeight1=0;
				maxHeight2=0;
				maxHeight3=0;
			}
			return true;
		}
		default:return super.onOptionsItemSelected(item);
		}
	}
 */
}
