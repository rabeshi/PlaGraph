package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20, y1 = 100, y2 = 50, speed = 10, speed1 = 20, speed2 = 15;
	
	DrawView drawView;
	Bitmap myImage, myPic, myPicture;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myPic=BitmapFactory.decodeResource(getResources(), R.drawable.ball1);
		myPicture=BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myPic, x, y1, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myPicture, x, y2, paint);
		
		Display display = getWindowManager().getDefaultDisplay();
		Point size = new Point();
		display.getSize(size);
		int width = size.x;
		int height = size.y;
		
		y = y + speed;
		y1 = y1 + speed1;
		y2 = y2 + speed2;
		
		if((y < 0) || (y > height))
		{
			speed = -speed;
		}
		
		if((y1 < 0) || (y1 > height))
		{
			speed1 = -speed1;
		}
		
		if((y2 < 0) || (y2 > height))
		{
			speed2 = -speed2;
		}
		
	}

}
