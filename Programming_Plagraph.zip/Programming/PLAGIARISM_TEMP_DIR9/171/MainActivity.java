package com.example.animationgame;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;

 public class MainActivity extends Activity {
	int x=30,y=20;
	int a=100,b=100;
	int c=350,d=50;
	boolean l=false;
	boolean m=false;
	boolean n= false;
	Bitmap myImage;
	Bitmap myImage2;
	Bitmap myImage3;
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
		myImage3=BitmapFactory.decodeResource(getResources(), R.drawable.ball3);
	}


	@SuppressLint
	("NewApi")public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage2, a, b, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage3, c, d, paint);
	
	Display dispaly = getWindowManager().getDefaultDisplay();
    Point size = new Point();
    dispaly.getSize(size); 
      int Height= size.y;
      
      if(y < Height && l == false)		
		{
	     
		y= y+10;	
		}
	      else{
	    	  l = true;
	      }
	      if(l == true)
	      {
		  y = y - 10;
		  if(y < 0){
			  l = false;
		  }
	      } 
	      if(b< Height && m == false)		
			{
		     
			b= b+20;	
			}
		      else{
		    	  m = true;
		      }
		      if( m== true)
		      {
			  b = b - 20;
			  if(b < 0){
				  m = false;
			  }
		      }
		      if(d < Height && n == false)		
				{
			     
				d= d+15;	
				}
			      else{
			    	  n = true;
			      }
			      if(n == true)
			      {
				  d = d - 15;
				  if(d< 0){
					  n = false;
				  }
			      } 
}
}