package com.example.animationagame1;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Window;
import android.view.WindowManager;


public class MainActivity extends Activity {
	int x=30,y=20;
	int height = 0;//variable to store screen height
	int y1 = 0;//y value of first ball
	int y2 = 0;//y value of second ball
	int y3 = 0;//y value of third ball
	Bitmap ball1; //first ball image
	Bitmap ball2;//second ball image
	Bitmap ball3;//third ball image
	int vel1 = 10;//velocity of each ball
	int vel2 = 20;
	int vel3 = 15;
	
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		ball1 = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		ball2 = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		ball3 = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		height = displaymetrics.heightPixels;		
	}


	public void doDraw(Canvas canvas, Paint paint) {
		//this changes the direction of travel of that balls if the hit the edge
		if (y1 > height || y1 < 0){
			vel1 *= -1;
		}
		if (y2 > height || y2 < 0){
			vel2 *= -1;
		}
		if (y3 > height || y3 < 0){
			vel3 *= -1;
		}
		//updates the position of the balls
		y1 += vel1;
		y2 += vel2;
		y3 += vel3;
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(ball1, x, y1, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(ball2, 300, y2, paint);//just randomly chose number so the ball won't be rendered on top of each other
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(ball3, 600, y3, paint);		
		
	}

}
