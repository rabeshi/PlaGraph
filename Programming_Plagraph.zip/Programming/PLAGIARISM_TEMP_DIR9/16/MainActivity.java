package com.example.bounceballs;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int height;
	Bitmap myImage, myImage2,myImage3;
	int direcBlk = 10, direcGrn = 20, direcYel = 15;
	int blkx=30,blky=20, grnx=100,grny=100,yelx=300,yely=50;;
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.poke);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.soccerball);
		myImage3=BitmapFactory.decodeResource(getResources(), R.drawable.stripes);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		height = canvas.getHeight();		
		
		if (blky <= 0){
			direcBlk = 10;						
		}	
		if(blky >= height){
			direcBlk = -10;
		}		
		//canvas.drawCircle(blkx, blky, 5, paint);
		paint.setColor(Color.BLACK);		
		canvas.drawBitmap(myImage, blkx, blky, paint);
		blky = blky + direcBlk;	
		
		if (grny <= 0){
			direcGrn = 20;						
		}	
		if(grny >= height){
			direcGrn = -20;
		}		
		paint.setColor(Color.GREEN);
		//canvas.drawCircle(grnx, grny, 30, paint);
		canvas.drawBitmap(myImage2, grnx, grny, paint);
		grny = grny + direcGrn;
		
		if (yely <= 0){
			direcYel = 15;						
		}	
		if(yely >= height){
			direcYel = -15;
		}		
		paint.setColor(Color.YELLOW);
		//canvas.drawCircle(yelx, yely, 10, paint);
		canvas.drawBitmap(myImage3, yelx, yely, paint);
		yely = yely + direcYel;
		
		
		
		
	}

}
