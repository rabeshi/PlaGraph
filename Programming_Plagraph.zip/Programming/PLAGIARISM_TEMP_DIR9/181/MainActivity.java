package com.example.drawing;

import android.app.Activity;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.Bitmap;

public class MainActivity extends Activity {
	int x=30,y=20,height, width,x1=150,y1=100,x2=300,y2=50,bounce0=-1,bounce1=-1,bounce2=-1;

	DrawView drawView;
	Bitmap myImage;
	Bitmap myImage1;
	Bitmap myImage2;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
		WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth();
		height = display.getHeight();
	
		myImage = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage1 = BitmapFactory.decodeResource(getResources(), R.drawable.soccerball);
		myImage2 = BitmapFactory.decodeResource(getResources(), R.drawable.cricketball);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		//paint.setColor(Color.BLACK);
		//canvas.drawCircle(x, y, 5, paint);
		canvas.drawBitmap(myImage, x, y, paint);
		//paint.setColor(Color.GREEN);
		//canvas.drawCircle(x1, y1, 30, paint);
		canvas.drawBitmap(myImage1, x1, y1, paint);
		//paint.setColor(Color.YELLOW);
		//canvas.drawCircle(x2, y2, 10, paint);
		canvas.drawBitmap(myImage2, x2, y2, paint);

		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		int height = displaymetrics.heightPixels;
		int width = displaymetrics.widthPixels;
		
		y = y + bounce0*5;
				
		if (y >= height-myImage.getHeight())
		{
			bounce0 *= -1;
			y = y - 5;
		
		}
		if (y == 0)
		{
			bounce0 *= -1;
			y = y + 5;
		}
		
		y1 = y1 + bounce1*5;
		
		if (y1 >= height-myImage1.getHeight())
		{
			bounce1 *= -1;
			y1 = y1 - 5;
		
		}
		if (y1 == 0)
		{
			bounce1 *= -1;
		
		}
		
		y2 = y2 + bounce2*5;
		
		if (y2 >= height-myImage2.getHeight())
		{
			bounce2 *= -1;
			y2 = y2 - 10;

		}
		if (y2 == 0)
		{
			bounce2 *= -1;
			y2 = y2 + 10;
		}
					 
	}

}
