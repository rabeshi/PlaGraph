package com.example.animationgame;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	/* 
	 Hi Pravesh 
	 I included the res folder as i downloaded additional images for the ball images.
	 The images are located in the drawable-mdpi folder.
	 Thanks 
	 Meelan
	 */
	int x=30,posball1=20,posball2=20,posball3=20,accelball1=10,accelball2=20,accelball3=15;
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		
	}


	public void doDraw(Canvas canvas, Paint paint) {
		
		
		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		int height = displaymetrics.heightPixels;
			
		Bitmap myImage = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		if(posball1>=height-myImage.getHeight())
		{
			accelball1 = accelball1*-1;
		}
		if(posball1<=0)
		{
			accelball1 = accelball1*-1;
		}
		posball1 = posball1+(accelball1);
		canvas.drawBitmap(myImage, x, posball1, paint);
		
		Bitmap myImage2 = BitmapFactory.decodeResource(getResources(), R.drawable.ball2t);
		if(posball2>=height-myImage2.getHeight())
		{
			accelball2 = accelball2*-1;
		}
		if(posball2<=0)
		{
			accelball2 = accelball2*-1;
		}
		posball2 = posball2+(accelball2);
		canvas.drawBitmap(myImage2, 250, posball2, paint);
		
		Bitmap myImage3 = BitmapFactory.decodeResource(getResources(), R.drawable.ball3t);
		if(posball3>=height-myImage3.getHeight())
		{
			accelball3 = accelball3*-1;
		}
		if(posball3<=0)
		{
			accelball3 = accelball3*-1;
		}
		posball3 = posball3+(accelball3);
		canvas.drawBitmap(myImage3, 500, posball3%height, paint);

	}

}
