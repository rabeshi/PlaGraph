package com.example.animationgame;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20, vitess = 10, vitess1 = 20, vitess2 = 15;
	int height, width;
	int ya = 0, yb =0;
    Bitmap myImage1,myImage2, myImage3;
    
	DrawView drawView;   

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
		WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage1=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.ball1);
		myImage3=BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
	}


	@SuppressLint("NewApi") public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage1, x, y, paint);
		//canvas.drawCircle(x, y, 5, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage2, x, ya, paint);
		//canvas.drawCircle(100, y1, 30, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage3, x, yb, paint);
		//canvas.drawCircle(300, y2, 10, paint);
		
		Display display = getWindowManager().getDefaultDisplay();
		Point size = new Point();
		display.getSize(size);
		width = size.x;
	    height = size.y;
	    
	    y = y + vitess;
	    ya = ya + vitess1;		
	    yb = yb + vitess2;
	   
	    if ((y < 0) || (y > height))
	    {
	    	vitess = -vitess;
	    }
	    if ((ya < 0) || (ya > height))
	    {
	    	 vitess1 = -vitess1; 
	    }
	     if ((yb < 0) || (yb > height))
	     {
	    	 vitess2 = -vitess2;    
	    }
	}

}
