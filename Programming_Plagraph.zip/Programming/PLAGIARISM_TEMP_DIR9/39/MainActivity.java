package com.example.drawview;

import android.R.bool;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=20,y=20,yy = 50, yg = 100;
	boolean x1 =false, x2 =false, x3 =false;
	Bitmap myImage;
	Bitmap myImage2;
	Bitmap myImage3;
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		myImage = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage2 = BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
		myImage3 = BitmapFactory.decodeResource(getResources(), R.drawable.ball3);
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
	}


	public void doDraw(Canvas canvas, Paint paint) {
		canvas.drawBitmap(myImage, x, y, paint);
		canvas.drawBitmap(myImage2, 100, yg, paint);
		canvas.drawBitmap(myImage3, 230, yy, paint);
		
		
		
		
		DisplayMetrics display = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(display);
		int L = display.heightPixels-50;
		
		if(y >= L){x1 = true;}
		if(y <= 0){x1 = false;}
		if(x1){y = y - 10;}
		else{y = y +10;}
		
		if(yy >= L){x2 = true;}
		if(yy <= 0){x2 = false;}
		if(x2){yy = yy - 15;}
		else{yy = yy + 15;}
		
		if(yg <= 0){x3 = false;}
		if(yg >= L){x3 = true;}
		if(x3){yg = yg - 20;}
		else{yg = yg +20;}
		}
	}


