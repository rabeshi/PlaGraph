package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20;
	int s_1 = 1,s_2 = 1,s_3 = 1;
	int y_2=100;
	int y_3=50;
	
	Bitmap myImage;
	Bitmap myImage2;
	Bitmap myImage3;
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.gunner);
		myImage3=BitmapFactory.decodeResource(getResources(), R.drawable.barca);
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		
	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage2, 200, y_2, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage3, 400, y_3, paint);
		//y = y + 10;
		//y_2 = y_2+20;
		//y_3 = y_3+15;
		//Display display = getWindowManager().getDefaultDisplay();
		 int height = getWindowManager().getDefaultDisplay().getHeight(); 
		 if(y<0){
			s_1=1;
			
			 //y=0;
		 } //y=y+s_1;
		 if(y>=height){
			 s_1=-1;
			 //y=y+s_1;
		 }
		 y=y+s_1*10;
		 
		 if(y_2<0){
			 s_2=1;
		 }
		 
		 if(y_2>=height){
			 s_2=-1;
		 }
		 y_2=y_2+s_2*20;
		 
		 if(y_3<0){
			 s_3=1;
		 }
		 
		 if(y_3>=height){
			 s_3=-1;
		 }
		 y_3=y_3+s_3*15;
		 
	}

}
