package com.example.animationgame;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	 int x=30,y=20, a = 100, b = 100, i = 300, j = 50;
	 int height;
	 int yspeed=15;
	 int bspeed=20;
	 int jspeed=15;
	 Bitmap myImage;
	 DrawView drawView;

	 @SuppressLint("NewApi") @Override
	 public void onCreate(Bundle savedInstanceState) {
	  super.onCreate(savedInstanceState);
	  // Set full screen view
	  getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
	    WindowManager.LayoutParams.FLAG_FULLSCREEN);
	  requestWindowFeature(Window.FEATURE_NO_TITLE);
	  Display display = getWindowManager().getDefaultDisplay();
	  Point size = new Point();
	  display.getSize(size);
	  int width = size.x;
	  height = size.y;
	  drawView = new DrawView(this);
	  setContentView(drawView);
	  drawView.requestFocus();
	  
	  myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
	  
	 }


	 public void doDraw(Canvas canvas, Paint paint) {
	  paint.setColor(Color.BLACK);
	  canvas.drawBitmap(myImage, x, y, paint);
	  paint.setColor(Color.GREEN);
	  canvas.drawBitmap(myImage, a, b, paint);
	  paint.setColor(Color.YELLOW);
	  canvas.drawBitmap(myImage, i, j, paint);
	  y=y+yspeed;
	  if ((y>height)||(y<0)){
	   yspeed=-1*yspeed;
	  }
		  b=b+bspeed;
	 
		  if ((y>height)||(y<0)){
		   bspeed=-1*bspeed;
		  }
		  
		  j=j+jspeed;
		  if ((j>height)||(j<0)){
		   jspeed=-1*jspeed;
		  }
	  }
	  
	  
	 }

