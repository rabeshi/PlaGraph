package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20,w=100,z=50;
	int i=1,j=1,k=1;
	
	DrawView drawView;
	Bitmap myImage;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		myImage = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage,x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage,100, w, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage,300, z, paint);
		
		
		int height = canvas.getHeight();
		
		if(y<=0){
			i=1;
		}
		if(y+myImage.getHeight()>=height){
			i=-1;
		}
		y+=10*i;
		
		if(w<=0){
			j=1;
		}
		if(w+myImage.getHeight()>=height){
			j=-1;
		}
		w+=15*j;
		
		if(z<=0){
			k=1;
		}
		if(z+myImage.getHeight()>=height){
			k=-1;
		}
		z+=15*k;
	}

}
