package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20;
	int speed=1,speed2=1;
	int speed1=1,i=100,k,j=100;
	int d=50,c=300;
	
	Bitmap myImage,myImage1,myImage2;
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.codeinjava);
		myImage1 =BitmapFactory.decodeResource(getResources(), R.drawable.soccer);
		myImage2 =BitmapFactory.decodeResource(getResources(), R.drawable.usain);
	}


	 public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage1,i, j, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage2,c, d,paint);
		
	    // getting the height of the screen
		int heightOfScreen = canvas.getHeight(); 
		
		// code for the first ball 
		if(y<=0 )
			speed =1;//initial speed of the ball
		if(y +myImage.getHeight()>=heightOfScreen)
			speed =-1;// the ball is moving up when this condition is true
		y+=10*speed;// incrementing the ball to move faster
		
		
		// code for the second ball
		if(j<=0)
			speed1=1;//initial speed of the ball
		if(j+ myImage1.getHeight()>=heightOfScreen)
			speed1=-1;// the ball is moving up when this condition is true
		 j+=20*speed1;// incrementing the ball to move faster
		
		
		//code for the third ball
		
		if(d<=0)
		   speed2=1;//initial speed of the ball
		if(d +myImage2.getHeight()>=heightOfScreen)
		      speed2 =-1;// the ball is moving up when this condition is true
		 d+=15*speed2;// incrementing the ball to move faster
		
		 
	}

}
