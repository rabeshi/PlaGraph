package com.example.animationgame;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20,y_gre=100,y_yel=50;
	int turn1=1,turn2=1,turn3=1;
	Bitmap myImage,Bella,Fedora;
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		Bella=BitmapFactory.decodeResource(getResources(), R.drawable.bella);
		Fedora=BitmapFactory.decodeResource(getResources(), R.drawable.fedora);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(Bella, 300, y_gre, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(Fedora, 100, y_yel, paint);
		y = y + 10*turn1;
		y_gre = y_gre + 20*turn2;
		y_yel = y_yel + 15*turn3;
		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		int height = displaymetrics.heightPixels;
		int width = displaymetrics.widthPixels;
		if (y > height)
		{
			turn1=-1;
		}
		else if (y < 0)
		{
			turn1=1;
		}
		if (y_gre > height)
		{
			turn2=-1;
		}
		else if (y_gre < 0)
		{
			turn2=1;
		}
		if (y_yel > height)
		{
			turn3=-1;
		}
		else if (y_yel < 0)
		{
			turn3=1;
		}
	}

}
