package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20, P=20, U=20;
	
	 int i=1 ;
	 int Q=1 ;
	 int W=1 ;
	 

		Bitmap myimage;
		Bitmap image;
		Bitmap mage;
	 
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		
		 myimage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		 image = BitmapFactory.decodeResource(getResources(), R.drawable.bal);
		 mage=BitmapFactory.decodeResource(getResources(), R.drawable.ba);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myimage, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(image, x+600, P, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(mage, x+300, U, paint);
		
		 int n = canvas.getHeight();
		   if(y == 30)
			   i = 1;
		   
		    if(y >= n)
			   i = -1;
		   y += 10*i;
			
		   
		   if(U == 20)
		   W= 1;
		      
		   if(U >= n)
			   W = -1;
		   U += 20*W;
			
		   if(P == 20)
			    Q= 1;
		   
		   if(P >= n)
			   Q = -1;
		   P += 15*Q;
		
//	
//	
	}
}
