package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20,k=100,l=100,m=300,n=50;
	Bitmap myImage,myImage1,myImage2; 
	boolean bottom,bottom1,bottom2 = false;
	
	DrawView drawView;


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage1=BitmapFactory.decodeResource(getResources(), R.drawable.ball1);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage1, k, l, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage2, m, n, paint);


		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		int height = displaymetrics.heightPixels;
		int width = displaymetrics.widthPixels;
		
		if (y >= height){
			
			bottom = true;	
		}
		else if (y<=0){
			bottom = false;
		}
		if (bottom){
			y = y - 10;
		}
		else if (!bottom){
			y = y + 10;
		}
		
		if (l >= height){
			bottom1 = true;
		}
		else if (l<=0){
			bottom1 = false;
		}	
		if (bottom1){
			l = l - 20;
			
		}
		else if (!bottom1){
			l = l + 20;
		}
		
		
		if (n >= height){
			bottom2 = true;
		}
		else if (n<=0){
			bottom2 = false;
		}
		
		if (bottom2){
			n = n - 15;
		}
		else if (!bottom2){
			n = n + 15;
		}
	
	}

}
