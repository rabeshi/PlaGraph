package com.example.animationgame;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20,y2=100,y3=50,Height;
	boolean y_up, y2_up, y3_up;
	
	DrawView drawView;
	Bitmap ball_red,ball_pink,ball_grey;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		
		//initialise balls
		ball_red=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		ball_pink=BitmapFactory.decodeResource(getResources(), R.drawable.ball_pink);
		ball_grey=BitmapFactory.decodeResource(getResources(), R.drawable.ball_grey);
		y_up = y2_up = y3_up = false; //down first
		
		//get screen height
		DisplayMetrics metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		Height = metrics.heightPixels;
	}


	public void doDraw(Canvas canvas, Paint paint) {
		/** CJ Bester - 783135 **/
		
		//draw balls
		canvas.drawBitmap(ball_red,x, y, paint);
		canvas.drawBitmap(ball_pink,100, y2, paint);
		canvas.drawBitmap(ball_grey,300, y3, paint);
		
		//move balls
		y = y + ((y_up)?(-10):(10));
		y2 = y2 + ((y2_up)?(-20):(20));
		y3 = y3 + ((y3_up)?(-15):(15));
		
		//redirect balls
		//ball_red
		if((!y_up && y>=Height)||(y_up && y<=0)) {
			y_up = !y_up;
		}
		//ball_pink
		if((!y2_up && y2>=Height)||(y2_up && y2<=0)) {
			y2_up = !y2_up;
		}
		//ball_grey
		if((!y3_up && y3>=Height)||(y3_up && y3<=0)) {
			y3_up = !y3_up;
		}
	}

}
