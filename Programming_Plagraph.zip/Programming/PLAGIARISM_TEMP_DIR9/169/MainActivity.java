package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
int x=30,y=20,yspeed=10,a=100,bspeed=20,b=100,i=300,p=50,pspeed=15;
	Bitmap myImage;
	Bitmap myImage1;
	Bitmap myImage2;
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage1=BitmapFactory.decodeResource(getResources(), R.drawable.ball1);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
		WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
	}


	public void doDraw(Canvas canvas, Paint paint) {
		int height=canvas.getHeight();
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage1, a, b, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage2, i, p, paint);
	  
		if(b<=0)
		{
			bspeed=20;
		}
		else if(b>=height)
		{
			bspeed=-20;
		}
		if(p<=0)
		{
			pspeed=15;
		}
		else if(p>=height)
		{
			pspeed=-15;;
		}
		if(y<=0)
		{
			yspeed=20;
		}
		else if(y>=height)
		{
		     yspeed=-20;
		}
	    y=y+yspeed;
		b=b+bspeed;
		p=p+pspeed;
	}

}
