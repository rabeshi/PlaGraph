package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20,z=100,a=50;
	boolean c1=false,c2=false,c3=false;
	Bitmap myImage,myImage1,myImage2;
	DrawView drawView;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage1=BitmapFactory.decodeResource(getResources(), R.drawable.cball);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.tball);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage1, 100, z, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage2, 300, a, paint);
		Display display = getWindowManager().getDefaultDisplay(); 
		int height = display.getHeight();
		
		if(y==0)
			c1=false;
		else if(y>height)
			c1=true;
		if(c1==false)
			y+=10;
		else
			y-=10;
		
		if(z==0)
			c2=false;
		else if(z>height)
			c2=true;
		if(c2==false)
			z+=20;
		else
			z-=20;
		
		if(a==0)
			c3=false;
		else if(a>height)
			c3=true;
		if(c3==false)
			a+=15;
		else
			a-=15;
		
		
		
			
	}
}
