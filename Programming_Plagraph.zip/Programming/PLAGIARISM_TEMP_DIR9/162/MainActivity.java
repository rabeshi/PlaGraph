package com.example.animationgame;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x,y;
	int a = 100;
	int b = 50;
	int yspeed = 10;
	int aspeed = 20;
	int bspeed = 15;
	Bitmap myImage1;
	Bitmap myImage3;
	Bitmap myImage2;
	Boolean bool = false;
	Boolean bool1= false;
	Boolean bool2 = false;
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage1=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.ball3);
		myImage3=BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		/*paint.setColor(Color.BLACK);
		canvas.drawCircle(x, y, 5, paint);
	
		paint.setColor(Color.GREEN);
		canvas.drawCircle(100, a, 30, paint);*/
		a  = a + aspeed;
		canvas.drawBitmap(myImage1, 90, y, paint);
		canvas.drawBitmap(myImage2, 30, a, paint);
		canvas.drawBitmap(myImage3, 0, b, paint);
				
		/*paint.setColor(Color.YELLOW);
		canvas.drawCircle(300, b, 10, paint);*/
		
		Display display = getWindowManager().getDefaultDisplay();
		Point size = new Point();
		display.getSize(size);
		b  = b + bspeed;
		int width = size.x;
		int height = size.y;
		y = y+yspeed;
		
		if (y>height){
			yspeed = -yspeed;
		}
		if (y <0){
			yspeed =-yspeed;
		}
		
		
		
		if (a>height){
			aspeed = -aspeed;
		}
		if (a <0){
			aspeed =-aspeed;
		}
		
		if (b>height){
			bspeed = -bspeed;
		}
		if (b <0){
			bspeed =-bspeed;
		}
		}
	}


