package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20,a=100,b=100,c=300,d=50;
	Bitmap myImage;
	Bitmap myImage1;
	Bitmap myImage2;
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage1=BitmapFactory.decodeResource(getResources(), R.drawable.ball1);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		int height=getApplicationContext().getResources().getDisplayMetrics().heightPixels;
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y,paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage1,a, b, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage2,c,d, paint);
		y=y-10;
		if(y<= 0){
			y=height;
		}
		b = b -20;
		if(b<=0){
			b=height;
		}
		d = d -15;
		if(d<=0){
			d=height;
		}
	}

}
