package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x = 0, y = 20, a = 350, b = 100, c = 700, d = 50, flip1 = -1,
			flip2 = -1, flip3 = -1;
	Bitmap myImage;
	Bitmap myImage2;
	Bitmap myImage3;
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage = BitmapFactory.decodeResource(getResources(),R.drawable.earth);
		myImage2 = BitmapFactory.decodeResource(getResources(),R.drawable.water);
		myImage3 = BitmapFactory.decodeResource(getResources(),R.drawable.fire);
	}

	public void doDraw(Canvas canvas, Paint paint) {

		canvas.drawBitmap(myImage, x, y, paint);

		canvas.drawBitmap(myImage2, a, b, paint);

		canvas.drawBitmap(myImage3, c, d, paint);

		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		int height = displaymetrics.heightPixels;
		int width = displaymetrics.widthPixels;

		y = y + flip1 * 5;

		if (y >= height - myImage.getHeight()) {
			flip1 *= -1;
			y = y - 5;
		}
		if (y == 0) {
			flip1 *= -1;
			y = y + 5;
		}
		
		b = b + flip2 * 5;

		if (b >= height - myImage2.getHeight()) {
			flip2 *= -1;
			b = b - 10;
		}
		if (b == 0) {
			flip2 *= -1;
			b = b + 10;
		}

		d = d + flip3 * 5;

		if (d >= height - myImage3.getHeight()) {
			flip3 *= -1;
			d = d - 5;
		}
		if (d == 0) {
			flip3 *= -1;
			d = d + 5;
		}
	}

}
