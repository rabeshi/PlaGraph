package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20;
	int Gy = 100;
	int Yy = 50;
	int YMove = 10;
	int GMove = 20;
	int YyMove = 15;
	int lol = 1;
	int Glol = 1;
	int Ylol = 1;
	
	
	DrawView drawView;
	
	Bitmap myImage;
	Bitmap myImage2;
	Bitmap myImage3;


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		
		myImage = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage2 = BitmapFactory.decodeResource(getResources(),R.drawable.pokeball);
		myImage3 = BitmapFactory.decodeResource(getResources(), R.drawable.ball3);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		//canvas.drawCircle(x, y, 5, paint);
		canvas.drawBitmap(myImage, x,y, paint);
		paint.setColor(Color.GREEN);
		//canvas.drawCircle(100, Gy, 30, paint);
		canvas.drawBitmap(myImage2, 100, Gy,paint);
		paint.setColor(Color.YELLOW);
		//canvas.drawCircle(300, Yy, 10, paint);
		canvas.drawBitmap(myImage3, 450, Yy, paint);
		
		int height = this.getResources().getDisplayMetrics().heightPixels;
		

		if(y<=height){
			y =y+ (YMove*lol);
		}
		if(y>=height){
			lol = lol * (-1);
			y=height;
		}
		if(y<=0){
			lol = lol * (-1);
			y=0;
		}
		
		if(Gy<=height){
			Gy = Gy + (GMove * Glol);
		}
		if(Gy>=height){
			Glol = Glol * (-1);
			Gy = height;
		}
		if(Gy<=0){
			Glol = Glol * (-1);
			Gy =0;
		}
		
		if(Yy<=height){
			Yy = Yy + (YMove * Ylol);
		}
		if(Yy>=height){
			Ylol = Ylol * (-1);
			Yy = height;
		}
		if(Yy<=0){
			Ylol = Ylol * (-1);
			Yy =0;
		}
		
		
		
	}

}
