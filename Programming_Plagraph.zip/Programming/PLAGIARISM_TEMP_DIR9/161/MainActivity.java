package com.example.animationgame;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20, y_speed = 10, y_speed1 = 20, y_speed2 = 15;
	int height, width;
	int y1 = 0, y2 =0;
    Bitmap myImage1,myImage2, myImage3;
    
	DrawView drawView;   

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
		WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage1=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.ball1);
		myImage3=BitmapFactory.decodeResource(getResources(), R.drawable.ball2);
	}


	@SuppressLint("NewApi") public void doDraw(Canvas canvas, Paint paint) {
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage1, x, y, paint);
		//canvas.drawCircle(x, y, 5, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage2, x, y1, paint);
		//canvas.drawCircle(100, y1, 30, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage3, x, y2, paint);
		//canvas.drawCircle(300, y2, 10, paint);
		
		Display display = getWindowManager().getDefaultDisplay();
		Point size = new Point();
		display.getSize(size);
		width = size.x;
	    height = size.y;
	    
	    y = y + y_speed;
	    y1 = y1 + y_speed1;		
	    y2 = y2 + y_speed2;
	   
	    if ((y < 0) || (y > height))
	    {
	    	y_speed = -y_speed;
	    }
	    if ((y1 < 0) || (y1 > height))
	    {
	    	 y_speed1 = -y_speed1; 
	    }
	     if ((y2 < 0) || (y2 > height))
	     {
	    	 y_speed2 = -y_speed2;    
	    }
	}

}
