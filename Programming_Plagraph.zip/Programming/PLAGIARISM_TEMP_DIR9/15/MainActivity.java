package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20;
	int a=20, b=15;
	int speed1 = 1, speed2=1, speed3=1;
	Bitmap myImage,myImage1,myImage2;
	
	DrawView drawView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage=BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		myImage1=BitmapFactory.decodeResource(getResources(), R.drawable.christ);
		myImage2=BitmapFactory.decodeResource(getResources(), R.drawable.grey);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(myImage, x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(myImage1, 100, 30+a, paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(myImage2, 50, 10+b, paint);

		
		DisplayMetrics metrics = new DisplayMetrics();
		this.getWindowManager().getDefaultDisplay().getMetrics(metrics);
		int Width = metrics.widthPixels;
		int Height = metrics.heightPixels;
		
		
		int H1 = myImage.getHeight();
		int H2 = myImage1.getHeight();
		int H3 = myImage2.getHeight();
	
	
	
		if(y<0){
		speed1 =1;
		}
		
		if(y>=Height-H1){
			speed1=-1;
			}
		
		y=y+speed1*10;
		
		if(a<0){
			speed2 =1;
		}
		if(a>=Height-H2){
			speed2=-1;
			}
		a=a+speed2*20;
			
			
		if(b<0){
			speed3 = 1;
			}
		if(b>=Height-H3){
			speed3 = -1;
		}
		b=b+speed3*15;
		
	}

}
