package com.example.animationgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int xB=30,  yB=20;
	int xG=100, yG=100;
	int xY=300, yY=50;
	int direction1 = 1, direction2 = 1, direction3 = 1;
	
	DrawView drawView;
	Bitmap myImage;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		myImage = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
	}


	public void doDraw(Canvas canvas, Paint paint) {

		// draw 3 balls at predefined locations
		canvas.drawBitmap(myImage, xB, yB, paint);
		canvas.drawBitmap(myImage, xG, yG, paint);
		canvas.drawBitmap(myImage, xY, yY, paint);

		// its not expressly said what the balls should do when they reach the top, so i made them bounce again.
		// disabling the first check of these ifs will make them simply return upwards.
		
		// "passed edge" => change direction (not pixel level accurate!) (but close enough for a lab?)
		if (yB <= 0 || yB >= canvas.getHeight()+10) direction1*=-1;
		if (yG <= 0 || yG >= canvas.getHeight()+20) direction2*=-1;
		if (yY <= 0 || yY >= canvas.getHeight()+15) direction3*=-1;
		
		// gogogo
		yB += (10*direction1);
		yG += (20*direction2);
		yY += (15*direction3);
	}

}
