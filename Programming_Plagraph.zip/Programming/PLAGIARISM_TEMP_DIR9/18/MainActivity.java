package com.example.androidgame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
	int x=30,y=20,p=100,q=100,k=300,l=50;
	int dir1=1,dir2=1,dir3=1;
	
	DrawView drawView;
	Bitmap Andries,Jackson,Reezy;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set full screen view
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		drawView = new DrawView(this);
		setContentView(drawView);
		drawView.requestFocus();
		Andries = BitmapFactory.decodeResource(getResources(), R.drawable.andries);
		Jackson = BitmapFactory.decodeResource(getResources(), R.drawable.jackson);
		Reezy = BitmapFactory.decodeResource(getResources(),R.drawable.lesego);
	}


	public void doDraw(Canvas canvas, Paint paint) {
		double h=canvas.getHeight();
		Andries = Bitmap.createScaledBitmap(Andries, 100,100, true);
		Jackson = Bitmap.createScaledBitmap(Jackson, 100,100, true);
		Reezy = Bitmap.createScaledBitmap(Reezy, 100,100, true);
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(Jackson,x, y, paint);
		paint.setColor(Color.GREEN);
		canvas.drawBitmap(Reezy,p, q,paint);
		paint.setColor(Color.YELLOW);
		canvas.drawBitmap(Andries,k, l,paint);
		if(y<=20)
			dir1=1;
		if(y>=h)
			dir1=-1;
		y+=10*dir1;
		if(q<=100)
			dir2=1;
		if(q>=h)
			dir2=-1;
		q+=15*dir2;
		if(l<=50)
			dir3=1;
		if(l>=h)
			dir3=-1;
		l+=20*dir3;
	}

}
